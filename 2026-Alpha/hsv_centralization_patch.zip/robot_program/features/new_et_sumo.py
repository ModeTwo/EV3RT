"""Experimental ET sumo route (steps 1-5). Real-hardware calibration required."""
import time
import os
import math
from py_trees.behaviour import Behaviour
from py_trees.common import Status
from py_etrobo_util import TraceSide, BottleColor
from ..runtime import runtime
from ..behaviours.line_trace import TraceLine
from .sumo_bearing_motion import current_bearing
from ..color_thresholds import SENSOR_BLUE_LINE, SENSOR_BLACK_LINE


class NewEtSumo(Behaviour):
    # Tune on the actual course. All distances are mm, angles degrees.
    FIRST_STRAIGHT_MM = 250.0
    SECOND_STRAIGHT_MM = 1100.0
    ARC_RADIUS_MM = 230.0  # nominal radius from wheel power ratio (not closed-loop radius control)
    ARC_ANGLE_DEG = 90.0  # physical left arc; heading sign depends on runtime.course
    PUSH_MM = 60.0
    BACK_MM = 60.0
    DRIVE_POWER = 35
    ARC_POWER = 28
    PUSH_POWER = 24
    TURN_POWER = 22
    TRACE_POWER = 40
    TRACE_TARGET_V = 75
    TRACE_PID = (0.65, 0.000001, 0.045)
    # Blue/black detection must be calibrated from actual HSV samples.
    COLOR_STABLE_FRAMES = 3
    TRACE_MIN_MM = 30.0
    TRACE_MAX_MM = 850.0
    WHEEL_TREAD_MM = 110.0
    MM_PER_POWER_SEC = 7.0  # safety timeout estimate only; distance uses plotter
    CAMERA_TIMEOUT_SEC = 3.0
    CAMERA_CONFIRM_FRAMES = 3
    CAMERA_MAX_ABS_THETA = 50.0
    TURN_TOLERANCE_DEG = 3.0
    HEADING_KP = 0.85
    HEADING_CORRECTION_LIMIT = 13

    def __init__(self, context, config):
        super().__init__(name='new_et_sumo_steps_1_to_5')
        self.context = context
        self.config = config
        self.stage = None
        self.trace = None
        self.test_stop_after = None

    def _distance(self):
        return float(runtime.plotter.get_distance())

    def _heading(self):
        return -float(runtime.course) * float(runtime.gyro_sensor.get_angle())

    def _motors(self, left, right):
        for motor in (runtime.left_motor, runtime.right_motor):
            motor.set_brake(False)
        runtime.left_motor.set_power(int(max(-100, min(100, left))))
        runtime.right_motor.set_power(int(max(-100, min(100, right))))

    def _stop(self):
        for motor in (runtime.left_motor, runtime.right_motor):
            motor.set_power(0)
            motor.set_brake(True)

    def _enter(self, stage):
        self._stop()
        self.stage = stage
        self.start_mm = self._distance()
        self.start_heading = self._heading()
        self.started = time.monotonic()
        self.logger.info('NEW SUMO stage=%s distance=%.1f heading=%.1f', stage,
                         self.start_mm, self.start_heading)

    def _advance(self, completed_stage, next_stage):
        """Stop at the selected test boundary without entering the next stage."""
        if self.test_stop_after == completed_stage:
            self._stop()
            self.stage = 'DONE'
            self.logger.info('NEW SUMO TEST STOP after %s', completed_stage)
            return Status.SUCCESS
        self._enter(next_stage)
        return Status.RUNNING

    def initialise(self):
        stop_after = os.environ.get('ET_SUMO_TEST_STOP_AFTER', '').strip().upper()
        if stop_after not in ('', 'TRACE', 'STRAIGHT_250', 'LEFT_ARC', 'STRAIGHT_1100', 'BACK_60'):
            raise ValueError('ET_SUMO_TEST_STOP_AFTER must be TRACE, STRAIGHT_250, LEFT_ARC, STRAIGHT_1100, BACK_60 or unset')
        self.test_stop_after = stop_after or None
        self.logger.info('NEW SUMO test stop after=%s', self.test_stop_after)
        runtime.require('plotter', 'color_sensor', 'gyro_sensor', 'video',
                        'left_motor', 'right_motor')
        if runtime.course not in (-1, 1):
            raise ValueError("runtime.course must be +1 or -1")
        # Bearing reference is registered during ResetDevice. Fail before moving if missing.
        current_bearing(self.context)
        self.trace = TraceLine('sumo trace to blue-black boundary',
                               self.TRACE_TARGET_V, self.TRACE_POWER,
                               *self.TRACE_PID, TraceSide.NORMAL)
        self.saw_blue = False
        self.blue_count = 0
        self.black_count = 0
        self.session = None
        self.last_frame_id = -1
        self.confirmed = 0
        self.theta_values = []
        self._enter('TRACE')

    def _fail(self, reason):
        self.logger.error('NEW SUMO FAIL: %s', reason)
        self._stop()
        return Status.FAILURE

    def _straight(self, target_mm, power, reverse=False):
        traveled = (self.start_mm - self._distance()) if reverse else (self._distance() - self.start_mm)
        if traveled < -8.0:
            raise RuntimeError("distance changed opposite to commanded direction")
        if traveled >= target_mm:
            return True
        if time.monotonic() - self.started > max(4.0, target_mm / 70.0 + 7.0):
            raise TimeoutError('straight travel timeout')
        error = self.start_heading - self._heading()
        correction = max(-self.HEADING_CORRECTION_LIMIT,
                         min(self.HEADING_CORRECTION_LIMIT, error * self.HEADING_KP))
        direction = -1 if reverse else 1
        base = direction * power
        # Match RunByGyro: right=power+course*turn, left=power-course*turn.
        self._motors(base - runtime.course * correction,
                     base + runtime.course * correction)
        return False

    def update(self):
        try:
            if self.stage == 'TRACE':
                traveled = self._distance() - self.start_mm
                if traveled < -8.0:
                    return self._fail("trace distance reversed")
                if traveled > self.TRACE_MAX_MM:
                    return self._fail('blue-to-black boundary not detected')
                h, s, v = runtime.color_sensor.get_raw_color_hsv()
                blue = SENSOR_BLUE_LINE.contains(h, s, v)
                black = SENSOR_BLACK_LINE.contains(h, s, v)
                self.blue_count = self.blue_count + 1 if blue else 0
                if self.blue_count >= self.COLOR_STABLE_FRAMES:
                    self.saw_blue = True
                self.black_count = self.black_count + 1 if self.saw_blue and black else 0
                if traveled >= self.TRACE_MIN_MM and self.black_count >= self.COLOR_STABLE_FRAMES:
                    self.trace.stop(Status.INVALID)
                    return self._advance('TRACE', 'STRAIGHT_250')
                self.trace.tick_once()
                if self.trace.status == Status.FAILURE:
                    return self._fail("line trace failed")
                return Status.RUNNING

            if self.stage == 'STRAIGHT_250':
                if self._straight(self.FIRST_STRAIGHT_MM, self.DRIVE_POWER):
                    return self._advance('STRAIGHT_250', 'LEFT_ARC')
                return Status.RUNNING

            if self.stage == 'LEFT_ARC':
                turned = self._heading() - self.start_heading
                target = float(runtime.course) * self.ARC_ANGLE_DEG
                if not math.isfinite(turned):
                    return self._fail("invalid gyro angle during arc")
                if (runtime.course * turned) >= (self.ARC_ANGLE_DEG - self.TURN_TOLERANCE_DEG):
                    return self._advance('LEFT_ARC', 'STRAIGHT_1100')
                if runtime.course * turned < -12.0:
                    return self._fail("arc gyro heading changed in wrong direction")
                if time.monotonic() - self.started > 12.0:
                    return self._fail('arc turn timeout')
                # Left wheel slower, right wheel faster => left arc.
                ratio = (self.ARC_RADIUS_MM - self.WHEEL_TREAD_MM / 2) / (self.ARC_RADIUS_MM + self.WHEEL_TREAD_MM / 2)
                if ratio <= 0:
                    return self._fail('arc radius must exceed half tread')
                self._motors(self.ARC_POWER * ratio, self.ARC_POWER)
                return Status.RUNNING

            if self.stage == 'STRAIGHT_1100':
                if self._straight(self.SECOND_STRAIGHT_MM, self.DRIVE_POWER):
                    if self.test_stop_after == 'STRAIGHT_1100':
                        return self._advance('STRAIGHT_1100', 'CAMERA')
                    self._enter('CAMERA')
                    self.session = runtime.video.begin_sumo_bottle_read()
                return Status.RUNNING

            if self.stage == 'CAMERA':
                self._stop()
                if time.monotonic() - self.started > self.CAMERA_TIMEOUT_SEC:
                    return self._fail('black bottle not found')
                session, frame_id, observation = runtime.video.get_bottle_observation()
                if session != self.session or frame_id <= self.last_frame_id:
                    return Status.RUNNING
                self.last_frame_id = frame_id
                insight, color, cx, theta, bottom, area, blind = observation
                valid = insight and color == BottleColor.BLACK and not blind and theta is not None and abs(float(theta)) <= self.CAMERA_MAX_ABS_THETA
                if not valid:
                    self.confirmed = 0
                    self.theta_values.clear()
                    return Status.RUNNING
                self.confirmed += 1
                self.theta_values.append(float(theta))
                if self.confirmed >= self.CAMERA_CONFIRM_FRAMES:
                    theta_avg = sum(self.theta_values) / len(self.theta_values)
                    bottle_bearing = (current_bearing(self.context) + theta_avg) % 360.0
                    raw = runtime.gyro_sensor.get_angle()
                    self.target_heading = self.context.sumo.bearing_reference.legacy_target(
                        bottle_bearing, raw, runtime.course)
                    self.logger.info("NEW SUMO aim theta=%.2f bearing=%.2f target_heading=%.2f",
                                     theta_avg, bottle_bearing, self.target_heading)
                    self._enter('AIM')
                return Status.RUNNING

            if self.stage == 'AIM':
                error = (self.target_heading - self._heading() + 180.0) % 360.0 - 180.0
                if abs(error) <= self.TURN_TOLERANCE_DEG:
                    self._enter('PUSH_60')
                    return Status.RUNNING
                if time.monotonic() - self.started > 7.0:
                    return self._fail('aim turn timeout')
                turn = self.TURN_POWER if error > 0 else -self.TURN_POWER
                # Match SpinAround: right=course*turn, left=-course*turn.
                self._motors(-runtime.course * turn, runtime.course * turn)
                return Status.RUNNING

            if self.stage == 'PUSH_60':
                if self._straight(self.PUSH_MM, self.PUSH_POWER):
                    self._enter('BACK_60')
                return Status.RUNNING

            if self.stage == 'BACK_60':
                if self._straight(self.BACK_MM, self.PUSH_POWER, reverse=True):
                    return self._advance('BACK_60', 'DONE')
                return Status.RUNNING

            if self.stage == 'DONE':
                self._stop()
                return Status.SUCCESS
            return self._fail('unknown stage')
        except Exception as exc:
            return self._fail(str(exc))

    def terminate(self, new_status):
        if self.trace is not None and self.trace.status == Status.RUNNING:
            self.trace.stop(Status.INVALID)
        self._stop()
