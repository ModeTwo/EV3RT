import json

with open("mirror_check_out.json", encoding="utf-8") as f:
    data = json.load(f)

CSS = """
  :root {
    --bg: #f3f4f1; --surface: #ffffff; --surface-alt: #eceeea;
    --ink: #1b232b; --ink-soft: #5b6570; --line: #d9ddd6;
    --accent: #3a6472; --good: #1f9d7c; --good-soft: #d9f1e9;
    --warn: #b8863a; --warn-soft: #f3e7d3;
    --shadow: rgba(24, 32, 36, 0.07);
    --font-head: "Yu Gothic UI", "Hiragino Sans", "Noto Sans JP", "Segoe UI", system-ui, sans-serif;
    --font-body: "Yu Gothic UI", "Hiragino Sans", "Noto Sans JP", "Segoe UI", system-ui, sans-serif;
    --font-mono: ui-monospace, "Cascadia Code", "SFMono-Regular", Consolas, "Noto Sans JP", monospace;
  }
  @media (prefers-color-scheme: dark) {
    :root:not([data-theme="light"]) {
      --bg: #10141a; --surface: #171c23; --surface-alt: #1e252d;
      --ink: #e7ebee; --ink-soft: #93a1ad; --line: #2b333d;
      --accent: #74b3c1; --good: #4fc79b; --good-soft: #163229;
      --warn: #d9ab6a; --warn-soft: #3a2f1a;
      --shadow: rgba(0, 0, 0, 0.45);
    }
  }
  :root[data-theme="dark"] {
    --bg: #10141a; --surface: #171c23; --surface-alt: #1e252d;
    --ink: #e7ebee; --ink-soft: #93a1ad; --line: #2b333d;
    --accent: #74b3c1; --good: #4fc79b; --good-soft: #163229;
    --warn: #d9ab6a; --warn-soft: #3a2f1a;
    --shadow: rgba(0, 0, 0, 0.45);
  }
  * { box-sizing: border-box; }
  body { margin: 0; background: var(--bg); color: var(--ink); font-family: var(--font-body); line-height: 1.6; padding: 2.5rem 1.25rem 4rem; }
  main { max-width: 1100px; margin: 0 auto; display: flex; flex-direction: column; gap: 1.6rem; }
  h1 { font-family: var(--font-head); font-size: clamp(1.4rem, 1.1rem + 1.2vw, 1.9rem); font-weight: 800; margin: 0; text-wrap: balance; }
  .subtitle { color: var(--ink-soft); font-size: 0.92rem; max-width: 78ch; }
  .subtitle code { font-family: var(--font-mono); background: var(--surface-alt); padding: 0.05em 0.4em; border-radius: 4px; font-size: 0.88em; }
  .note { background: var(--warn-soft); border: 1px solid var(--warn); border-radius: 10px; padding: 1rem 1.2rem; color: var(--ink); font-size: 0.92rem; }
  .note strong { color: var(--warn); }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.2rem; }
  .case { background: var(--surface); border: 1px solid var(--line); border-radius: 12px; padding: 1.2rem; box-shadow: 0 1px 3px var(--shadow); }
  .case.good { border-color: var(--good); }
  .case.warn { border-color: var(--warn); }
  .case h2 { margin: 0 0 0.4rem; font-size: 1.0rem; }
  .case p { color: var(--ink-soft); font-size: 0.85rem; margin: 0.2rem 0 0.7rem; }
  .diagram-frame { background: var(--surface-alt); border: 1px solid var(--line); border-radius: 8px; padding: 0.7rem; overflow-x: auto; }
  svg { display: block; width: 100%; height: auto; font-family: var(--font-body); }
  .course { fill: var(--surface-alt); stroke: var(--line); stroke-width: 0.4; }
  .griddot { fill: var(--ink-soft); opacity: 0.5; }
  .gateline { stroke: var(--ink-soft); stroke-width: 0.35; stroke-dasharray: 2 1.4; opacity: 0.7; }
  .validzone { stroke-width: 1.7; stroke-linecap: round; }
  .post { stroke: var(--surface); stroke-width: 0.3; }
  .gatelabel { font-size: 3.1px; font-weight: 700; }
  .pathline { stroke-width: 1.0; fill: none; stroke-linecap: round; }
  .waynode { fill: var(--ink-soft); opacity: 0.5; }
  .checkpoint { fill: var(--surface); stroke-width: 1.1; }
  .entrymark { fill: var(--surface); stroke-width: 0.6; }
  .exitmark { stroke: var(--surface); stroke-width: 0.35; }
  .cplabel { font-size: 2.7px; font-weight: 700; }
  .startnode { fill: var(--accent); }
  .goalnode { fill: var(--ink); }
  .terminallabel { fill: var(--surface); font-size: 2.7px; font-weight: 700; }
  .headingarrow { stroke: var(--ink); stroke-width: 0.5; }
  .headingarrow-fill { fill: var(--ink); }
"""

html = f"""<title>LEFT/RIGHT反転の検証</title>
<style>
{CSS}
</style>
<main>
  <header>
    <h1>course=rightの反転は「上下反転」だった</h1>
    <p class="subtitle">
      seed=9392783の経路で、3種類の変換を比較。<code>sample_comment.py</code>の
      <code>course=right</code>(=全旋回角の符号反転)が実際に作る図形と、
      「Y軸を境とした左右反転」で期待される図形が一致するかを目視確認する。
    </p>
  </header>

  <div class="note">
    <strong>結論:</strong> <code>START_HEADING_DEG=180°</code>(水平方向)が軸になっているため、
    全旋回角を符号反転する操作(<code>course=right</code>が実機で行っていること)は
    数学的に「スタート/ゴールを通る水平線」を軸にした<strong>上下反転</strong>になる。
    ご説明の「Y軸を境とした左右反転」(垂直線が軸)とは軸が異なる可能性が高い。
    実機のジャイロの符号規約が想定と逆であれば結果も変わりうるので、最終的には
    実機で数ステップ動かして確認するのが確実。
  </div>

  <div class="grid">
    <section class="case good">
      <h2>① 元(LEFT)</h2>
      <p>seed=9392783の経路そのまま。</p>
      <div class="diagram-frame">{data['left']['svg']}</div>
    </section>
    <section class="case warn">
      <h2>② course=rightが実際に作る図形(上下反転)</h2>
      <p>全target_heading_degの符号を反転した場合。y = 89.95(スタート/ゴールの高さ)を軸に上下反転。</p>
      <div class="diagram-frame">{data['mirror_h']['svg']}</div>
    </section>
    <section class="case">
      <h2>③ 「左右反転」のイメージ(参考)</h2>
      <p>グリッド中央列を軸に左右反転した場合(ご説明の「Y軸を境」に近いイメージ)。②とは別物。</p>
      <div class="diagram-frame">{data['mirror_v']['svg']}</div>
    </section>
  </div>
</main>
"""

with open("mirror_check.html", "w", encoding="utf-8") as f:
    f.write(html)
print("wrote", len(html), "bytes")
