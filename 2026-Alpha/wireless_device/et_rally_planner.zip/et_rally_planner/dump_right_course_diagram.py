import json

import config

MIRROR_AXIS_X_CM = 2 * config.GRID_PITCH_CM


def mirror_x(x_cm):
    return 2 * MIRROR_AXIS_X_CM - x_cm


def mirror_heading(heading_deg):
    return (180.0 - heading_deg) % 360.0


config.START_POS_CM = (mirror_x(config.START_POS_CM[0]), config.START_POS_CM[1])
config.GOAL_POS_CM = (mirror_x(config.GOAL_POS_CM[0]), config.GOAL_POS_CM[1])
config.START_HEADING_DEG = mirror_heading(config.START_HEADING_DEG)
config.GOAL_HEADING_DEG = mirror_heading(config.GOAL_HEADING_DEG)

import generate_diagram  # noqa: E402
import geometry as geo  # noqa: E402
from planner import Gate  # noqa: E402
from random_gates import random_gates  # noqa: E402
from rule_route import plan_route_with_anchors  # noqa: E402

SEED = 9392783
gates, seed = random_gates(SEED)


def mirror_gate(gate):
    def mirror_grid(pt):
        col, row = pt
        return (4 - col, row)

    return Gate(gate.color, mirror_grid(gate.foot_a_grid), mirror_grid(gate.foot_b_grid))


mirrored_gates = {c: mirror_gate(g) for c, g in gates.items()}

waypoints, anchors, labels, true_points = plan_route_with_anchors(mirrored_gates)
dist = sum(geo.distance(waypoints[i], waypoints[i + 1]) for i in range(len(waypoints) - 1))


def fake_plan(gates_arg, _wp=waypoints, _dist=dist, _lab=labels, _tp=true_points):
    return _wp, _dist, _lab, _tp


generate_diagram.plan_path_detailed = fake_plan
result = generate_diagram.main(gates=mirrored_gates, out_path="diagram_right_course.svg.txt")

with open("right_course_diagram_out.json", "w", encoding="utf-8") as f:
    json.dump({"svg": result["svg"]}, f, ensure_ascii=False)
print("done")
