"""RIGHTコース(LEFTコースをグリッド中央の列(col=2)を軸に左右反転したもの)用の
plan.jsonを書き出す。

course=right引数によるジャイロ符号反転(sample_comment.py)は、実際には
上下反転になってしまうことが判明したため(mirror_check.htmlで確認済み)、
代わりにこちらでゲート配置・スタート/ゴール位置そのものを正しく左右反転した
状態でrule_route.pyの経路計算をやり直し、実機ではcourse=left(反転なし)で
そのまま実行できるplan.jsonを作る。

config.START_POS_CM等はモジュール読み込み時に一度だけ評価されるデフォルト
引数として複数の関数(verify_pivot_safety, _route_turn_sum_deg,
waypoints_to_plan等)に使われているため、必ずconfigを書き換えてから
rule_route/commandsをimportすること(importの順序が重要)。
"""

import json
import sys

import config

# --- 左右反転(グリッド中央の列 col=2、つまり x = 2*GRID_PITCH_CM を軸) ---
MIRROR_AXIS_X_CM = 2 * config.GRID_PITCH_CM


def mirror_x(x_cm):
    return 2 * MIRROR_AXIS_X_CM - x_cm


def mirror_heading(heading_deg):
    return (180.0 - heading_deg) % 360.0


config.START_POS_CM = (mirror_x(config.START_POS_CM[0]), config.START_POS_CM[1])
config.GOAL_POS_CM = (mirror_x(config.GOAL_POS_CM[0]), config.GOAL_POS_CM[1])
config.START_HEADING_DEG = mirror_heading(config.START_HEADING_DEG)
config.GOAL_HEADING_DEG = mirror_heading(config.GOAL_HEADING_DEG)

# config書き換え後にimportすることで、上記の関数群のデフォルト引数が
# 反転後の値を正しく捉える
from commands import waypoints_to_plan  # noqa: E402
from planner import Gate  # noqa: E402
from random_gates import random_gates  # noqa: E402
from rule_route import (  # noqa: E402
    plan_route_with_anchors,
    verify_gate_crossing_directions,
    verify_pivot_safety,
    verify_straight_clearance,
)
import geometry as geo  # noqa: E402


def mirror_gate(gate):
    def mirror_grid(pt):
        col, row = pt
        return (4 - col, row)

    return Gate(gate.color, mirror_grid(gate.foot_a_grid), mirror_grid(gate.foot_b_grid))


def main():
    arg = sys.argv[1] if len(sys.argv) > 1 else None
    out_path = sys.argv[2] if len(sys.argv) > 2 else "plan_right.json"

    seed = int(arg) if arg is not None else None
    gates, used_seed = random_gates(seed)
    mirrored_gates = {color: mirror_gate(g) for color, g in gates.items()}

    print(f"LEFT gates : {{c: (g.foot_a_grid, g.foot_b_grid) for c, g in gates.items()}}")
    for c, g in gates.items():
        print(f"  LEFT  {c}: {g.foot_a_grid} - {g.foot_b_grid}")
    for c, g in mirrored_gates.items():
        print(f"  RIGHT {c}: {g.foot_a_grid} - {g.foot_b_grid}")

    waypoints, anchors, labels, true_points = plan_route_with_anchors(mirrored_gates)
    all_posts = [p for g in mirrored_gates.values() for p in g.posts()]

    pivot_v = verify_pivot_safety(waypoints, all_posts)
    straight_v = verify_straight_clearance(waypoints, all_posts, anchors)
    crossing_v = verify_gate_crossing_directions(waypoints, labels, list(mirrored_gates.values()))
    non_goal_pivot = [v for v in pivot_v if labels[v[0]] != "goal"]
    print(f"pivot={len(non_goal_pivot)} straight={len(straight_v)} crossing={len(crossing_v)}")

    total_dist_cm = sum(geo.distance(waypoints[i], waypoints[i + 1]) for i in range(len(waypoints) - 1))
    steps = waypoints_to_plan(waypoints, labels)

    move_count = sum(1 for s in steps if s["type"] == "move")
    turn_count = sum(1 for s in steps if s["type"] == "turn")

    out = {
        "gates": {
            "mode": "random",
            "seed": used_seed,
            "course": "right",
            "mirrored_from_left_grid": True,
        } | {c: {"a": g.foot_a_grid, "b": g.foot_b_grid} for c, g in mirrored_gates.items()},
        "heading_convention": (
            "target_heading_deg is absolute, shifted so that the plan's own start "
            "heading = 0deg. This file is pre-mirrored for the RIGHT course: run "
            "sample_comment.py with course=left (no further inversion needed)."
        ),
        "total_distance_mm": round(total_dist_cm * 10.0, 1),
        "move_count": move_count,
        "turn_count": turn_count,
        "steps": steps,
    }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"gates={out['gates']}")
    print(f"total_distance_mm={out['total_distance_mm']} move_count={move_count} turn_count={turn_count}")
    print(f"wrote {len(steps)} steps to {out_path}")


if __name__ == "__main__":
    main()
