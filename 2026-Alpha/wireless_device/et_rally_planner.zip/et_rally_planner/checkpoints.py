"""床の黒線・枠線を使った位置リセット用の「寄り道(probe)」を、計算済みの経路に後から挿入する。

背景(2026-09-20): 実機の走行誤差が周回ごとに数cmランダムに溜まる(置き方や係数の
調整では消えない)ため、床にプリントされた黒線(スタート/ゴールのX座標にある左右の
縦線、下側の枠線)に、カラーセンサーで実際に触れて、進行方向の座標を既知の値に
リセットする。

方式: ゲート退出後など「停止して旋回する」点で、直前の進行方向(軸に平行)のまま
黒線まで低速で直進→黒を検知→検知位置(既知の座標)から、あらかじめ計算した公称距離
だけ後退して元の点に戻る。旋回を増やさないので、旋回ごとのキャスターの引きずりは増えない。
補正できるのは進行方向の座標(Xかまたは Y)だけで、向きのズレは補正できない。

経路自体(rule_route.pyの結果)は変更しない。寄り道が支柱に近づく/ゲートの脚を横切る
場合は候補から除外する。1周につきX方向・Y方向それぞれ最大1回、距離が最短の候補だけ
挿入する。
"""

import math

import config
import geometry as geo
import rule_route


def _lap_of(label):
    if label and label.startswith("lap"):
        try:
            return int(label.split("-")[0][3:])
        except ValueError:
            return None
    return None


def _axis_heading(a, b, tol_deg=0.5):
    """a->bが軸に平行なら(dx符号, dy符号, 絶対方位deg)を返す。そうでなければNone。"""
    if geo.distance(a, b) < 1e-6:
        return None
    h = math.degrees(math.atan2(b[1] - a[1], b[0] - a[0]))
    for target in (0.0, 90.0, 180.0, -90.0, -180.0):
        if abs(geo.normalize_deg(h - target)) < tol_deg:
            t = round(target)
            if t == 0:
                return (1, 0, 0.0)
            if t == 90:
                return (0, 1, 90.0)
            if t in (180, -180):
                return (-1, 0, 180.0)
            return (0, -1, -90.0)
    return None


def _reference_lines():
    """床の基準線。X線はスタート/ゴールのX座標(右コースでは鏡像化済みのconfigが入る)。"""
    return [
        {"name": "start-line", "axis": "x", "value": config.START_POS_CM[0]},
        {"name": "goal-line", "axis": "x", "value": config.GOAL_LINE_X_CM},
        {"name": "bottom-border", "axis": "y", "value": config.BOTTOM_BORDER_Y_CM},
    ]


def _detect_pivot_coord(line, direction):
    """線を検知した瞬間の、旋回中心(pivot)の座標。カラーセンサーは車軸より前にある。"""
    ahead = config.COLOR_SENSOR_AHEAD_CM
    hw = config.LINE_HALF_WIDTH_CM
    if line["axis"] == "x":
        return line["value"] - direction * (hw + ahead)
    return line["value"] + ahead  # 下側の枠線(南向きのみ)、内側の縁で検知


def _probe_is_clear(a, b, gates_by_color):
    margin = rule_route.STRAIGHT_CLEARANCE_CM + config.PROBE_EXTRA_CLEARANCE_CM
    gates = list(gates_by_color.values())
    for g in gates:
        for post in g.posts():
            if rule_route._segment_post_distance(a, b, post) < margin:
                return False
        if rule_route._segment_crosses_gate_leg(a, b, g) is not None:
            return False
    return True


def find_reset_probes(waypoints, labels, gates_by_color):
    """{waypoint index: probe dict} を返す。probe dictのキー:
    axis("x"/"y")、line(基準線の名前)、heading_deg(絶対方位、内部の数学座標系)、
    nominal_cm(waypointから検知位置(pivot)までの距離)。
    """
    lines = _reference_lines()
    best = {}  # (lap, axis) -> (nominal_cm, index, probe)
    seen_exit = False
    lap = None
    for i in range(1, len(waypoints) - 1):
        l = _lap_of(labels[i])
        if l is not None:
            lap = l
        if labels[i] and labels[i].endswith("-exit"):
            seen_exit = True
        if not seen_exit or lap is None:
            continue

        inc = _axis_heading(waypoints[i - 1], waypoints[i])
        if inc is None:
            continue
        nxt = _axis_heading(waypoints[i], waypoints[i + 1])
        # 次の区間も同じ向きに続くなら停止点ではない(旋回しない)ので候補にしない。
        if nxt is not None and nxt[2] == inc[2]:
            continue
        if nxt is None and abs(geo.normalize_deg(
                math.degrees(math.atan2(waypoints[i + 1][1] - waypoints[i][1],
                                        waypoints[i + 1][0] - waypoints[i][0])) - inc[2])) < 1.0:
            continue

        dx, dy, heading = inc
        wp = waypoints[i]
        for line in lines:
            if line["axis"] == "x":
                if dx == 0:
                    continue
                direction = dx
                detect = _detect_pivot_coord(line, direction)
                d = (detect - wp[0]) * direction
                end = (detect, wp[1])
            else:
                if dy != -1:
                    continue
                detect = _detect_pivot_coord(line, -1)
                d = wp[1] - detect
                end = (wp[0], detect)
            if not (config.PROBE_MIN_DISTANCE_CM <= d <= config.PROBE_MAX_DISTANCE_CM):
                continue
            if not _probe_is_clear(wp, end, gates_by_color):
                continue
            key = (lap, line["axis"])
            if key not in best or d < best[key][0]:
                best[key] = (d, i, {
                    "axis": line["axis"],
                    "line": line["name"],
                    "heading_deg": heading,
                    "nominal_cm": d,
                })
    return {idx: probe for (_, idx, probe) in best.values()}
