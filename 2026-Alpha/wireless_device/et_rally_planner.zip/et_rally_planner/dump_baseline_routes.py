import hashlib
import json
import sys

import rule_route
from random_gates import random_gates

out_path = sys.argv[1] if len(sys.argv) > 1 else "baseline_routes.json"

import random

seed_sets = []
seed_sets.append(("v1", [i * 7919 + 1 for i in range(200)]))

# v2: i=200..399 with same formula as v1 (i*7919+1)
seed_sets.append(("v2", [i * 7919 + 1 for i in range(200, 400)]))

# v3: independent random.Random(999999)
rng3 = random.Random(999999)
seed_sets.append(("v3", [rng3.randint(1, 10_000_000) for _ in range(200)]))

results = {}
count = 0
for tag, seeds in seed_sets:
    for s in seeds:
        gates, seed = random_gates(s)
        waypoints, anchors, labels, true_points = rule_route.plan_route_with_anchors(gates)
        # round to avoid float printing noise, but keep enough precision to catch real changes
        rounded = [[round(x, 9), round(y, 9)] for x, y in waypoints]
        key = f"{tag}:{seed}"
        results[key] = {
            "labels": labels,
            "waypoints": rounded,
        }
        count += 1

blob = json.dumps(results, sort_keys=True, ensure_ascii=False)
digest = hashlib.sha256(blob.encode("utf-8")).hexdigest()

with open(out_path, "w", encoding="utf-8") as f:
    json.dump({"digest": digest, "count": count, "results": results}, f, ensure_ascii=False, indent=1)

print(f"saved {count} routes to {out_path}")
print("digest:", digest)
