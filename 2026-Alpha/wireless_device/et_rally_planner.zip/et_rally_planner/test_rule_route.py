import math
import time

import config
import geometry as geo
from commands import waypoints_to_commands
from random_gates import parse_gate_spec, validate_gate_orientation
from rule_route import plan_route, verify_pivot_safety


def side_of_line(p, line_point, line_dir):
    v = geo.sub(p, line_point)
    cross = line_dir[0] * v[1] - line_dir[1] * v[0]
    if cross > 1e-9:
        return 1
    if cross < -1e-9:
        return -1
    return 0


def verify_crossings(gates, true_points, labels):
    ok = True
    for i, lab in enumerate(labels):
        if lab is None or not lab.endswith("-entry"):
            continue
        lap_n, color, _ = lab.split("-")
        gate = gates[color]
        entry_pt, exit_pt = true_points[i], true_points[i + 1]
        s1 = side_of_line(entry_pt, gate.foot_a, gate.direction)
        s2 = side_of_line(exit_pt, gate.foot_a, gate.direction)
        crossed = s1 != 0 and s2 != 0 and s1 != s2
        if not crossed:
            ok = False
            print(f"  [NG-CROSS] {lap_n} {color}: entry={entry_pt} exit={exit_pt} side {s1}->{s2}")
    return ok


def main(spec):
    gates = parse_gate_spec(spec)
    validate_gate_orientation(gates)
    all_posts = [p for g in gates.values() for p in g.posts()]

    t0 = time.time()
    waypoints, total_dist_cm, labels, true_points = plan_route(gates)
    t1 = time.time()

    ok1 = verify_crossings(gates, true_points, labels)
    violations = verify_pivot_safety(waypoints, all_posts)

    print(f"spec={spec}")
    print(f"waypoints={len(waypoints)} total_dist_cm={total_dist_cm:.1f} time={t1-t0:.3f}s")
    print(f"全ゲート通過が反対側まで抜けている: {'YES' if ok1 else 'NO'}")
    print(f"旋回安全性違反: {len(violations)}件")
    for idx, pt, turn in violations:
        print(f"  [NG-PIVOT] i={idx} point={pt} turn={turn:.1f}deg label={labels[idx]}")

    commands = waypoints_to_commands(waypoints)
    move_count = sum(1 for c, _ in commands if c == "move")
    turn_count = sum(1 for c, _ in commands if c == "turn")
    turn_sum = sum(abs(v) for c, v in commands if c == "turn")
    print(f"move={move_count} turn={turn_count} turn_sum_deg={turn_sum:.1f}")

    for i, (p, lab) in enumerate(zip(waypoints, labels)):
        print(f"  {i:2d} {lab!s:20s} {p}")


if __name__ == "__main__":
    import sys
    spec = sys.argv[1] if len(sys.argv) > 1 else "red:1,1-2,1;blue:4,3-4,4;yellow:0,2-1,2"
    verbose = len(sys.argv) > 2 and sys.argv[2] == "-v"
    if verbose:
        main(spec)
    else:
        import io
        import contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            main(spec)
        lines = buf.getvalue().splitlines()
        for line in lines:
            if line.startswith("spec=") or "waypoints=" in line or "全ゲート" in line or "旋回安全性" in line or line.startswith("move="):
                print(line)
