import json, sys
import generate_diagram
import geometry as geo
import rule_route
from random_gates import random_gates
seed=int(sys.argv[1]); laps=int(sys.argv[2]) if len(sys.argv)>2 else 2
gates,_=random_gates(seed)
wps,anc,labels,tp=rule_route.plan_route_with_anchors(gates,laps)
dist=sum(geo.distance(wps[i],wps[i+1]) for i in range(len(wps)-1))
def fake(g,_w=wps,_d=dist,_l=labels,_t=tp): return _w,_d,_l,_t
generate_diagram.plan_path_detailed=fake
r=generate_diagram.main(gates=gates,out_path=f"diagram_seed{seed}.svg.txt")
json.dump([{"idx":0,"seed":seed,"total_dist_cm":r["total_dist_cm"],"ok":True,"svg":r["svg"]}],open(f"gallery_seed{seed}_out.json","w",encoding="utf-8"),ensure_ascii=False)
print("gates",{c:(g.foot_a_grid,g.foot_b_grid) for c,g in gates.items()})
for k,l in enumerate(labels): print(k,l,[round(v,1) for v in wps[k]])
