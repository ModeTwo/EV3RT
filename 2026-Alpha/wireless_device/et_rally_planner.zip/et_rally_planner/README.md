# ETラリー 経路計画ツール

赤→青→黄の順に3周ぶんゲートを通過し、ゴールで停止するまでの走行経路を、
コース上のゲート配置から自動計算するツール。実機の`move()`/`turn()`コマンド列、
または絶対方位ベースの制御部品(`RunByGyro`/`SpinAround`)向けのJSONを出力する。

## 全体の流れ(パイプライン)

```
ゲート配置(グリッド座標)
   │  Gate(planner.py)
   ▼
ルールベースの経路構築    plan_route_with_anchors() … rule_route.py
   │  (entry/exit・迂回点・旋回安全性チェックまで含めて1本の経路を組み立てる)
   ▼
waypoints(頂点座標列)     plan_route()            … rule_route.py
   │
   ├─→ move/turnコマンド列   waypoints_to_commands() … commands.py
   ├─→ 絶対方位ベースJSON     waypoints_to_plan()     … commands.py
   └─→ SVG図                generate_diagram.py
```

`export_plan.py`(実機投入用JSON)・`generate_diagram.py`(SVG図)・
`run_random.py`(動作確認CLI)は、いずれも`rule_route.plan_route`を
`plan_path_detailed`という名前で読み込んで呼んでいる(過去に別方式
[planner.pyの可視グラフ+Dijkstra]から現行方式へ切り替えた際、呼び出し側の
コードは変えずに済むよう、返り値の形式`(waypoints, total_dist_cm, labels,
true_points)`をそろえてある)。

## ファイル一覧

### 経路計算のコア

| ファイル | 役割 |
|---|---|
| `config.py` | コース・ロボットの物理定数、探索パラメータをまとめた設定ファイル。まず最初に読むと全体像がつかみやすい。 |
| `geometry.py` | 2Dベクトル演算・角度計算などの汎用ユーティリティ。 |
| `planner.py` | `Gate`クラス(ゲート形状)、`build_stage_sequence`(周回順序)、`pivot_turn_safe`(その場旋回の安全判定)など、rule_route.pyからも使われる共通部品を持つ。あわせて、現在は本番では使われていない旧方式(可視グラフ+Dijkstra、`build_graph`/`dijkstra_with_turns`/`plan_path_detailed`)も参考用に残っている(詳細はファイル先頭のコメント参照)。 |
| `rule_route.py` | **現行の経路計算の本体。** ゲート通過は常に中心を垂直に通る、というルールから出発し、支柱への接触・旋回の安全性・ゲートへの一方向侵入ルールを満たす経路を構築する。設計の詳細はファイル先頭のコメント、および本READMEの次章を参照。 |
| `commands.py` | `rule_route.py`が返す頂点座標列(waypoints)を、実機に渡す形式(相対turn/move、または絶対方位ベースのJSON用ステップ列)に変換する。 |
| `random_gates.py` | 大会規定を満たすゲート配置をランダム生成 / 文字列からの直接指定 / 向きの妥当性チェック。 |

### 実行スクリプト(CLI)

| ファイル | 役割 | 実行例 |
|---|---|---|
| `run_random.py` | 経路計算を1回実行し、検証結果・統計・SVG図を出力する動作確認用スクリプト。 | `python3 run_random.py 199055`<br>`python3 run_random.py "red:0,0-1,0;blue:2,1-2,2;yellow:1,3-2,3"` |
| `export_plan.py` | 実機投入用のJSON(`plan.json`)を書き出す。引数の指定方法は`run_random.py`と同じ。 | `python3 export_plan.py 199055 plan.json` |
| `generate_diagram.py` | 経路をSVG図として書き出す(`run_random.py`から内部的にも呼ばれる)。 | `python3 generate_diagram.py` |

### テスト・検証ツール

| ファイル | 役割 |
|---|---|
| `test_rule_route.py` | 手動指定した1パターンのゲート配置で経路を計算し、全ゲート通過・旋回安全性を確認する。`verify_crossings()`は他の検証スクリプトからも再利用される。 |
| `stress_test_gate_crossing.py` / `_v2.py` / `_v3.py` | それぞれ独立した200件・計600件のランダムなゲート配置で経路を計算し、直進クリアランス・旋回安全性・ゲート通過方向のいずれの違反もないことを検証する回帰テスト。`rule_route.py`を変更した際は、この3つを実行して全て200/200であることを必ず確認する。 |
| `dump_baseline_routes.py` | 上記3バッチ計600件について、経路(waypoints)そのものをJSONに保存しSHA256ダイジェストを出す。挙動を変えないはずの変更(コメント整理・ロジック統合など)の前後で実行し、ダイジェストが完全一致することを「経路が1つも変わっていない」証拠として使う。 |
| `dump_gallery_50.py` + `build_gallery_page.py` | ランダムな50件の経路図をまとめてHTML1枚に並べる(目視レビュー用)。`dump_gallery_50.py`の`rng = random.Random(...)`のシード値を変えれば毎回別の50件を生成できる。 |

## 経路計算の考え方(rule_route.py)

### 1. ロボットの動き方のモデル

ロボットは「直線移動」と「その場旋回(タイヤ位置を中心に、その場で好きな角度だけ回る)」
の組み合わせだけで動く前提。旋回は頂点の上でだけ起き、区間の移動中は常に直進。

タイヤ(=旋回の中心)は車体の幾何中心ではなく、前端から7.5cmの位置にある
(`config.ROBOT_FRONT_OVERHANG_CM`)。そのため前後で旋回半径が非対称になる。

### 2. ゲート通過の表現(常に中心を垂直に)

ゲート通過は、角度をつけたり中心からずらしたりする候補探索は行わず、常に
「ゲートの中心を通り、ゲートに垂直」に固定する(`gate_entry_exit`)。

- **entry(進入完了点)**: ゲート中心から、進入側の法線方向に前方オーバーハング
  (7.5cm)だけ離れた点(車体前端が中心に重なる位置)
- **exit(退出完了点)**: 中心から反対方向に後方オーバーハング(18cm)だけ
  離れた点(車体後端が中心に重なる位置)

entry→exitを必ず直進で結ぶ強制区間として経路に組み込むことで、「ロボット
全体が線の反対側まで抜けた」ことが経路の構造そのもので保証される。

### 3. 迂回の作り方

2点を直進で結ぶ線が支柱にぶつかる場合、2通りの方式を試して短い方を採用する。

- **長方形オフセット方式**(`resolve_segment`): ぶつかった支柱から、その支柱が
  属するゲートの法線方向にオフセットした「手前の侵入ポイント」を経由する。
  まだ別の支柱にぶつかる場合は同じ処理を再帰的に適用する。
- **軸方向延長方式**(`_resolve_segment_via_parallel_extension`): 直前に通過した
  ゲートの向き(またはスタート地点なら東西・南北の両方)に沿って少しずつ
  直進を延長し、そこから先が支柱にもゲートの脚にもぶつからなくなる点を探す。

さらに、ステージ間をつなぐ最上位区間(`_resolve_top_level_segment`)では、
上記2方式に加えて「別のゲートを正式なentry/exitで経由してから向かう」候補
(`_resolve_via_other_gate`)も常に試し、旋回安全性・直進クリアランス・
ゲートの脚への意図しない接触のいずれも起きない候補の中から最短のものを選ぶ。

### 4. ゲートへの一方向侵入ルール

同じゲートは3周とも必ず同じ向きから通過し(`gate_signs`)、無関係な区間
(別ゲートへ向かう途中の迂回など)がそのゲートの脚を結ぶ線を斜めに掠めたり
逆向きに横切ったりすることは一切許可しない(`_candidate_crossing_safe`、
`_fix_gate_crossings`)。目的のゲート以外を横切る場合も、必ずそのゲート自身の
中心を垂直に通る正式なentry/exitの形でなければならない。

### 5. 旋回の安全性判定(角度依存)

その場旋回で車体の隅が実際に振れるのは、旋回前の向きから旋回後の向きまでの
弧の部分だけ(`planner.pivot_turn_safe`)。単純な距離だけで判定すると、
支柱同士が近いゲート配置で通過候補が全滅する不具合が実際にあったため、
「支柱までの距離」と「実際に曲がる角度の範囲(弧)の中に支柱があるか」の
両方を見る。

`rule_route.py`は、経路構築の各段階でこの判定を使う:
候補選定時(entry到達時・出発時・経路中の各点・ゴール到着時、いずれも
`_resolve_top_level_segment`内の各種`*_pivot_safe`関数)と、それでも
残った違反の事後修正(`_fix_pivot_violations`)。

### 6. 8通りの侵入方向を全探索

赤・青・黄それぞれ、ゲートに「表裏」がないため+1/-1の2通りの侵入方向が
あり、3ゲートで2³=8通りの組み合わせがある。`plan_route_with_anchors`は
8通り全てで経路を組み立て、直進クリアランス・旋回安全性・ゲート通過方向の
いずれの違反もない候補の中から、総移動距離+旋回角合計×重みが最小のものを
選ぶ。

### 7. 出力形式

`plan_route()`が返す`waypoints`(頂点座標のリスト、cm単位)を、用途に応じて
2通りの形式に変換できる。

- `waypoints_to_commands()`: 直前の向きからの相対的な`turn(角度deg)`/`move(距離mm)`
  コマンド列。誤差が後続区間に蓄積しやすい。
- `waypoints_to_plan()`: 各区間の絶対方位(スタート時点を0度とする)を持つ
  ステップ列。実機の`RunByGyro`/`SpinAround`(`target_type=ABSOLUTE`)に
  そのまま渡せる形式で、誤差が蓄積しない(`export_plan.py`が書き出すJSONの実体)。

## 実機への組み込み

`C:\Users\MSAD\Desktop\EV3RT-master\2026base\sample_comment.py`に、
`export_plan.py`が書き出すJSON(`plan.json`)を読み込んでビヘイビアツリーの
部品列に変換する`steps_from_plan()`と、それを使った専用ツリーを組み立てる
`build_et_rally_tree()`を追加済み。

移動区間は`Parallel(RunByGyro + IsDistanceEarned)`、旋回区間は`SpinAround`
という、既存の`gyro_demo.py`の"square"サンプルと同じ組み合わせ方をしている。

**注意:** JSON内の方位が増える向き(右回りか左回りか)が実機のジャイロ配線と
一致しているかは、実際に動かして確認する必要がある(未検証)。逆だった場合は
`plan.json`内の全`target_heading_deg`の符号を反転すれば直る。
