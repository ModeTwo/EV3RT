"""ランダムなゲート配置を生成する(大会規定通り: 赤・黄は横向き、青は縦向き)。"""

import random

from planner import Gate

GATE_ORIENTATION = {"red": "horizontal", "blue": "vertical", "yellow": "horizontal"}


def random_gates(seed=None):
    """大会規定(赤・黄=横向き、青=縦向き)を満たすランダムなゲート配置を1つ生成する。

    seedを指定すると同じ配置を再現できる(省略時はランダムに1つ選んでその値も返す)。
    戻り値: ({"red": Gate, "blue": Gate, "yellow": Gate}, 実際に使ったseed)
    """
    if seed is None:
        seed = random.randint(0, 999999)
    rng = random.Random(seed)  # このシード専用の乱数生成器(グローバルなrandomの状態を汚さない)

    def vertical():
        """5x5グリッド内で、上下に隣接する2マスの組をランダムに1つ選ぶ(縦向きゲート用)。"""
        col = rng.randint(0, 4)
        row = rng.randint(0, 3)  # +1したマスも範囲内に収まるよう0..3までにする
        return (col, row), (col, row + 1)

    def horizontal():
        """5x5グリッド内で、左右に隣接する2マスの組をランダムに1つ選ぶ(横向きゲート用)。"""
        row = rng.randint(0, 4)
        col = rng.randint(0, 3)
        return (col, row), (col + 1, row)

    # 3ゲート・6本の脚がどれも同じマスに重ならないものが出るまで引き直す
    # (同じマスに2本の脚が重なると、ゲート同士が干渉して物理的に成立しないため)。
    while True:
        red_a, red_b = horizontal()
        blue_a, blue_b = vertical()
        yellow_a, yellow_b = horizontal()
        feet = {red_a, red_b, blue_a, blue_b, yellow_a, yellow_b}
        if len(feet) == 6:  # 6本の脚がすべて別の位置(重複なし)
            break

    return {
        "red": Gate("red", red_a, red_b),
        "blue": Gate("blue", blue_a, blue_b),
        "yellow": Gate("yellow", yellow_a, yellow_b),
    }, seed


def parse_gate_spec(spec):
    """"red:0,0-1,0;blue:2,1-2,2;yellow:1,3-2,3" 形式の文字列からゲート辞書を作る。

    色ごとに "色名:col,row-col,row" をセミコロンで区切って指定する
    (大文字小文字は区別しない、空白は無視)。赤・青・黄の3色すべてが
    必要。
    """
    gates = {}
    for part in spec.split(";"):
        part = part.strip()
        if not part:
            continue
        try:
            color, coords = part.split(":")
            a_str, b_str = coords.split("-")
            a = tuple(int(v) for v in a_str.split(","))
            b = tuple(int(v) for v in b_str.split(","))
        except ValueError as e:
            raise ValueError(
                f"ゲート指定を解析できません: {part!r} "
                f'(期待する形式: "red:0,0-1,0;blue:2,1-2,2;yellow:1,3-2,3")'
            ) from e
        color = color.strip().lower()
        if color not in ("red", "blue", "yellow"):
            raise ValueError(f"不明なゲート色です: {color!r}")
        if len(a) != 2 or len(b) != 2:
            raise ValueError(f"座標はcol,rowの2値で指定してください: {part!r}")
        gates[color] = Gate(color, a, b)

    missing = {"red", "blue", "yellow"} - set(gates)
    if missing:
        raise ValueError(f"ゲート情報が不足しています: {sorted(missing)}")
    return gates


def validate_gate_orientation(gates):
    """大会規定の向き(赤・黄は横向き=行が同じ、青は縦向き=列が同じ)を満たしているか確認する。"""
    errors = []
    for color, orientation in GATE_ORIENTATION.items():
        a, b = gates[color].foot_a_grid, gates[color].foot_b_grid
        if orientation == "horizontal" and a[1] != b[1]:
            errors.append(f"{color}ゲートは横向き(2脚の行が同じ)である必要があります: {a}-{b}")
        elif orientation == "vertical" and a[0] != b[0]:
            errors.append(f"{color}ゲートは縦向き(2脚の列が同じ)である必要があります: {a}-{b}")
    if errors:
        raise ValueError("\n".join(errors))


if __name__ == "__main__":
    import sys

    seed = int(sys.argv[1]) if len(sys.argv) > 1 else random.randint(0, 999999)
    gates, used_seed = random_gates(seed)
    print(f"seed={used_seed}")
    for color, gate in gates.items():
        print(f"  {color}: {gate.foot_a_grid} - {gate.foot_b_grid}")
