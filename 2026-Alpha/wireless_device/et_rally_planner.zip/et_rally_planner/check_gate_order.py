"""競技規約5.17.3の「赤→青→黄の順番を守らないと1周として成立しない、
同色連続は1回とみなす」ルールに従って、実際に何周ぶん成立するかを
rule_route.verify_gate_passage_order()でシミュレートする。

2026-09-15: 以前はここに専用の(古い、隣接ペアのみを見る)ロジックを
複製して持っていたが、_build_route_with_signsに「複数ゲートのentry/exitが
同一直線上に並ぶ場合、間の停止点を経由せず1本の直進としてつなぐ」
最適化を追加したことで、この専用ロジックだけが非隣接の正式通過を
見逃すようになった(rule_route.verify_gate_passage_order側は
_maximal_collinear_runsで対応済み)。二重管理を避けるため、
rule_route側の実装をそのまま使うように変更した。
"""
import rule_route


def check_seed(seed_val):
    from random_gates import random_gates
    gates, seed = random_gates(seed_val)
    all_gates = list(gates.values())
    waypoints, anchors, labels, true_points = rule_route.plan_route_with_anchors(gates)
    laps = rule_route.verify_gate_passage_order(waypoints, all_gates)
    return seed, laps, None


if __name__ == "__main__":
    import sys
    # 2026-09-15: 開発中の簡易チェックは200件に短縮(600件のフル確認は
    # 最終段階でのみ実施する運用のため)。stress_test_gate_crossing.py
    # (1本目、200件)と同じseed列を使う。
    seed_sets = [i * 7919 + 1 for i in range(200)]

    bad = []
    for i, s in enumerate(seed_sets):
        seed, laps, seq = check_seed(s)
        if laps < 3:
            bad.append((seed, laps, seq))
        if i % 100 == 0:
            print(f"...progress {i}/{len(seed_sets)}", flush=True)

    print(f"\ntotal={len(seed_sets)} bad(<3 laps)={len(bad)}")
    for seed, laps, seq in bad[:30]:
        print(f"seed={seed} laps={laps} seq={seq}")
