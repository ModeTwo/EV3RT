"""T字パーツに垂直に近づいて3cm未満になる区間(ゲートに入る手前、そのゲート自身のT字パーツ)の
実例を、経路図に重ねて表示する(2026-09-20)。"""
import json, math, re
import config, geometry as geo, rule_route as rr
import generate_diagram
from random_gates import random_gates

SEEDS = [9805622, 9655436, 3847588, 4485989, 5238729, 9167215]
LAPS = 2
HALF_W = config.ROBOT_HALF_WIDTH_CM
FRONT = config.ROBOT_FRONT_OVERHANG_CM
REAR = config.ROBOT_REAR_OVERHANG_CM
ARM = config.POST_PIVOT_ARM_HALF_LENGTH_CM

def find_cases(gates, wps, labels):
    cases = []
    last_exit = 0
    for i, l in enumerate(labels):
        if l and l.endswith("-exit"):
            last_exit = i
        if l and l.endswith("-entry"):
            col = l.split("-")[1]
            g = gates[col]
            for k in range(last_exit + 1 if last_exit else 1, i + 1):
                a, b = wps[k - 1], wps[k]
                dl = geo.distance(a, b)
                if dl < 1e-6:
                    continue
                d = geo.scale(geo.sub(b, a), 1 / dl)
                worst = None
                for p in g.posts():
                    if not (p.arm_dir[0] or p.arm_dir[1]):
                        continue
                    dp = abs(d[0] * p.arm_dir[0] + d[1] * p.arm_dir[1])
                    c = rr._segment_body_clearance(a, b, p)
                    if dp < 0.02 and c < 3.0:
                        tiny = geo.add(a, geo.scale(d, 0.01))
                        c0 = rr._segment_body_clearance(a, tiny, p)
                        cases.append(dict(entry=l, k=k, a=a, b=b, d=d, post=p, clr=c, start_clr=c0, gate=col))
    return cases

def overlay(svg, gates, wps, cases):
    posts = [p for g in gates.values() for p in g.posts()]
    pts = [config.START_POS_CM, config.GOAL_POS_CM] + posts + list(wps)
    pad = 16.0
    x_min = min(p[0] for p in pts) - pad
    y_max = max(p[1] for p in pts) + pad
    sx = lambda x: x - x_min
    sy = lambda y: y_max - y
    out = []
    shown = set()
    for c in cases:
        a, b, d, p = c["a"], c["b"], c["d"], c["post"]
        key = (c["k"],)
        if key not in shown:
            shown.add(key)
            # problem segment
            out.append(f'<line x1="{sx(a[0]):.2f}" y1="{sy(a[1]):.2f}" x2="{sx(b[0]):.2f}" y2="{sy(b[1]):.2f}" stroke="#e5484d" stroke-width="1.6" stroke-linecap="round" opacity="0.9"/>')
            # robot footprint at the segment start pose (rear..front)
            n = (-d[1], d[0])
            def P(t, w):
                q = geo.add(geo.add(a, geo.scale(d, t)), geo.scale(n, w))
                return f'{sx(q[0]):.2f},{sy(q[1]):.2f}'
            poly = " ".join([P(-REAR, HALF_W), P(FRONT, HALF_W), P(FRONT, -HALF_W), P(-REAR, -HALF_W)])
            out.append(f'<polygon points="{poly}" fill="#e5484d" fill-opacity="0.12" stroke="#e5484d" stroke-width="0.35" stroke-dasharray="1.2 0.8"/>')
            out.append(f'<circle cx="{sx(a[0]):.2f}" cy="{sy(a[1]):.2f}" r="1.1" fill="#e5484d"/>')
        # T-arm of the involved post
        ax, ay = p[0], p[1]
        e1 = (ax - p.arm_dir[0] * ARM, ay - p.arm_dir[1] * ARM)
        e2 = (ax + p.arm_dir[0] * ARM, ay + p.arm_dir[1] * ARM)
        out.append(f'<line x1="{sx(e1[0]):.2f}" y1="{sy(e1[1]):.2f}" x2="{sx(e2[0]):.2f}" y2="{sy(e2[1]):.2f}" stroke="#f5a524" stroke-width="1.4" stroke-linecap="round"/>')
        # label
        mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
        out.append(f'<text x="{sx(ax)+2:.2f}" y="{sy(ay)-2:.2f}" font-size="3.6" font-weight="700" fill="#e5484d">{c["clr"]:.2f}cm</text>')
    return svg.replace("</svg>", "\n".join(out) + "\n</svg>")

cards = []
for seed in SEEDS:
    gates, _ = random_gates(seed)
    wps, anc, labels, tp = rr.plan_route_with_anchors(gates, LAPS)
    dist = sum(geo.distance(wps[i], wps[i + 1]) for i in range(len(wps) - 1))
    def fake(g, _w=wps, _d=dist, _l=labels, _t=tp):
        return _w, _d, _l, _t
    generate_diagram.plan_path_detailed = fake
    r = generate_diagram.main(gates=gates, out_path=f"diagram_armcase_{seed}.svg.txt")
    cases = find_cases(gates, wps, labels)
    if cases:
        first_lap = min(c["entry"].split("-")[0] for c in cases)
        cases = [c for c in cases if c["entry"].startswith(first_lap)]
    svg = overlay(r["svg"], gates, wps, cases)
    lap1 = cases
    segs = {}
    for c in lap1:
        segs.setdefault(c["k"], []).append(c)
    notes = []
    for k, cs in segs.items():
        starts_bad = any(x["start_clr"] < 3.0 for x in cs)
        c0 = cs[0]
        notes.append(
            f'{c0["entry"]} 手前 / 区間 ({c0["a"][0]:.1f},{c0["a"][1]:.1f})→({c0["b"][0]:.1f},{c0["b"][1]:.1f}) / 最小 {min(x["clr"] for x in cs):.2f}cm / '
            + ("<b>区間の出発点に立った時点で既に近い(この区間を動かしても直らない)</b>" if starts_bad else "出発点の姿勢は3cm以上ある(この区間を動かせば直る可能性あり)"))
    cards.append((seed, {c: (g.foot_a_grid, g.foot_b_grid) for c, g in gates.items()}, dist, notes, svg))

src = open("build_gallery_goal_moved_30.py", encoding="utf-8").read()
head = src[:src.index('cards = []')]
head = head.replace("gallery_goal_moved_30_out.json", "x").replace("ゴール移動後の経路30件(2周)", "T字パーツに近づく実例(2周・左コース)")
# take HEAD/TAIL strings by exec'ing the top part without data loading
ns = {}
code = src[:src.index('cards = []')]
code = code.replace('with open("gallery_goal_moved_30_out.json", encoding="utf-8") as f:\n    data = json.load(f)', 'data = []')
exec(code, ns)
HEAD, TAIL = ns["HEAD"], ns["TAIL"]
HEAD = re.sub(r"<title>.*?</title>", "<title>T字パーツに近づく実例</title>", HEAD)
i = HEAD.index('<p class="subtitle">'); j = HEAD.index('</p>', i) + 4
HEAD = HEAD[:i] + ('<p class="subtitle">ゲートに入る手前で、そのゲート自身のT字パーツに<b>垂直に</b>近づき、車体(前方)から3cm未満になる実例(60シード中、6シードを抜粋。各シードで最初に出る周を表示)。'
    '赤の線=近すぎる区間、赤の点線の長方形=その区間の出発点に立った車体(後方17.5cm、前方7.5cm、幅13.7cm)、橙の線=T字パーツ(支柱から±4cm)、数字=車体の前方からT字パーツまでの距離。'
    '灰=1周目、紫=2周目、Gがゴール。</p>') + HEAD[j:]
H1 = re.sub(r"<h1>.*?</h1>", "<h1>T字パーツに近づく実例</h1>", HEAD)
cards_html = []
for seed, gt, dist, notes, svg in cards:
    gd = " / ".join(f"{c}:{a}-{b}" for c, (a, b) in gt.items())
    nt = "".join(f'<div style="font-size:0.74rem;color:var(--ink-soft);line-height:1.5">・{n}</div>' for n in notes)
    cards_html.append(f'''    <div class="card bad">
      <div class="card-head"><b>seed={seed}</b><span class="badge bad">{dist:.0f}cm</span></div>
      <div style="font-size:0.7rem;color:var(--ink-soft)">{gd}</div>
      <div class="diagram-frame">
{svg}
      </div>
      {nt}
    </div>''')
open("gallery_arm_cases_page.html", "w", encoding="utf-8").write(H1 + "\n".join(cards_html) + TAIL)
print("saved", len(cards))
for seed, gt, dist, notes, svg in cards:
    print(seed, gt); [print("  ", n) for n in notes]
