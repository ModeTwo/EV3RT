"""ゴール地点を(X+58cm, Y-115cm)に移動した状態で、ランダム30件の経路を生成する(2周)。"""
import json
import random

import generate_diagram
import geometry as geo
import rule_route
from rule_route import verify_pivot_safety, verify_straight_clearance, verify_gate_crossing_directions
from random_gates import random_gates
from test_rule_route import verify_crossings

N = 30
LAPS = 2
rng = random.Random(20260920)
seeds = [rng.randint(1, 10_000_000) for _ in range(N)]

results = []
for k, s in enumerate(seeds):
    gates, seed = random_gates(s)
    all_gates = list(gates.values())
    all_posts = [p for g in gates.values() for p in g.posts()]
    try:
        waypoints, anchors, labels, true_points = rule_route.plan_route_with_anchors(gates, LAPS)
    except Exception as e:
        print(f"{k:2d} seed={seed} FAILED: {e!r}")
        results.append({"idx": k, "seed": seed, "ok": False, "total_dist_cm": 0, "svg": "<p>経路生成に失敗</p>", "err": repr(e)})
        continue
    dist = sum(geo.distance(waypoints[i], waypoints[i + 1]) for i in range(len(waypoints) - 1))
    ok1 = verify_crossings(gates, true_points, labels)
    pivot_v = verify_pivot_safety(waypoints, all_posts)
    straight_v = verify_straight_clearance(waypoints, all_posts, anchors, labels)
    crossing_v = verify_gate_crossing_directions(waypoints, labels, all_gates)
    non_goal_pivot = [v for v in pivot_v if labels[v[0]] != "goal"]
    ok = ok1 and not non_goal_pivot and not straight_v and not crossing_v

    def fake(gates_arg, _wp=waypoints, _dist=dist, _lab=labels, _tp=true_points):
        return _wp, _dist, _lab, _tp

    generate_diagram.plan_path_detailed = fake
    result = generate_diagram.main(gates=gates, out_path=f"diagram_goalmoved_{k}.svg.txt")
    print(f"{k:2d} seed={seed} dist={dist:.1f} ok={ok} v=({ok1},{len(non_goal_pivot)},{len(straight_v)},{len(crossing_v)})")
    results.append({"idx": k, "seed": seed, "total_dist_cm": result["total_dist_cm"], "ok": ok, "svg": result["svg"]})

with open("gallery_goal_moved_30_out.json", "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=2)
print("saved", len(results), "ok:", sum(1 for r in results if r["ok"]))
