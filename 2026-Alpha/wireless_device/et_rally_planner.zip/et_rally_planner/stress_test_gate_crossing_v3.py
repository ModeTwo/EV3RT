import time
import rule_route
from rule_route import verify_pivot_safety, verify_straight_clearance, verify_gate_crossing_directions
from random_gates import random_gates
from test_rule_route import verify_crossings
import random

N = 200
rng = random.Random(999999)
seeds = [rng.randint(1, 10_000_000) for _ in range(N)]

fail_count = 0
t0 = time.time()
for k, s in enumerate(seeds):
    if k % 10 == 0:
        print(f'...progress {k}/{N} ({time.time()-t0:.1f}s elapsed)', flush=True)
    gates, seed = random_gates(s)
    all_gates = list(gates.values())
    all_posts = [p for g in gates.values() for p in g.posts()]
    try:
        waypoints, anchors, labels, true_points = rule_route.plan_route_with_anchors(gates)
    except RuntimeError as e:
        print(f'seed={seed}: EXCEPTION {e}')
        fail_count += 1
        continue
    ok1 = verify_crossings(gates, true_points, labels)
    pivot_violations = verify_pivot_safety(waypoints, all_posts)
    straight_violations = verify_straight_clearance(waypoints, all_posts, anchors)
    crossing_violations = verify_gate_crossing_directions(waypoints, labels, all_gates)
    non_goal_pivot = [v for v in pivot_violations if labels[v[0]] != 'goal']
    ok = ok1 and not non_goal_pivot and not straight_violations and not crossing_violations
    if not ok:
        fail_count += 1
        print(f'seed={seed}: crossings_ok={ok1} non_goal_pivot={len(non_goal_pivot)} straight_violations={len(straight_violations)} crossing_violations={len(crossing_violations)}', flush=True)
        for c, g in gates.items():
            print(f'    {c}: {g.foot_a_grid}-{g.foot_b_grid}', flush=True)

elapsed = time.time() - t0
print(f'\n{N-fail_count}/{N} scenarios fully OK in {elapsed:.1f}s')
