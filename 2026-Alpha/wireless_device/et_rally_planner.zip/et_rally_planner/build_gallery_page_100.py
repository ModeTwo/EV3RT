import json

with open("gallery_100_out.json", encoding="utf-8") as f:
    data = json.load(f)

HEAD = """<title>経路サンプル50件</title>
<style>
  :root {
    --bg: #f3f4f1;
    --surface: #ffffff;
    --surface-alt: #eceeea;
    --ink: #1b232b;
    --ink-soft: #5b6570;
    --line: #d9ddd6;
    --accent: #3a6472;
    --good: #1f9d7c;
    --good-soft: #d9f1e9;
    --shadow: rgba(24, 32, 36, 0.07);
    --font-head: "Yu Gothic UI", "Hiragino Sans", "Noto Sans JP", "Segoe UI", system-ui, sans-serif;
    --font-body: "Yu Gothic UI", "Hiragino Sans", "Noto Sans JP", "Segoe UI", system-ui, sans-serif;
    --font-mono: ui-monospace, "Cascadia Code", "SFMono-Regular", Consolas, "Noto Sans JP", monospace;
  }
  @media (prefers-color-scheme: dark) {
    :root:not([data-theme="light"]) {
      --bg: #10141a; --surface: #171c23; --surface-alt: #1e252d;
      --ink: #e7ebee; --ink-soft: #93a1ad; --line: #2b333d;
      --accent: #74b3c1; --good: #4fc79b; --good-soft: #163229;
      --shadow: rgba(0, 0, 0, 0.45);
    }
  }
  :root[data-theme="dark"] {
    --bg: #10141a; --surface: #171c23; --surface-alt: #1e252d;
    --ink: #e7ebee; --ink-soft: #93a1ad; --line: #2b333d;
    --accent: #74b3c1; --good: #4fc79b; --good-soft: #163229;
    --shadow: rgba(0, 0, 0, 0.45);
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; background: var(--bg); color: var(--ink);
    font-family: var(--font-body); line-height: 1.5; padding: 2rem 1.25rem 4rem;
  }
  main { max-width: 1400px; margin: 0 auto; display: flex; flex-direction: column; gap: 1.3rem; }
  h1 {
    font-family: var(--font-head); font-size: clamp(1.35rem, 1.1rem + 1vw, 1.8rem);
    font-weight: 800; margin: 0; text-wrap: balance;
  }
  .subtitle { color: var(--ink-soft); font-size: 0.88rem; max-width: 76ch; }
  .grid {
    display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 0.9rem;
  }
  .card {
    background: var(--surface); border: 1px solid var(--line); border-radius: 10px;
    padding: 0.6rem; box-shadow: 0 1px 2px var(--shadow);
    display: flex; flex-direction: column; gap: 0.4rem;
  }
  .card-head {
    display: flex; justify-content: space-between; align-items: baseline;
    font-family: var(--font-mono); font-size: 0.72rem; color: var(--ink-soft);
  }
  .card-head b { color: var(--ink); font-size: 0.78rem; }
  .card .badge {
    font-size: 0.66rem; font-weight: 700; color: var(--good);
    background: var(--good-soft); border-radius: 4px; padding: 0.05em 0.4em;
  }
  .diagram-frame {
    background: var(--surface-alt); border: 1px solid var(--line); border-radius: 6px;
    padding: 0.3rem; overflow: hidden;
  }
  svg { display: block; width: 100%; height: auto; font-family: var(--font-body); }
  .course { fill: var(--surface-alt); stroke: var(--line); stroke-width: 0.4; }
  .griddot { fill: var(--ink-soft); opacity: 0.4; }
  .gateline { stroke: var(--ink-soft); stroke-width: 0.35; stroke-dasharray: 2 1.4; opacity: 0.6; }
  .validzone { stroke-width: 1.7; stroke-linecap: round; }
  .post { stroke: var(--surface); stroke-width: 0.3; }
  .gatelabel { font-size: 3.4px; font-weight: 700; }
  .pathline { stroke-width: 1.1; fill: none; stroke-linecap: round; }
  .waynode { fill: var(--ink-soft); opacity: 0.5; }
  .checkpoint { fill: var(--surface); stroke-width: 1.1; }
  .entrymark { fill: var(--surface); stroke-width: 0.6; }
  .exitmark { stroke: var(--surface); stroke-width: 0.35; }
  .cplabel { font-size: 3.0px; font-weight: 700; }
  .startnode { fill: var(--accent); }
  .goalnode { fill: var(--ink); }
  .terminallabel { fill: var(--surface); font-size: 3.0px; font-weight: 700; }
  .headingarrow { stroke: var(--ink); stroke-width: 0.5; }
  .headingarrow-fill { fill: var(--ink); }
  footer.notes {
    font-size: 0.8rem; color: var(--ink-soft); border-top: 1px solid var(--line); padding-top: 1rem;
  }
</style>
<main>
  <header>
    <h1>ランダム100パターン(config更新後)の経路図</h1>
    <p class="subtitle">
      200/200達成後、完全ランダムな50シード(既存のテストとは別系統)で
      生成した経路をすべて掲載。灰=1周目、紫=2周目、緑=3周目。
      違反はすべて0件(自動検証済み)だが、目視で「想定通りの動き」に
      なっているかを確認する用途。
    </p>
  </header>
  <div class="grid">
"""

TAIL = """
  </div>
  <footer class="notes">
    50件すべて機械的な違反チェック(旋回安全性・直進クリアランス・一方向侵入)は通過済み。
  </footer>
</main>
"""

cards = []
for r in data:
    card = f"""    <div class="card">
      <div class="card-head">
        <b>#{r['idx']} seed={r['seed']}</b>
        <span class="badge">{r['total_dist_cm']:.0f}cm</span>
      </div>
      <div class="diagram-frame">
{r['svg']}
      </div>
    </div>"""
    cards.append(card)

html = HEAD + "\n".join(cards) + TAIL

with open("gallery_100_page.html", "w", encoding="utf-8") as f:
    f.write(html)
print("saved, size=", len(html))
