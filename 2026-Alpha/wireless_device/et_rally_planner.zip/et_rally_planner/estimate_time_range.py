import random

import config
import geometry as geo
import rule_route
from random_gates import random_gates

N = 5000
rng = random.Random(31415926)
seeds = [rng.randint(1, 10_000_000) for _ in range(N)]

CALIBRATION_SEED = 9392783
CALIBRATION_SECONDS = 67.0

results = []
for s in seeds:
    gates, seed = random_gates(s)
    waypoints, anchors, labels, true_points = rule_route.plan_route_with_anchors(gates)
    dist_cm = sum(geo.distance(waypoints[i], waypoints[i + 1]) for i in range(len(waypoints) - 1))
    turn_sum = rule_route._route_turn_sum_deg(waypoints)
    cost = dist_cm + config.TURN_COST_PER_DEGREE_CM * turn_sum
    results.append((seed, dist_cm, turn_sum, cost))

# 較正シード自身の値も同じ手順で計算し直す(手打ちの798.6/1450.9と一致するか確認)
gates, _ = random_gates(CALIBRATION_SEED)
waypoints, anchors, labels, true_points = rule_route.plan_route_with_anchors(gates)
calib_dist = sum(geo.distance(waypoints[i], waypoints[i + 1]) for i in range(len(waypoints) - 1))
calib_turn = rule_route._route_turn_sum_deg(waypoints)
calib_cost = calib_dist + config.TURN_COST_PER_DEGREE_CM * calib_turn
print(f"calibration seed recompute: dist={calib_dist:.1f} turn_sum={calib_turn:.1f} cost={calib_cost:.1f}")

sec_per_unit = CALIBRATION_SECONDS / calib_cost
print(f"implied seconds/unit-cost = {sec_per_unit:.5f}")

results.sort(key=lambda r: r[3])
min_seed = results[0]
max_seed = results[-1]

print(f"\nN={N} random seeds")
print(f"MIN cost: seed={min_seed[0]} dist={min_seed[1]:.1f} turn_sum={min_seed[2]:.1f} cost={min_seed[3]:.1f} -> est {min_seed[3]*sec_per_unit:.1f}s")
print(f"MAX cost: seed={max_seed[0]} dist={max_seed[1]:.1f} turn_sum={max_seed[2]:.1f} cost={max_seed[3]:.1f} -> est {max_seed[3]*sec_per_unit:.1f}s")

# 参考: 5%/95%タイル(外れ値を除いた実用的なレンジ)
costs = sorted(r[3] for r in results)
p05 = costs[int(0.05 * N)]
p95 = costs[int(0.95 * N)]
print(f"\n5%tile cost={p05:.1f} -> est {p05*sec_per_unit:.1f}s")
print(f"95%tile cost={p95:.1f} -> est {p95*sec_per_unit:.1f}s")
