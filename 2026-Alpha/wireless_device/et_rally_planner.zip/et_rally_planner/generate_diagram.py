"""経路のSVG図を生成する(パスは幾何計算済み、座標変換とマークアップ組み立てのみ担当)。"""

import math

import config
from commands import waypoints_to_commands
from planner import Gate
from rule_route import plan_route as plan_path_detailed

COLOR_JA = {"red": "赤", "blue": "青", "yellow": "黄"}
GATE_HEX = {"red": "#c0392b", "blue": "#2f5fa8", "yellow": "#c98a1f"}
LAP_HEX = {1: "#7d8590", 2: "#8a5cc4", 3: "#1f9d7c"}


def build_gates():
    return {
        "red": Gate("red", (0, 0), (1, 0)),      # 横向き
        "blue": Gate("blue", (2, 2), (2, 3)),    # 縦向き
        "yellow": Gate("yellow", (3, 4), (4, 4)),  # 横向き
    }


def lap_for_segment(labels, i):
    """区間(i -> i+1)がどの周回に属するかを、直近/直後のチェックポイントラベルから決める。"""
    for j in range(i + 1, len(labels)):
        lab = labels[j]
        if lab is None:
            continue
        if lab == "goal":
            return 3
        # "lap{n}-{color}"
        return int(lab.split("-")[0][3:])
    return 3


def main(gates=None, out_path="diagram.svg.txt"):
    if gates is None:
        gates = build_gates()
    waypoints, total_dist_cm, labels, true_points = plan_path_detailed(gates)
    commands = waypoints_to_commands(waypoints)

    all_posts = [p for g in gates.values() for p in g.posts()]
    pts_for_bounds = [config.START_POS_CM, config.GOAL_POS_CM] + all_posts + waypoints
    pad = 16.0
    x_min = min(p[0] for p in pts_for_bounds) - pad
    x_max = max(p[0] for p in pts_for_bounds) + pad
    y_min = min(p[1] for p in pts_for_bounds) - pad
    y_max = max(p[1] for p in pts_for_bounds) + pad
    width = x_max - x_min
    height = y_max - y_min

    def sx(x):
        return x - x_min

    def sy(y):
        return y_max - y

    def pt(p):
        return (sx(p[0]), sy(p[1]))

    gate_desc = "、".join(
        f"{COLOR_JA[c]}{gates[c].foot_a_grid}-{gates[c].foot_b_grid}" for c in ("red", "blue", "yellow")
    )
    svg_parts = []
    svg_parts.append(
        f'<svg viewBox="0 0 {width:.1f} {height:.1f}" role="img" '
        f'aria-label="ETラリー経路計画: {gate_desc}のゲート配置で、'
        f'スタートから3周(赤→青→黄を3回)してゴールに至る最短経路のダイアグラム">'
    )

    # コース領域(0,0)-(4*GRID_PITCH_CM, 4*GRID_PITCH_CM)(グレー●4個ぶんを1辺とする正方形)
    course_side = 4 * config.GRID_PITCH_CM
    x0, y0 = pt((0, 0))
    x1, y1 = pt((course_side, course_side))
    svg_parts.append(
        f'<rect x="{min(x0,x1):.2f}" y="{min(y0,y1):.2f}" width="{abs(x1-x0):.2f}" '
        f'height="{abs(y1-y0):.2f}" class="course" />'
    )

    # グリッド点(5x5)
    for i in range(5):
        for j in range(5):
            gx, gy = pt((i * config.GRID_PITCH_CM, j * config.GRID_PITCH_CM))
            svg_parts.append(f'<circle cx="{gx:.2f}" cy="{gy:.2f}" r="1.1" class="griddot" />')

    # ゲート(開口ライン → 有効通過区間 → 支柱の順に描画)
    for color, gate in gates.items():
        hexcol = GATE_HEX[color]
        ax, ay = pt(gate.foot_a)
        bx, by = pt(gate.foot_b)
        svg_parts.append(f'<line x1="{ax:.2f}" y1="{ay:.2f}" x2="{bx:.2f}" y2="{by:.2f}" class="gateline" />')

        half = gate.valid_half_length()
        c = gate.center
        d = gate.direction
        va = (c[0] - d[0] * half, c[1] - d[1] * half)
        vb = (c[0] + d[0] * half, c[1] + d[1] * half)
        vax, vay = pt(va)
        vbx, vby = pt(vb)
        svg_parts.append(
            f'<line x1="{vax:.2f}" y1="{vay:.2f}" x2="{vbx:.2f}" y2="{vby:.2f}" '
            f'class="validzone" style="stroke:{hexcol}" />'
        )

        for post in gate.posts():
            px, py = pt(post)
            svg_parts.append(f'<circle cx="{px:.2f}" cy="{py:.2f}" r="1.6" style="fill:{hexcol}" class="post" />')

        lx, ly = pt((c[0], c[1]))
        offx, offy = (6.0, -6.0) if color != "yellow" else (-6.0, -6.0)
        anchor = "start" if offx >= 0 else "end"
        svg_parts.append(
            f'<text x="{lx+offx:.2f}" y="{ly+offy:.2f}" text-anchor="{anchor}" '
            f'class="gatelabel" style="fill:{hexcol}">{COLOR_JA[color]}ゲート</text>'
        )

    # 経路(周回ごとに色分け、区間ごとに矢印)
    # 3周分で同じ区間を通ると線が完全に重なってしまうため、周回ごとに進行方向と
    # 垂直にわずかにオフセットし、3本の並行線として見分けられるようにする。
    LAP_OFFSET = {1: -1.6, 2: 0.0, 3: 1.6}
    for i in range(len(waypoints) - 1):
        p1, p2 = waypoints[i], waypoints[i + 1]
        if math.hypot(p2[0] - p1[0], p2[1] - p1[1]) < 1e-6:
            continue
        lap = lap_for_segment(labels, i)
        hexcol = LAP_HEX[lap]
        x1s, y1s = pt(p1)
        x2s, y2s = pt(p2)
        dx, dy = x2s - x1s, y2s - y1s
        seg_len = math.hypot(dx, dy)
        nx, ny = -dy / seg_len, dx / seg_len
        off = LAP_OFFSET[lap]
        x1s, y1s = x1s + nx * off, y1s + ny * off
        x2s, y2s = x2s + nx * off, y2s + ny * off
        svg_parts.append(f'<line x1="{x1s:.2f}" y1="{y1s:.2f}" x2="{x2s:.2f}" y2="{y2s:.2f}" '
                          f'class="pathline" style="stroke:{hexcol}" />')

        mx, my = (x1s + x2s) / 2, (y1s + y2s) / 2
        ang = math.atan2(y2s - y1s, x2s - x1s)
        al = 2.6
        aw = 1.5
        p_tip = (mx + al * math.cos(ang), my + al * math.sin(ang))
        p_l = (mx - al * 0.5 * math.cos(ang) + aw * math.cos(ang + math.pi / 2),
               my - al * 0.5 * math.sin(ang) + aw * math.sin(ang + math.pi / 2))
        p_r = (mx - al * 0.5 * math.cos(ang) - aw * math.cos(ang + math.pi / 2),
               my - al * 0.5 * math.sin(ang) - aw * math.sin(ang + math.pi / 2))
        svg_parts.append(
            f'<polygon points="{p_tip[0]:.2f},{p_tip[1]:.2f} {p_l[0]:.2f},{p_l[1]:.2f} '
            f'{p_r[0]:.2f},{p_r[1]:.2f}" style="fill:{hexcol}" />'
        )

    def true_crossing_point(entry_pt, exit_pt, gate):
        """entry->exitの線分と、ゲートの直線(脚を結ぶ直線)の交点を求める。

        entry/exitは旋回軸(タイヤ位置)が前端7.5cm/後端18cmという非対称な
        オフセットで計算されているため、単純な中点はゲート線上に乗らない
        (最大で数cmずれる)。図では「実際に線分を通過した位置」を正しく
        示すため、線分同士の交点を計算する。
        """
        n = gate.normal
        d = (exit_pt[0] - entry_pt[0], exit_pt[1] - entry_pt[1])
        denom = n[0] * d[0] + n[1] * d[1]
        if abs(denom) < 1e-9:
            return ((entry_pt[0] + exit_pt[0]) / 2.0, (entry_pt[1] + exit_pt[1]) / 2.0)
        num = n[0] * (gate.foot_a[0] - entry_pt[0]) + n[1] * (gate.foot_a[1] - entry_pt[1])
        t = num / denom
        return (entry_pt[0] + t * d[0], entry_pt[1] + t * d[1])

    # チェックポイント(ゲート通過点)・中継点(障害物回避点)のマーカー
    # ゲート通過は entry(進入完了)->exit(退出完了) の2点1組で表現されているため、
    # その線分とゲート線の交点を「実際に線分を通過した位置」としてマーカーを置く。
    # 周回によって全く同じ通過点になる場合があるため、同一座標(丸め誤差程度)は
    # 1つのマーカーにまとめ、周回番号を併記する(ラベルの重なりを防ぐ)。
    lap_kanji = {1: "①", 2: "②", 3: "③"}
    checkpoint_groups = {}
    for i, (p, lab) in enumerate(zip(waypoints, labels)):
        if lab is None:
            x, y = pt(p)
            svg_parts.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="0.8" class="waynode" />')
        elif lab.endswith("-entry"):
            lap_n = int(lab.split("-")[0][3:])
            color = lab.split("-")[1]
            p_exit = waypoints[i + 1]
            cross_pt = true_crossing_point(p, p_exit, gates[color])
            key = (color, round(cross_pt[0], 1), round(cross_pt[1], 1))
            checkpoint_groups.setdefault(key, {"point": cross_pt, "color": color, "laps": []})
            checkpoint_groups[key]["laps"].append(lap_n)

            # true_entry(車体前端が線分に触れる瞬間, 手前)とtrue_exit(車体後端が
            # 抜けきる瞬間, 奥)を別マーカーで明示する。waypoint自体(p/p_exit)は
            # 旋回スイープぶん手前/先に離した「安全な旋回可能地点」なので、
            # 通過の証跡としてはtrue_entry/true_exitの方を表示する。
            # entry=白抜きの小さい丸、exit=塗りつぶした小さい丸。
            hexcol_e = GATE_HEX[color]
            ex, ey = pt(true_points[i])
            xx, xy = pt(true_points[i + 1])
            svg_parts.append(
                f'<circle cx="{ex:.2f}" cy="{ey:.2f}" r="1.0" class="entrymark" style="stroke:{hexcol_e}" />'
            )
            svg_parts.append(
                f'<circle cx="{xx:.2f}" cy="{xy:.2f}" r="1.0" class="exitmark" style="fill:{hexcol_e}" />'
            )

    for (color, _rx, _ry), info in checkpoint_groups.items():
        x, y = pt(info["point"])
        hexcol = GATE_HEX[color]
        laps_txt = "".join(lap_kanji[n] for n in sorted(set(info["laps"])))
        svg_parts.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="1.7" class="checkpoint" style="stroke:{hexcol}" />')
        svg_parts.append(
            f'<text x="{x:.2f}" y="{y-2.6:.2f}" text-anchor="middle" class="cplabel" '
            f'style="fill:{hexcol}">{COLOR_JA[color]}{laps_txt}</text>'
        )

    # スタート/ゴール(向きの矢印つき)
    def draw_terminal(pos_cm, heading_deg, label, css_class):
        x, y = pt(pos_cm)
        svg_parts.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="2.6" class="{css_class}" />')
        svg_parts.append(f'<text x="{x:.2f}" y="{y+1.1:.2f}" text-anchor="middle" class="terminallabel">{label}</text>')
        rad = math.radians(heading_deg)
        dx, dy = math.cos(rad), -math.sin(rad)  # 標準系(反時計回り正)->SVG(下向き正)へ変換
        ex, ey = x + dx * 9.0, y + dy * 9.0
        svg_parts.append(f'<line x1="{x:.2f}" y1="{y:.2f}" x2="{ex:.2f}" y2="{ey:.2f}" class="headingarrow" />')
        tip_ang = math.atan2(ey - y, ex - x)
        al, aw = 2.2, 1.3
        p_l = (ex - al * math.cos(tip_ang) + aw * math.cos(tip_ang + math.pi / 2),
               ey - al * math.sin(tip_ang) + aw * math.sin(tip_ang + math.pi / 2))
        p_r = (ex - al * math.cos(tip_ang) - aw * math.cos(tip_ang + math.pi / 2),
               ey - al * math.sin(tip_ang) - aw * math.sin(tip_ang + math.pi / 2))
        svg_parts.append(
            f'<polygon points="{ex:.2f},{ey:.2f} {p_l[0]:.2f},{p_l[1]:.2f} {p_r[0]:.2f},{p_r[1]:.2f}" class="headingarrow-fill" />'
        )

    draw_terminal(config.START_POS_CM, config.START_HEADING_DEG, "S", "startnode")
    draw_terminal(config.GOAL_POS_CM, config.GOAL_HEADING_DEG, "G", "goalnode")

    svg_parts.append("</svg>")

    svg_markup = "\n".join(svg_parts)

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(svg_markup)

    move_count = sum(1 for c, _ in commands if c == "move")
    turn_count = sum(1 for c, _ in commands if c == "turn")
    turn_sum_deg = sum(abs(v) for c, v in commands if c == "turn")
    print(f"gates={ {c: (g.foot_a_grid, g.foot_b_grid) for c, g in gates.items()} }")
    print(f"total_dist_cm={total_dist_cm:.1f}")
    print(f"waypoints={len(waypoints)}")
    print(f"move_count={move_count} turn_count={turn_count} turn_sum_deg={turn_sum_deg:.1f}")
    print(f"viewBox width={width:.1f} height={height:.1f}")

    return {
        "waypoints": waypoints, "labels": labels, "commands": commands,
        "total_dist_cm": total_dist_cm, "move_count": move_count,
        "turn_count": turn_count, "turn_sum_deg": turn_sum_deg,
        "svg": svg_markup,
    }


if __name__ == "__main__":
    main()
