import json
import random

import generate_diagram
import geometry as geo
import rule_route
from rule_route import verify_pivot_safety, verify_straight_clearance, verify_gate_crossing_directions
from random_gates import random_gates
from test_rule_route import verify_crossings

N = 40
rng = random.Random(137270)
seeds = [rng.randint(1, 10_000_000) for _ in range(N)]

results = []
for k, s in enumerate(seeds):
    gates, seed = random_gates(s)
    all_gates = list(gates.values())
    all_posts = [p for g in gates.values() for p in g.posts()]

    waypoints, anchors, labels, true_points = rule_route.plan_route_with_anchors(gates)
    dist = sum(geo.distance(waypoints[i], waypoints[i + 1]) for i in range(len(waypoints) - 1))
    ok1 = verify_crossings(gates, true_points, labels)
    pivot_v = verify_pivot_safety(waypoints, all_posts)
    straight_v = verify_straight_clearance(waypoints, all_posts, anchors, labels)
    crossing_v = verify_gate_crossing_directions(waypoints, labels, all_gates)
    non_goal_pivot = [v for v in pivot_v if labels[v[0]] != "goal"]
    ok = ok1 and not non_goal_pivot and not straight_v and not crossing_v

    def fake_plan_path_detailed(gates_arg, _wp=waypoints, _dist=dist, _lab=labels, _tp=true_points):
        return _wp, _dist, _lab, _tp

    generate_diagram.plan_path_detailed = fake_plan_path_detailed
    result = generate_diagram.main(gates=gates, out_path=f"diagram_gallery40_{k}.svg.txt")

    print(f"{k:2d} seed={seed} dist={dist:.1f} ok={ok}")

    results.append({
        "idx": k,
        "seed": seed,
        "gates": {c: {"a": g.foot_a_grid, "b": g.foot_b_grid} for c, g in gates.items()},
        "total_dist_cm": result["total_dist_cm"],
        "move_count": result["move_count"],
        "turn_count": result["turn_count"],
        "ok": ok,
        "svg": result["svg"],
    })

with open("gallery_40_out.json", "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=2)
print("\nsaved", len(results), "cases")
print("all ok:", all(r["ok"] for r in results))
