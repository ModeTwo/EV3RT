import json

with open("mirror_check_out.json", encoding="utf-8") as f:
    left_data = json.load(f)
with open("right_course_diagram_out.json", encoding="utf-8") as f:
    right_data = json.load(f)

CSS = """
  :root {
    --bg: #f3f4f1; --surface: #ffffff; --surface-alt: #eceeea;
    --ink: #1b232b; --ink-soft: #5b6570; --line: #d9ddd6;
    --accent: #3a6472; --good: #1f9d7c; --good-soft: #d9f1e9;
    --font-head: "Yu Gothic UI", "Hiragino Sans", "Noto Sans JP", "Segoe UI", system-ui, sans-serif;
    --font-body: "Yu Gothic UI", "Hiragino Sans", "Noto Sans JP", "Segoe UI", system-ui, sans-serif;
    --font-mono: ui-monospace, "Cascadia Code", "SFMono-Regular", Consolas, "Noto Sans JP", monospace;
    --shadow: rgba(24, 32, 36, 0.07);
  }
  @media (prefers-color-scheme: dark) {
    :root:not([data-theme="light"]) {
      --bg: #10141a; --surface: #171c23; --surface-alt: #1e252d;
      --ink: #e7ebee; --ink-soft: #93a1ad; --line: #2b333d;
      --accent: #74b3c1; --good: #4fc79b; --shadow: rgba(0, 0, 0, 0.45);
    }
  }
  :root[data-theme="dark"] {
    --bg: #10141a; --surface: #171c23; --surface-alt: #1e252d;
    --ink: #e7ebee; --ink-soft: #93a1ad; --line: #2b333d;
    --accent: #74b3c1; --good: #4fc79b; --shadow: rgba(0, 0, 0, 0.45);
  }
  * { box-sizing: border-box; }
  body { margin: 0; background: var(--bg); color: var(--ink); font-family: var(--font-body); line-height: 1.6; padding: 2.5rem 1.25rem 4rem; }
  main { max-width: 1000px; margin: 0 auto; display: flex; flex-direction: column; gap: 1.6rem; }
  h1 { font-family: var(--font-head); font-size: clamp(1.4rem, 1.1rem + 1.2vw, 1.9rem); font-weight: 800; margin: 0; text-wrap: balance; }
  .subtitle { color: var(--ink-soft); font-size: 0.92rem; max-width: 76ch; }
  .subtitle code { font-family: var(--font-mono); background: var(--surface-alt); padding: 0.05em 0.4em; border-radius: 4px; font-size: 0.88em; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.2rem; }
  .case { background: var(--surface); border: 1px solid var(--good); border-radius: 12px; padding: 1.2rem; box-shadow: 0 1px 3px var(--shadow); }
  .case h2 { margin: 0 0 0.4rem; font-size: 1.0rem; }
  .case p { color: var(--ink-soft); font-size: 0.85rem; margin: 0.2rem 0 0.7rem; }
  .badge { font-family: var(--font-mono); font-size: 0.76rem; font-weight: 700; padding: 0.2em 0.65em; border-radius: 6px; display: inline-block; background: #d9f1e9; color: var(--good); }
  .diagram-frame { background: var(--surface-alt); border: 1px solid var(--line); border-radius: 8px; padding: 0.7rem; overflow-x: auto; margin-top: 0.6rem; }
  svg { display: block; width: 100%; height: auto; font-family: var(--font-body); }
  .course { fill: var(--surface-alt); stroke: var(--line); stroke-width: 0.4; }
  .griddot { fill: var(--ink-soft); opacity: 0.5; }
  .gateline { stroke: var(--ink-soft); stroke-width: 0.35; stroke-dasharray: 2 1.4; opacity: 0.7; }
  .validzone { stroke-width: 1.7; stroke-linecap: round; }
  .post { stroke: var(--surface); stroke-width: 0.3; }
  .gatelabel { font-size: 3.1px; font-weight: 700; }
  .pathline { stroke-width: 1.0; fill: none; stroke-linecap: round; }
  .waynode { fill: var(--ink-soft); opacity: 0.5; }
  .checkpoint { fill: var(--surface); stroke-width: 1.1; }
  .entrymark { fill: var(--surface); stroke-width: 0.6; }
  .exitmark { stroke: var(--surface); stroke-width: 0.35; }
  .cplabel { font-size: 2.7px; font-weight: 700; }
  .startnode { fill: var(--accent); }
  .goalnode { fill: var(--ink); }
  .terminallabel { fill: var(--surface); font-size: 2.7px; font-weight: 700; }
  .headingarrow { stroke: var(--ink); stroke-width: 0.5; }
  .headingarrow-fill { fill: var(--ink); }
  footer.notes { font-size: 0.82rem; color: var(--ink-soft); border-top: 1px solid var(--line); padding-top: 1rem; }
"""

html = f"""<title>LEFT/RIGHTコース経路</title>
<style>
{CSS}
</style>
<main>
  <header>
    <h1>seed=9392783 のLEFT/RIGHTコース経路</h1>
    <p class="subtitle">
      RIGHTコース用は、ゲート配置・スタート/ゴール位置をグリッド中央の列
      (col=2、<code>x=2*GRID_PITCH_CM</code>)を軸に左右反転した上で、
      <code>rule_route.py</code>で経路を計算し直したもの
      (<code>export_plan_right_course.py</code>)。反転は幾何レベルで
      完結しているので、実機では<code>course=left</code>でそのまま
      実行できる想定。
    </p>
  </header>

  <div class="grid">
    <section class="case">
      <h2>LEFTコース</h2>
      <p>元のゲート配置での経路。</p>
      <span class="badge">798.6cm・move21・turn22</span>
      <div class="diagram-frame">{left_data['left']['svg']}</div>
    </section>
    <section class="case">
      <h2>RIGHTコース(左右反転)</h2>
      <p>col方向に鏡映したゲート配置で経路を再計算。距離・旋回量ともLEFTと完全一致。</p>
      <span class="badge">798.6cm・move21・turn22・違反0件</span>
      <div class="diagram-frame">{right_data['svg']}</div>
    </section>
  </div>

  <footer class="notes">
    総移動距離(798.6cm)・旋回角合計(1450.9度)がLEFT/RIGHTで完全に一致しており、
    正しく鏡映になっていることを裏付けている。plan.jsonは
    <code>plan_seed9392783_right.json</code>。
  </footer>
</main>
"""

with open("right_course_page.html", "w", encoding="utf-8") as f:
    f.write(html)
print("wrote", len(html), "bytes")
