"""動作確認用CLI: 経路計画を1回実行し、検証結果・統計・図(SVG)を出力する。

使い方:
  python3 run_random.py                乱数シードでゲート配置を自動生成
  python3 run_random.py 199055          乱数シード指定(再現用)
  python3 run_random.py "red:0,0-1,0;blue:2,1-2,2;yellow:1,3-2,3"  ゲート直接指定
"""

import sys
import time

import math

import generate_diagram
import geometry as geo
from planner import pivot_turn_safe
from random_gates import parse_gate_spec, random_gates, validate_gate_orientation
from rule_route import plan_route as plan_path_detailed


def side_of_line(p, line_point, line_dir):
    """点pが、line_pointを通りline_dir方向へ伸びる直線のどちら側にあるかを符号(+1/-1/0)で返す。"""
    v = geo.sub(p, line_point)
    cross = line_dir[0] * v[1] - line_dir[1] * v[0]
    if cross > 1e-9:
        return 1
    if cross < -1e-9:
        return -1
    return 0


def verify(gates, true_points, labels):
    """各ゲート通過について、entry点とexit点がゲートの直線を挟んで反対側にあるか
    (=ロボットが本当に反対側まで抜けきったか)を機械的にチェックする。"""
    ok = True
    for i, lab in enumerate(labels):
        if lab is None or not lab.endswith("-entry"):
            continue
        lap_n, color, _ = lab.split("-")
        gate = gates[color]
        entry_pt, exit_pt = true_points[i], true_points[i + 1]
        s1 = side_of_line(entry_pt, gate.foot_a, gate.direction)
        s2 = side_of_line(exit_pt, gate.foot_a, gate.direction)
        crossed = s1 != 0 and s2 != 0 and s1 != s2
        if not crossed:
            ok = False
            print(f"  [NG] {lap_n} {color}: entry={entry_pt} exit={exit_pt} side {s1}->{s2}")
    return ok


def verify_pivot_safety(gates, waypoints, labels):
    """経路上の各ノードで実際に起きる旋回(直前の進行方向->直後の進行方向)が、
    pivot_turn_safe(旋回角度に応じた、車体四隅の実際の掃引弧に基づく判定)で
    安全と確認できるかをチェックする(単純な距離だけの判定は、旋回角が
    小さいケースまで危険と誤判定してしまうため使わない)。"""
    all_posts = [p for g in gates.values() for p in g.posts()]

    def heading(a, b):
        return math.degrees(math.atan2(b[1] - a[1], b[0] - a[0]))

    ok = True
    for i in range(1, len(waypoints) - 1):
        h_in = heading(waypoints[i - 1], waypoints[i])
        h_out = heading(waypoints[i], waypoints[i + 1])
        if not pivot_turn_safe(waypoints[i], h_in, h_out, all_posts):
            ok = False
            print(f"  [NG-PIVOT] i={i} label={labels[i]} point={waypoints[i]}: "
                  f"旋回{geo.normalize_deg(h_out - h_in):.1f}degが支柱に接触する可能性")
    return ok


def main():
    arg = sys.argv[1] if len(sys.argv) > 1 else None

    if arg is not None and not arg.lstrip("-").isdigit():
        # "red:0,0-1,0;blue:2,1-2,2;yellow:1,3-2,3" のようなゲート指定文字列
        gates = parse_gate_spec(arg)
        validate_gate_orientation(gates)
        print("=== 手動指定ゲート配置 ===")
    else:
        seed = int(arg) if arg is not None else None
        gates, used_seed = random_gates(seed)
        print(f"=== seed={used_seed} ===")
    for color, gate in gates.items():
        print(f"  {color}: {gate.foot_a_grid} - {gate.foot_b_grid}")

    t0 = time.time()
    waypoints, total_dist_cm, labels, true_points = plan_path_detailed(gates)
    t1 = time.time()

    ok = verify(gates, true_points, labels)
    print(f"\n全ゲート通過が反対側まで抜けている: {'YES' if ok else 'NO'}")
    ok2 = verify_pivot_safety(gates, waypoints, labels)
    print(f"entry/exit地点での旋回が支柱に届かない: {'YES' if ok2 else 'NO'}")
    print(f"計算時間: {t1 - t0:.2f}s")

    result = generate_diagram.main(gates=gates, out_path="diagram_random.svg.txt")
    print(f"\ntotal_dist_cm={result['total_dist_cm']:.1f} move={result['move_count']} "
          f"turn={result['turn_count']} turn_sum_deg={result['turn_sum_deg']:.1f}")


if __name__ == "__main__":
    main()
