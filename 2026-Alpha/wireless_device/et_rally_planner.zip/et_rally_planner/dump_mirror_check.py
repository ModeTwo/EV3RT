import json

import config
import generate_diagram
import geometry as geo
import rule_route
from planner import Gate
from random_gates import random_gates

SEED = 9392783
gates, seed = random_gates(SEED)

waypoints, anchors, labels, true_points = rule_route.plan_route_with_anchors(gates)
dist = sum(geo.distance(waypoints[i], waypoints[i + 1]) for i in range(len(waypoints) - 1))


def fake_left(gates_arg, _wp=waypoints, _dist=dist, _lab=labels, _tp=true_points):
    return _wp, _dist, _lab, _tp


generate_diagram.plan_path_detailed = fake_left
left_result = generate_diagram.main(gates=gates, out_path="diagram_mirror_left.svg.txt")

# --- 水平線反転(course=right が実装している反転): (x, y) -> (x, 2*axis_y - y) ---
axis_y = config.START_POS_CM[1]  # == GOAL_POS_CM[1] == 89.95


def mirror_h(p):
    return (p[0], 2 * axis_y - p[1])


mirrored_waypoints = [mirror_h(p) for p in waypoints]
mirrored_true_points = [mirror_h(p) if p is not None else None for p in true_points]
mirrored_gates = {
    color: Gate(color, g.foot_a_grid, g.foot_b_grid)  # placeholder, overwritten below
    for color, g in gates.items()
}
# Gateはgrid座標から作られるため、cm座標を直接差し替えられるようfoot_a/foot_bを上書きする
for color, g in gates.items():
    mg = mirrored_gates[color]
    mg.foot_a = mirror_h(g.foot_a)
    mg.foot_b = mirror_h(g.foot_b)


def fake_mirror_h(gates_arg, _wp=mirrored_waypoints, _dist=dist, _lab=labels, _tp=mirrored_true_points):
    return _wp, _dist, _lab, _tp


generate_diagram.plan_path_detailed = fake_mirror_h
mirror_h_result = generate_diagram.main(gates=mirrored_gates, out_path="diagram_mirror_h.svg.txt")

# --- 垂直線反転(ユーザーの説明する「左右反転」): (x, y) -> (2*axis_x - x, y) ---
# 軸はコースグリッドの中心列(col=2, x=2*GRID_PITCH_CM)を採用
axis_x = 2 * config.GRID_PITCH_CM


def mirror_v(p):
    return (2 * axis_x - p[0], p[1])


mirrored_v_waypoints = [mirror_v(p) for p in waypoints]
mirrored_v_true_points = [mirror_v(p) if p is not None else None for p in true_points]
mirrored_v_gates = {color: Gate(color, g.foot_a_grid, g.foot_b_grid) for color, g in gates.items()}
for color, g in gates.items():
    mg = mirrored_v_gates[color]
    mg.foot_a = mirror_v(g.foot_a)
    mg.foot_b = mirror_v(g.foot_b)


def fake_mirror_v(gates_arg, _wp=mirrored_v_waypoints, _dist=dist, _lab=labels, _tp=mirrored_v_true_points):
    return _wp, _dist, _lab, _tp


generate_diagram.plan_path_detailed = fake_mirror_v
mirror_v_result = generate_diagram.main(gates=mirrored_v_gates, out_path="diagram_mirror_v.svg.txt")

with open("mirror_check_out.json", "w", encoding="utf-8") as f:
    json.dump(
        {
            "left": {"svg": left_result["svg"]},
            "mirror_h": {"svg": mirror_h_result["svg"]},
            "mirror_v": {"svg": mirror_v_result["svg"]},
        },
        f,
        ensure_ascii=False,
    )
print("done")
