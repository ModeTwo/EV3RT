import sys
import argparse
import json
import math
import time
import threading
import signal
from enum import IntEnum, Enum, auto
from etrobo_python import ETRobo, Hub, Motor, TouchSensor, ColorSensor, SonarSensor, GyroSensor
from simple_pid import PID
from py_trees.trees import BehaviourTree
from py_trees.behaviour import Behaviour
from py_trees.common import Status
from py_trees.composites import Sequence
from py_trees.composites import Parallel
from py_trees.common import ParallelPolicy
from py_trees import (
    display as display_tree,
    logging as log_tree
)
from py_etrobo_util import Video, TraceSide, TargetInterested, Plotter, SymmetricClamper, Color, ColorClassifier
# その場旋回を左右のエンコーダで揃えるSpinAroundByEncoder(下記)で使う。
# 較正済みの値はpy_etrobo_util/plotter.py側で一元管理している。
from py_etrobo_util.plotter import TIRE_DIAMETER, WHEEL_TREAD, GYRO_SCALE_FACTOR

# --- 制御の周期（インターバル）設定 ---
EXEC_INTERVAL: float = 0.03   # メインの制御ツリーを動かす周期（0.03秒ごと）
VIDEO_INTERVAL: float = 0.02  # バックグラウンドの動画・画像処理を動かす周期（0.02秒ごと）

# --- ロボットの動作に関する定数設定 ---
ARM_SHIFT_PWM = 30          # アームを上下に動かすときのモーター出力（パワー）
JUNCT_UPPER_THREAH = 50     # 交差点（ラインの合流・分岐）を判定するための、エッジ幅の上限しきい値
JUNCT_LOWER_THREAH = 30     # 交差点（ラインの合流・分岐）を判定するための、エッジ幅の下限しきい値
SPIN_MAX_POWER = 70         # その場回旋（スピン）するときの最大モーター出力
SPIN_MIN_POWER = 60         # その場回旋（スピン）するときの最低モーター出力
PROBE_BLACK_V_MAX = 40      # 寄り道(LineProbe)で「黒線」とみなす明度Vの上限(黒のV平均は約26、白は約98)
TRACELINE_TARGET_V = 65     # ライントレース時の目標とする輝度値（センサーの真下の明るさ目標）

# アームの移動方向を定義する列挙型（UPならマイナス方向、DOWNならプラス方向にモーターを回す）
class ArmDirection(IntEnum):
    UP = -1
    DOWN = 1

# 交差点（Junction）の状態を管理するステートマシン用の列挙型
class JState(Enum):
    INITIAL = auto()  # 初期状態
    JOINING = auto()  # ラインが合流しつつある状態
    JOINED = auto()   # 合流が完了した状態
    FORKING = auto()  # ラインが分岐しつつある状態
    FORKED = auto()   # 分岐が完了した状態

# ジャイロセンサー等で向き（Heading）を指定する際の種類
class HeadingType(Enum):
    ABSOLUTE = "absolute"  # 絶対方位（リセット時を基準とした固定の角度）
    RELATIVE = "relative"  # 相対方位（今の向きからプラスマイナス何度動くか）

# --- グローバル変数の定義（プログラム全体、別スレッドからも共有して使う機材や設定） ---
g_plotter: Plotter = None          # 自己位置推定・走行軌跡を計算するオブジェクト
g_hub: Hub = None                  # ロボットのコントロールハブ（基盤）
g_arm_motor: Motor = None          # アーム駆動用モーター
g_right_motor: Motor = None        # 右車輪駆動用モーター
g_left_motor: Motor = None         # 左車輪駆動用モーター
g_touch_sensor: TouchSensor = None  # タッチセンサー（スタートボタン用など）
g_color_sensor: ColorSensor = None  # カラーセンサー（地面の識別用）
g_sonar_sensor: SonarSensor = None  # 超音波センサー（障害物の距離測定用）
g_gyro_sensor: GyroSensor = None    # ジャイロセンサー（車体の向き測定用）
g_course: int = 0                  # 走行コース（右なら -1、左なら 1 を掛けて左右のモーター出力を反転させる）
g_key: str = None                  # 暗号解読等で使用する、入力されたキー文字列


# =============================================================================
# 【ビヘイビアツリー（Behavior Tree）用の各ノード（動作部品）の定義】
# 全てのクラスは py_trees.behaviour.Behaviour クラスの能力を「継承」しています。
# =============================================================================

#__init__を書かない場合、super(TheEnd, self).__init__(name)は勝手に呼ばれる。
#loggeとrunninng=Falseのために__init__()を明示的に書く。
#組んだビヘイビアツリーの最後に配置することで、プログラムが終了せずにctrl+Cを待つ状態を維持することができます。
class TheEnd(Behaviour):
    """プログラムの終了状態を維持し、ctrl+Cを待つためのノード"""
    def __init__(self, name: str):
        super(TheEnd, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))
        self.running = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            # ビヘイビアツリーが最後まで到達したことをログに出力
            self.logger.info("%+06d %s.behavior tree exhausted. ctrl+C shall terminate the program" % (g_plotter.get_distance(), self.__class__.__name__))
        return Status.RUNNING  # 終了せず、ずっとRUNNING状態を返し続けて待機する


class ResetDevice(Behaviour):
    """各種モーターの回転角やジャイロセンサーを初期化（リセット）するノード"""
    def __init__(self, name: str):
        super(ResetDevice, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))
        self.count = 0

    def update(self) -> Status:
        if self.count == 0:
            # すべてのモーターのカウンターとジャイロの角度を0にリセットする
            g_arm_motor.reset_count()
            g_right_motor.reset_count()
            g_left_motor.reset_count()
            g_gyro_sensor.reset()
            self.logger.info("%+06d %s.resetting..." % (g_plotter.get_distance(), self.__class__.__name__))
            self.logger.info("%+06d %s.waiting for IMU to be stationary..." % (g_plotter.get_distance(), self.__class__.__name__))
        elif self.count > 3:
            # 完全に静止し、リセット状態が数フレーム維持できたら「成功（SUCCESS）」を返して次の動作へ進む
            self.logger.info("%+06d %s.complete" % (g_plotter.get_distance(), self.__class__.__name__))
            return Status.SUCCESS
            
        # 慣性計測装置（IMU / ジャイロ）が完全に静止しているかチェックし、静止していればカウントを進める
        if g_hub.hub_imu_is_stationary():
            self.count += 1
        return Status.RUNNING


class ArmUpDownFull(Behaviour):
    """アームを上限、または下限まで限界まで動かすノード（突っかかって動かなくなるまで回す）"""
    def __init__(self, name: str, direction: ArmDirection, min_travel_deg: int = 0, timeout_s: float = 3.0):
        super(ArmUpDownFull, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))
        self.direction = direction  # 動かす方向（UPかDOWN）
        # min_travel_deg > 0: 起動直後の停止誤検出を防ぐため、start位置から
        # この角度以上動くまで（またはtimeout_s経過まで）停止判定をしない
        self.min_travel_deg = min_travel_deg
        self.timeout_s = timeout_s
        self.running = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            self.prev_degree = g_arm_motor.get_count()
            self.logger.info("%+06d %s.start position is %d" % (g_plotter.get_distance(), self.__class__.__name__, self.prev_degree))
            self.count = 0
            self.start_degree = self.prev_degree
            self.start_time = time.time()
            # 指定された方向に向けてモーターを回し始める
            g_arm_motor.set_power(ARM_SHIFT_PWM * self.direction)
        else:
            cur_degree = g_arm_motor.get_count()
            if (self.min_travel_deg > 0
                    and abs(cur_degree - self.start_degree) < self.min_travel_deg
                    and time.time() - self.start_time < self.timeout_s):
                self.prev_degree = cur_degree
                return Status.RUNNING
            # 「前回の角度と今回の角度の差が5度未満」＝アームが限界まで達してロック（停止）したかチェック
            if abs(cur_degree - self.prev_degree) < 5:
                if self.count > 10:  # 10フレーム連続で動いていなければ完全に限界位置に到達したとみなす
                    g_arm_motor.set_power(0)      # モーターを停止
                    g_arm_motor.set_brake(True)   # その位置をがっちりキープ（ブレーキ）
                    self.logger.info("%+06d %s.position set to %d" % (g_plotter.get_distance(), self.__class__.__name__, cur_degree))
                    return Status.SUCCESS        # 成功して次の動作へ
                else:
                    self.count += 1
            self.prev_degree = cur_degree
        return Status.RUNNING


class ReadKey(Behaviour):
    """コンソール（キーボード）から解読用キー入力を求めるデバッグ・ミッション用ノード"""
    def __init__(self, name: str):
        super(ReadKey, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))
        self.running = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            return Status.RUNNING
        else:
            global g_key
            g_key = input("Enter the given key for decryption: ")
            # バリデーション：4文字でなければ再入力を促す
            if len(g_key) != 4:
                self.logger.warning("%+06d %s.invalid key length: %d. key should be 4 characters long." % (g_plotter.get_distance(), self.__class__.__name__, len(g_key)))
                return Status.RUNNING
            else:
                self.logger.info("%+06d %s.entered key: %s" % (g_plotter.get_distance(), self.__class__.__name__, g_key))
                confirmation = input("Is the entered key correct? (y/n): ")
                if confirmation.lower() == 'y':
                    self.logger.info("%+06d %s.key confirmed" % (g_plotter.get_distance(), self.__class__.__name__))
                    return Status.SUCCESS
                else:
                    self.logger.info("%+06d %s.key rejected, please enter again" % (g_plotter.get_distance(), self.__class__.__name__))
                    return Status.RUNNING


class IsTimePassed(Behaviour):
    """指定された時間（秒）が経過したかどうかを判定するタイマー（条件付き待機）ノード"""
    def __init__(self, name: str, delta_time: int):
        super(IsTimePassed, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))
        self.delta_time = delta_time  # 待ちたい秒数
        self.running = False
        self.earned = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            self.orig_time = time.time()  # 開始時刻を記録
            self.logger.info("%+06d %s.accumulation started for delta=%d" % (self.orig_time, self.__class__.__name__, self.delta_time))
        cur_time = time.time()
        earned_time = cur_time - self.orig_time  # 経過時間を計算
        if earned_time >= self.delta_time:
            if not self.earned:
                self.earned = True
                self.logger.info("%+06d %s.delta time passed" % (g_plotter.get_distance(), self.__class__.__name__))
            return Status.SUCCESS  # 指定時間経ったら SUCCESS
        else:
            return Status.RUNNING  # 経ってなければ RUNNING でループを維持


class LogGyroPeriodically(Behaviour):
    """モーターを一切動かさず、指定時間だけジャイロの角度を1秒おきにログへ
    出し続けるだけの、動作確認・ドリフト計測専用ノード(2026-09-14追加)。

    RunByGyroが「1秒ごとに現在の向きをログに出す」のと同じ考え方だが、
    こちらは旋回・直進を一切行わない。ロボットを静止させたまま実行すれば、
    センサー自体の時間経過によるドリフト(旋回動作とは無関係な純粋な
    ジャイロのクセ)がどれくらいあるかを見られる。build_gyro_watch_tree()
    経由で使う想定。
    """
    def __init__(self, name: str, duration_sec: float):
        super(LogGyroPeriodically, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))
        self.duration_sec = duration_sec
        self.running = False

    def update(self) -> Status:
        # 2026-09-14: ジャイロの生値は実際の回転量を約0.6%過少に報告していると
        # 判明した(py_etrobo_util/plotter.pyのGYRO_SCALE_FACTOR参照)ため、
        # 全ての箇所でここを掛けた値を「真の角度の推定値」として使う。
        current_heading = (-1) * g_course * g_gyro_sensor.get_angle() * GYRO_SCALE_FACTOR
        if not self.running:
            self.running = True
            self.t0 = time.time()
            self.last_log = 0.0
            self.start_heading = current_heading
            self.logger.info("%+06d %s.gyro-watch start heading=%.2f (%.0fs間ログを出し続けます)" % (
                g_plotter.get_distance(), self.__class__.__name__, self.start_heading, self.duration_sec))
        elapsed = time.time() - self.t0
        if elapsed - self.last_log >= 1.0:
            self.last_log = elapsed
            self.logger.info("%+06d %s.t=%.1fs heading=%.2f (start比delta=%.2f)" % (
                g_plotter.get_distance(), self.__class__.__name__, elapsed, current_heading,
                current_heading - self.start_heading))
        if elapsed >= self.duration_sec:
            self.logger.info("%+06d %s.gyro-watch end heading=%.2f (start比delta=%.2f)" % (
                g_plotter.get_distance(), self.__class__.__name__, current_heading,
                current_heading - self.start_heading))
            return Status.SUCCESS
        return Status.RUNNING


class IsDistanceEarned(Behaviour):
    """ロボットが指定された距離（ミリメートル）を進んだかどうかを判定するノード"""
    def __init__(self, name: str, delta_dist: int):
        super(IsDistanceEarned, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))
        self.delta_dist = delta_dist  # 進みたい距離（mm）
        self.running = False
        self.earned = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            self.orig_dist = g_plotter.get_distance()  # 開始時点の走行距離（オドメーター）を取得
            self.logger.info("%+06d %s.accumulation started for delta=%d" % (self.orig_dist, self.__class__.__name__, self.delta_dist))
        cur_dist = g_plotter.get_distance()
        earned_dist = cur_dist - self.orig_dist  # 進んだ距離を算出（前進・後退どちらにも対応）
        if (earned_dist >= self.delta_dist or -earned_dist <= -self.delta_dist):
            if not self.earned:
                self.earned = True
                self.logger.info("%+06d %s.delta distance earned" % (cur_dist, self.__class__.__name__))
            return Status.SUCCESS  # 目標距離に達したら SUCCESS
        else:
            return Status.RUNNING


class IsColorDetected(Behaviour):
    """カラーセンサーで地面の特定の特定色（青など）を検知したかを判定するノード"""
    def __init__(self, name: str, color: Color):
        super(IsColorDetected, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))
        self.color = color              # 待ち構えるターゲットの色
        self.prevColor = Color.UNKNOWN
        self.classifier = ColorClassifier()  # HSVから色を判定する識別器
        self.running = False
        self.detected = False

    def update(self) -> Status:
        cur_dist = g_plotter.get_distance()
        if not self.running:
            self.running = True
            self.logger.info("%+06d %s.detection started for color=%s" % (cur_dist, self.__class__.__name__, self.color.value))
        
        # カラーセンサーから生のHSV（色相・彩度・明度）を取得
        h, s, v = g_color_sensor.get_raw_color_hsv()

        # HSV値をもとに、現在の色を「BLUE」「BLACK」などに変換
        detected_color = self.classifier.classify(h, s, v)
        if detected_color == self.color:
            if not self.detected:
                self.detected = True
                self.logger.info("%+06d %s.color=%s detected" % (cur_dist, self.__class__.__name__, self.color.value))
            return Status.SUCCESS  # 狙った色を検知できたら SUCCESS
        else:
            # ログが埋め尽くされないよう、色が変わった瞬間だけ変化ログを吐く工夫
            if detected_color != self.prevColor:
                if detected_color != Color.UNKNOWN or self.prevColor != Color.UNKNOWN:
                    self.logger.info("%+06d %s.color changed from %s to %s" % (cur_dist, self.__class__.__name__, self.prevColor.value, detected_color.value))
                    self.prevColor = detected_color
            return Status.RUNNING


class IsQRDecoded(Behaviour):
    """カメラを使って、正面のQRコードの読み取りに成功したかを判定するノード"""
    def __init__(self, name: str):
        super(IsQRDecoded, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))
        self.running = False
        self.detected = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            # グローバル変数のビデオオブジェクトに対して「QRコード認識モード」へ切り替えるよう指示
            g_video.set_target_interested(TargetInterested.QRCODE)
            self.logger.info("%+06d %s.detection started for QR code" % (g_plotter.get_distance(), self.__class__.__name__))
        
        # バックグラウンドの別スレッドが解読した最新のQRテキストを取得
        text = g_video.get_QR_text()
        if text != "":  # 空文字でなければ解読成功！
            if not self.detected:
                self.detected = True
                self.logger.info("%+06d %s.QR code decoded: %s" % (g_plotter.get_distance(), self.__class__.__name__, text))
            return Status.SUCCESS  # 次のステップへ
        else:
            return Status.RUNNING


class IsSonarOn(Behaviour):
    """超音波センサーで、前方に障害物（ペットボトル等）が指定距離以内に近づいたか判定するノード"""
    def __init__(self, name: str, alert_dist: int):
        super(IsSonarOn, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))
        self.alert_dist = alert_dist  # 警戒距離（cm）
        self.running = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            self.logger.info("%+06d %s.detection started for dist=%d" % (g_plotter.get_distance(), self.__class__.__name__, self.alert_dist))
        
        # 超音波センサーから前方物体までの距離を取得
        dist = g_sonar_sensor.get_distance()
        if (dist <= self.alert_dist and dist > 0):  # 0より大きく、指定距離以下なら捕捉とみなす
            self.logger.info("%+06d %s.alerted at dist=%d" % (g_plotter.get_distance(), self.__class__.__name__, dist))
            return Status.SUCCESS
        else:
            return Status.RUNNING


class IsTouchOn(Behaviour):
    """タッチセンサーのボタンが物理的にカチッと押されたかを判定するノード（主にスタート合図用）"""
    def __init__(self, name: str):
        super(IsTouchOn, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))
        self.running = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            self.logger.info("%+06d %s.waiting for touch..." % (g_plotter.get_distance(), self.__class__.__name__))
        
        # ボタンが押し込まれていれば SUCCESS を返して即座に発進させる
        if g_touch_sensor.is_pressed():
            self.logger.info("%+06d %s.pressed" % (g_plotter.get_distance(), self.__class__.__name__))
            return Status.SUCCESS
        else:
            return Status.RUNNING


class StopNow(Behaviour):
    """左右の車輪モーターのパワーを0にし、その場で緊急停止・ブレーキをかけるノード"""
    def __init__(self, name: str):
        super(StopNow, self).__init__(name)
        self.logger.debug("%s.__init__()" % (self.__class__.__name__))

    def update(self) -> Status:
        g_right_motor.set_power(0)
        g_right_motor.set_brake(True)
        g_left_motor.set_power(0)
        g_left_motor.set_brake(True)
        self.logger.info("%+06d %s.motors stopped" % (g_plotter.get_distance(), self.__class__.__name__))
        return Status.SUCCESS


class BrakeUntilStopped(Behaviour):
    """左右の車輪にブレーキをかけ、エンコーダが動かなくなる(=実際に止まる)まで
    待つノード(2026-09-20追加)。

    StopNowはpower=0+brakeを1回設定して即SUCCESSを返すため、直後のノードが
    同じtickで別のパワーを上書きしてしまい、ブレーキがほぼ効かない。
    こちらは実際に止まるまでRUNNINGを返し続けるので、直進の終わりの
    惰性・次の旋回開始時の慣性を断つのに使う。
    """
    def __init__(self, name: str, still_ticks: int = 3, timeout_sec: float = 0.6) -> None:
        super(BrakeUntilStopped, self).__init__(name)
        self.still_ticks = still_ticks
        self.timeout_sec = timeout_sec
        self.running = False

    def update(self) -> Status:
        g_right_motor.set_power(0)
        g_right_motor.set_brake(True)
        g_left_motor.set_power(0)
        g_left_motor.set_brake(True)
        cur_r = g_right_motor.get_count()
        cur_l = g_left_motor.get_count()
        if not self.running:
            self.running = True
            self.t0 = time.time()
            self.still = 0
        elif cur_r == self.prev_r and cur_l == self.prev_l:
            self.still += 1
        else:
            self.still = 0
        self.prev_r = cur_r
        self.prev_l = cur_l
        if self.still >= self.still_ticks or time.time() - self.t0 >= self.timeout_sec:
            self.logger.info("%+06d %s.stopped (still=%d, %.2fs)" % (
                g_plotter.get_distance(), self.__class__.__name__, self.still, time.time() - self.t0))
            return Status.SUCCESS
        return Status.RUNNING


class LineProbe(Behaviour):
    """進行方向のまま床の黒線まで低速で直進し、黒を検知した位置(既知の座標)で
    位置をリセットしてから、公称距離だけ後退して元の点に戻るノード(2026-09-20追加)。

    et_rally_planner側のcheckpoints.pyが、ゲート退出後などの「停止して旋回する点」に
    挿入する"probe"ステップ用。旋回を増やさないので、旋回ごとのキャスターの引きずりは
    増えない。補正できるのは進行方向の座標だけ(向きのズレは補正できない)。

    動作:
      1. fwd : target(絶対方位)へRunByGyroと同じPIDで低速直進。進んだ距離が
               min_mm以上になってから黒を検知したら停止フェーズへ(min_mm未満の黒は
               コース上の他の黒いマーク等の誤検知として無視)。max_mmまで進んでも
               黒が見つからなければ「検知失敗」として停止フェーズへ。
      2. stop: ブレーキをかけて、エンコーダが動かなくなるまで待つ。
      3. back: 検知できた場合は「公称距離(nominal_mm) + 検知から停止までの惰性」だけ、
               検知失敗の場合は「進んだ距離」だけ、後退して計画上の元の点に戻る
               (検知成功なら黒線の既知座標が基準になるので、元の点のズレが
               リセットされる。失敗なら元の位置に戻るだけで、経路には影響しない)。
    後退中の向き保持は、前進と同じ式でよい(ヨー角は左右の出力差だけで決まる)。
    """
    def __init__(self, name: str, target: float, nominal_mm: float, min_mm: float, max_mm: float,
                 power: int, pid_p: float, pid_i: float, pid_d: float) -> None:
        super(LineProbe, self).__init__(name)
        self.target = target
        self.nominal_mm = nominal_mm
        self.min_mm = min_mm
        self.max_mm = max_mm
        self.power = power
        self.pid_p = pid_p
        self.pid_i = pid_i
        self.pid_d = pid_d
        self.classifier = ColorClassifier()
        self.phase = "init"

    def _brake(self) -> None:
        g_right_motor.set_power(0)
        g_right_motor.set_brake(True)
        g_left_motor.set_power(0)
        g_left_motor.set_brake(True)

    def update(self) -> Status:
        current_heading = (-1) * g_course * g_gyro_sensor.get_angle() * GYRO_SCALE_FACTOR
        dist = g_plotter.get_distance()
        if self.phase == "init":
            self.pid = PID(self.pid_p, self.pid_i, self.pid_d, setpoint=self.target,
                           sample_time=EXEC_INTERVAL, output_limits=(-self.power, self.power))
            self.orig = dist
            self.detected = False
            self.dist_detect = 0
            self.black_count = 0
            self.black_first = 0
            self.next_sample_mm = 0
            # アームを下げた直後の数tickは、センサー値が不安定(2026-09-20の実機テストで、
            # 線から16cm離れているのに動き出して9mm/8mmで「黒を検知」した)ため、
            # 静止して待ってから検知を始める。
            self.settle_end = time.time() + 0.3
            self.phase = "fwd"
            self.logger.info("%+06d %s.probe started (nominal=%dmm, window=%d..%dmm)" % (
                dist, self.__class__.__name__, self.nominal_mm, self.min_mm, self.max_mm))

        if self.phase == "stop":
            self._brake()
            cur_r = g_right_motor.get_count()
            cur_l = g_left_motor.get_count()
            if self.stop_ticks == 0:
                self.stop_t0 = time.time()
            if cur_r == self.prev_r and cur_l == self.prev_l:
                self.still += 1
            else:
                self.still = 0
            self.prev_r = cur_r
            self.prev_l = cur_l
            self.stop_ticks += 1
            if self.still >= 3 or time.time() - self.stop_t0 >= 0.6:
                traveled = dist - self.orig
                if self.detected:
                    self.back_mm = self.nominal_mm + (traveled - self.dist_detect)
                else:
                    self.back_mm = traveled
                self.back_start = dist
                self.phase = "back"
                self.logger.info("%+06d %s.stopped, going back %dmm (detected=%s)" % (
                    dist, self.__class__.__name__, self.back_mm, self.detected))
            return Status.RUNNING

        if self.phase == "fwd" and time.time() < self.settle_end:
            # 待っている間もセンサーを読んで(値は捨てる)、読み出しモードの切替や
            # アーム動作直後の(0,0,0)の無効値を、走り出す前に済ませておく。
            g_color_sensor.get_raw_color_hsv()
            self._brake()
            return Status.RUNNING

        error = (float(self.target) - current_heading + 180.0) % 360.0 - 180.0
        self.pid.setpoint = current_heading + error
        turn = int(self.pid(current_heading))
        turn = max(-self.power, min(self.power, turn))

        if self.phase == "fwd":
            traveled = dist - self.orig
            h, s, v = g_color_sensor.get_raw_color_hsv()
            # 黒が2tick連続で見えたときだけ検知とみなす(ノイズ対策)。
            # 検知位置は、連続の最初の黒を見た位置にする(判定の遅れを含めない)。
            # ColorClassifierは「低彩度(S<35)で白でないもの」を全て黒扱いにするため、
            # 影になった白い床や灰色の●も黒と判定してしまう(2026-09-20、線に届く前の
            # 誤検知の疑い)。ここでは明度Vも見て、本物の黒(V平均約26)だけ拾う。
            # 25mm進むごとにHSVをログに出して、実機での値を確認できるようにする。
            if traveled >= self.next_sample_mm:
                self.logger.info("%+06d %s.traveled=%dmm hsv=(%d,%d,%d)" % (
                    dist, self.__class__.__name__, traveled, h, s, v))
                self.next_sample_mm += 25
            # 2026-09-20実機ログ: 床(白)=(0,5,99)、黒線=(195〜220, 32〜37, 9〜29)。
            # 黒線は青みがかって彩度Sが35を少し超える(36,37)ことがあるため、Sの
            # 上限は緩め、明度Vで判定する。(0,0,0)は読み出しの無効値(線から離れた
            # 位置で「黒」と誤検知していた)なので、黒とも白とも数えず無視する。
            if h == 0 and s == 0 and v == 0:
                pass
            elif traveled >= self.min_mm and s < 50 and v <= PROBE_BLACK_V_MAX:
                if self.black_count == 0:
                    self.black_first = traveled
                self.black_count += 1
            else:
                self.black_count = 0
            if self.black_count >= 2:
                self.detected = True
                traveled = self.black_first
                self.dist_detect = traveled
                self.logger.info("%+06d %s.black detected at %dmm (nominal=%dmm, diff=%+dmm) hsv=(%d,%d,%d)" % (
                    dist, self.__class__.__name__, traveled, self.nominal_mm, traveled - self.nominal_mm, h, s, v))
            elif traveled >= self.max_mm:
                self.logger.warning("%+06d %s.black NOT detected within %dmm, returning to start" % (
                    dist, self.__class__.__name__, self.max_mm))
            else:
                g_right_motor.set_power(self.power + g_course * turn)
                g_left_motor.set_power(self.power - g_course * turn)
                return Status.RUNNING
            self.phase = "stop"
            self.stop_ticks = 0
            self.still = 0
            self.prev_r = g_right_motor.get_count()
            self.prev_l = g_left_motor.get_count()
            self._brake()
            return Status.RUNNING

        # phase == "back"
        if dist - self.back_start >= self.back_mm:
            self._brake()
            self.logger.info("%+06d %s.probe complete" % (dist, self.__class__.__name__))
            return Status.SUCCESS
        g_right_motor.set_power(-self.power + g_course * turn)
        g_left_motor.set_power(-self.power - g_course * turn)
        return Status.RUNNING


class RunAsInstructed(Behaviour):
    """指定された左右の固定パワー（PWM値）で、ひたすら車輪を回し駆動させる単純移動ノード"""
    def __init__(self, name: str, pwm_l: int, pwm_r: int) -> None:
        super(RunAsInstructed, self).__init__(name)
        # コース設定（右コース=-1、左コース=1）を掛けることで、左右の旋回や進行方向を自動でコースにアジャストする
        self.pwm_l = g_course * pwm_l
        self.pwm_r = g_course * pwm_r
        self.running = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            self.logger.info("%+06d %s.started with pwm=(%s, %s)" % (g_plotter.get_distance(), self.__class__.__name__, self.pwm_l, self.pwm_r))
        g_right_motor.set_power(self.pwm_r)
        g_left_motor.set_power(self.pwm_l)
        return Status.RUNNING


class TraceLine(Behaviour):
    """カラーセンサー（光・明暗）とPID制御を用いた、一般的な車体下のライントレース動作ノード"""
    def __init__(self, name: str, target: int, power: int, pid_p: float, pid_i: float, pid_d: float,
                 trace_side: TraceSide) -> None:
        super(TraceLine, self).__init__(name)
        self.power = power  # 基本の前進ベースパワー
        # simple_pid ライブラリを使って、明暗の目標値（setpoint=target）に合わせるためのPID演算器を初期化
        self.pid = PID(pid_p, pid_i, pid_d, setpoint=target, sample_time=EXEC_INTERVAL, output_limits=(-power, power))
        self.trace_side = trace_side  # 線の「左エッジ」を這うか「右エッジ」を這うかの設定
        self.running = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            self.logger.info("%+06d %s.trace started with TS=%s" % (g_plotter.get_distance(), self.__class__.__name__, self.trace_side.name))
        
        # カラーセンサーから明暗度（v）を取得
        h, s, v = g_color_sensor.get_raw_color_hsv()
        
        # トレースするエッジの左右（NORMAL / OPPOSITE）とコース特性（g_course）を加味して、曲がるための旋回量（turn）を計算
        if self.trace_side == TraceSide.NORMAL:
            turn = (-1) * g_course * int(self.pid(v))
        else: # TraceSide.OPPOSITE
            turn = g_course * int(self.pid(v))
            
        # 前進パワーに旋回出力を足し引きして車輪を回す
        g_right_motor.set_power(self.power - turn)
        g_left_motor.set_power(self.power + turn)
        return Status.RUNNING


class SpinAndLocateLine(Behaviour):
    """一度ラインから外れる方向に旋回（スピン）したのち、逆旋回して再度黒線を「視覚的に捕捉」する高度なノード"""
    def __init__(self, name: str, target: int, max_power: int, min_power: int,
                 pid_p: float, pid_i: float, pid_d: float, trace_side: TraceSide) -> None:
        super(SpinAndLocateLine, self).__init__(name)
        self.target = target
        self.spin_direction = 1 if trace_side == TraceSide.NORMAL else -1
        self.pid_p = pid_p
        self.pid_i = pid_i
        self.pid_d = pid_d
        self.clamper = SymmetricClamper(min_power, max_power) # パワーが弱すぎて不感帯に入ったり、強すぎたりするのを防ぐリミッター
        self.move_away = True  # 最初は「ラインから離れるフェーズ」
        self.running = False

    def update(self) -> Status:
        # 2026-09-14: ジャイロの生値は実際の回転量を約0.6%過少に報告していると
        # 判明した(py_etrobo_util/plotter.pyのGYRO_SCALE_FACTOR参照)ため、
        # 全ての箇所でここを掛けた値を「真の角度の推定値」として使う。
        current_heading = (-1) * g_course * g_gyro_sensor.get_angle() * GYRO_SCALE_FACTOR
        if not self.running:
            # フェーズ1: 確実に元のラインを見失う（外に出る）ために、今の向きから30度強制的にスピンさせる目標を設定
            self.target_heading = current_heading + self.spin_direction * 30
            self.pid = PID(self.pid_p, self.pid_i, self.pid_d, setpoint=self.target_heading, sample_time=EXEC_INTERVAL)
            self.running = True
            self.logger.info("%+06d %s.spin started at heading=%d for %d" % (g_plotter.get_distance(),
                                                                             self.__class__.__name__, current_heading, self.target_heading))
        if self.move_away:
            # --- フェーズ1: ラインから外側へ離れる動作 ---
            error = float(self.target_heading) - current_heading
            # 角度の差を -180 〜 180 度の範囲に正規化（補正）
            if error > 180.0: error -= 360.0
            if error < -180.0: error += 360.0
            
            if abs(error) < 2.0:  # 30度しっかり離れ終わったら
                self.logger.info("%+06d %s.move away spin ended at heading=%d" % (g_plotter.get_distance(), self.__class__.__name__, current_heading))
                # フェーズ2へ移行：目標値をジャイロ角度ではなく、探し求める「黒線の明暗度（target）」にスイッチ！
                self.pid = PID(self.pid_p, self.pid_i, self.pid_d, setpoint=self.target, sample_time=EXEC_INTERVAL)
                self.spin_direction *= -1  # 旋回方向を真逆に反転
                self.move_away = False     # 離れるフェーズを終了
                return Status.RUNNING
            power = int(self.clamper.clamp(self.pid(current_heading)))
        else:
            # --- フェーズ2: 逆旋回して床の黒線を探し当てる動作 ---
            h, s, v = g_color_sensor.get_raw_color_hsv()
            error = float(self.target) - v
            if abs(error) < 5.0:  # センサー値が目標の黒線の明暗に重なった瞬間！「線を発見」とみなす
                self.logger.info("%+06d %s.line located at heading=%d" % (g_plotter.get_distance(), self.__class__.__name__, current_heading))        
                return Status.SUCCESS  # 任務完了で SUCCESS
            power = int(self.clamper.clamp(self.pid(v))) * self.spin_direction * (-1)
            
        g_right_motor.set_power(g_course * power)
        g_left_motor.set_power((-1) * g_course * power)
        return Status.RUNNING    


class SpinAround(Behaviour):
    """ジャイロセンサーをフィードバックに用いて、その場で指定角度だけ超精密にスピン（回旋）するノード"""
    def __init__(self, name: str, target: int, max_power: int, min_power: int,
                 pid_p: float, pid_i: float, pid_d: float, target_type: HeadingType) -> None:
        super(SpinAround, self).__init__(name)
        self.target = target
        self.target_type = target_type  # ABSOLUTE(絶対値指定) か RELATIVE(現在の向きからの相対) か
        self.pid_p = pid_p
        self.pid_i = pid_i
        self.pid_d = pid_d
        self.clamper = SymmetricClamper(min_power, max_power)
        self.running = False

    def update(self) -> Status:
        # 2026-09-14: ジャイロの生値は実際の回転量を約0.6%過少に報告していると
        # 判明した(py_etrobo_util/plotter.pyのGYRO_SCALE_FACTOR参照)ため、
        # 全ての箇所でここを掛けた値を「真の角度の推定値」として使う。
        current_heading = (-1) * g_course * g_gyro_sensor.get_angle() * GYRO_SCALE_FACTOR
        if not self.running:
            if self.target_type == HeadingType.RELATIVE:
                self.target_heading = current_heading + self.target  # 相対角度で目標決定
            else:
                self.target_heading = self.target                  # 絶対角度で目標決定
            self.pid = PID(self.pid_p, self.pid_i, self.pid_d, setpoint=self.target_heading, sample_time=EXEC_INTERVAL)
            self.running = True
            self.logger.info("%+06d %s.spin started at heading=%d for %d" % (g_plotter.get_distance(),
                                                                             self.__class__.__name__, current_heading, self.target_heading))
        # 短い方(-180〜180度)に正規化した誤差。current_headingはジャイロの積算値で
        # 周回を重ねると360度を大きく超えることがあり、"if error>180: -=360"を1回
        # 適用するだけでは範囲内に収まりきらないケースがあった(360度以上ズレている
        # 場合、1回の補正では足りない)。剰余演算(%)を使えば、ズレの大きさに関わらず
        # 一発で-180〜180度の範囲に正規化できる(et_rally_plannerのgeo.normalize_degと
        # 同じ考え方)。
        error = (float(self.target_heading) - current_heading + 180.0) % 360.0 - 180.0

        if abs(error) < 2.0:  # 目標角度との誤差が2度以内に収まったら旋回完了
            self.logger.info("%+06d %s.spin ended at heading=%d" % (g_plotter.get_distance(), self.__class__.__name__, current_heading))
            return Status.SUCCESS
        # PIDライブラリは内部でsetpoint - current_headingを単純に(180度をまたぐ場合の
        # 短い方への正規化なしで)計算するため、上のerror(短い方に正規化済み)と食い違い、
        # 180度以上・逆方向に旋回してしまう不具合があった。setpointを毎ティック
        # current_heading + error に補正することで、PID内部の誤差計算を上のerrorと一致させる。
        self.pid.setpoint = current_heading + error
        power = int(self.clamper.clamp(self.pid(current_heading)))
        g_right_motor.set_power(g_course * power)
        g_left_motor.set_power((-1) * g_course * power)
        return Status.RUNNING


class SpinAroundByEncoder(Behaviour):
    """左右のタイヤの回転量(エンコーダ)を揃えて回すことで、「その場旋回」であること
    そのものを幾何学的に保証する旋回ノード。SpinAround(上記)の代替。

    背景(2026-09-12): SpinAroundはジャイロの角度だけを見て、目標角度に届くまで
    左右対称のパワーを与え続ける方式。最終的な向きの精度はジャイロがそのまま
    保証するが、左右のタイヤの実効径やグリップにわずかでも差があると、実際の
    回転中心が車軸の中心からズレてしまい、「その場」旋回のはずが車体全体が
    平行移動する問題があった。et_rally_plannerでの検証(±90度の旋回のみを
    30回繰り返すテスト)で、旋回だけで最大約40cm・再現性の高い(2回の試行で
    ほぼ同じ量・同じ向き)位置ズレが見つかっている。ランダムな滑りにしては
    再現性が高すぎるため、左右のタイヤの機械的な非対称性(回転中心のオフセット)
    が主因と推定した。

    このノードでは、目標の回転角度を「左右の車輪が地面の上で進むべき円弧の
    長さ(符号は逆・大きさは同じ)」に変換し(WHEEL_TREAD/TIRE_DIAMETER、
    py_etrobo_util/plotter.py参照)、実際に左右のエンコーダがその量だけ回転
    するまで駆動する(フェーズ1)。左右対称に回転させている限り、タイヤの
    実効径の絶対値の較正誤差があっても「その場」であることには影響しない。

    ただし旋回中にタイヤが滑ると(エンコーダは回っても実際には転がっていない)
    実際の角度がズレる可能性があるため、フェーズ1完了後にジャイロで最終角度を
    確認し、2度以上のズレが残っていれば低パワー(fine_min_power〜fine_max_power、
    SpinAroundのSPIN_MIN_POWER=60より大幅に低い値を想定)で小さく仕上げ補正する
    (フェーズ2)。フェーズ2の判定基準(2度以内)はSpinAroundと同一なので、
    最終的な角度精度は変えずに、旋回による位置ズレだけを減らす狙い。
    """
    def __init__(self, name: str, target: int,
                 main_power: int, fine_max_power: int, fine_min_power: int,
                 pid_p: float, pid_i: float, pid_d: float, target_type: HeadingType,
                 fine_tolerance_deg: float = 2.0,
                 decel_deg: float = 0.0, decel_power: int = 50) -> None:
        super(SpinAroundByEncoder, self).__init__(name)
        # 2026-09-20: フェーズ1(全力寄りのmain_power)のまま目標のエンコーダ角度に
        # 到達してブレーキをかけると、慣性で行き過ぎてフェーズ2の仕上げ補正が
        # 毎回必要になる。残りのエンコーダ角度がdecel_deg未満になったら
        # decel_powerに落として勢いを減らしてからブレーキをかける(0で無効)。
        # 静止状態からdecel_powerで始めると静止摩擦で動けない恐れがあるため、
        # 目標がdecel_degの2倍未満の小さい旋回では使わない。
        self.decel_deg = decel_deg
        self.decel_power = decel_power
        self.target = target
        self.target_type = target_type
        self.main_power = main_power  # フェーズ1(エンコーダ主導・全力寄り)の駆動パワー
        self.pid_p = pid_p
        self.pid_i = pid_i
        self.pid_d = pid_d
        # 2026-09-12: フェーズ2(ジャイロの仕上げ補正)がその場旋回の位置ズレの
        # 原因になっていないか切り分けるための一時的な診断用パラメータ。
        # フェーズ2をほぼ発動させないよう緩めた状態(例:8度)で同じ旋回テストを
        # やり直し、後方への位置ズレ(24〜28cm)が縮むかどうかを見る。
        # 縮めばフェーズ2側(左右非対称な旧SpinAround方式のまま)が原因、
        # 縮まなければ別の要因(キャスター等)を疑う。切り分けが終わったら
        # 2.0に戻すこと。
        self.fine_tolerance_deg = fine_tolerance_deg
        self.fine_clamper = SymmetricClamper(fine_min_power, fine_max_power)  # フェーズ2(仕上げ)専用
        # フェーズ1終了直後はブレーキで完全停止しているため、fine_min_power程度の
        # 弱い力では静止摩擦に勝てず、まったく動かないまま(=角度誤差が2度未満に
        # ならないまま)ノードが永久にRUNNINGを返し続けてスタックする恐れがある
        # (2026-09-12、実機でこの症状を確認)。一定時間ジャイロの角度が進まなければ、
        # フェーズ1のmain_powerに近い、動くことが分かっているパワーまで引き上げる
        # (エスカレーション)ための予備クランパー。
        self.escalated_clamper = SymmetricClamper(max(int(main_power * 0.8), fine_min_power), main_power)
        self.running = False

    def update(self) -> Status:
        # 2026-09-14: ジャイロの生値は実際の回転量を約0.6%過少に報告していると
        # 判明した(py_etrobo_util/plotter.pyのGYRO_SCALE_FACTOR参照)ため、
        # 全ての箇所でここを掛けた値を「真の角度の推定値」として使う。
        current_heading = (-1) * g_course * g_gyro_sensor.get_angle() * GYRO_SCALE_FACTOR
        if not self.running:
            if self.target_type == HeadingType.RELATIVE:
                self.target_heading = current_heading + self.target
            else:
                self.target_heading = self.target
            error = (float(self.target_heading) - current_heading + 180.0) % 360.0 - 180.0

            # 目標角度(度)を、左右の車輪が地面の上で進むべき円弧の長さ(mm)に
            # 変換し、さらにエンコーダの回転角度(度)に変換する。
            arc_length_mm = math.radians(abs(error)) * (WHEEL_TREAD / 2.0)
            self.target_motor_deg = arc_length_mm / (math.pi * TIRE_DIAMETER) * 360.0
            self.direction = 1 if error > 0 else -1

            self.start_r = g_right_motor.get_count()
            self.start_l = g_left_motor.get_count()
            self.right_done = (self.target_motor_deg < 1e-6)
            self.left_done = (self.target_motor_deg < 1e-6)
            self.phase = 1

            self.running = True
            self.logger.info("%+06d %s.encoder-spin started at heading=%d for %d (target_motor_deg=%.1f)" % (
                g_plotter.get_distance(), self.__class__.__name__, current_heading, self.target_heading, self.target_motor_deg))

        if self.phase == 1:
            delta_r = abs(g_right_motor.get_count() - self.start_r)
            delta_l = abs(g_left_motor.get_count() - self.start_l)

            # 目標のエンコーダ角度に達した方から個別に止める
            # (左右のタイヤの実効径がわずかに違っても、片方だけ行き過ぎさせない)
            if not self.right_done and delta_r >= self.target_motor_deg:
                self.right_done = True
                g_right_motor.set_power(0)
                g_right_motor.set_brake(True)
            if not self.left_done and delta_l >= self.target_motor_deg:
                self.left_done = True
                g_left_motor.set_power(0)
                g_left_motor.set_brake(True)

            if self.right_done and self.left_done:
                self.phase = 2
                self.pid = PID(self.pid_p, self.pid_i, self.pid_d, setpoint=self.target_heading, sample_time=EXEC_INTERVAL)
                self.stall_ticks = 0
                self.escalated = False
                self.prev_heading_for_stall = current_heading
                self.logger.info("%+06d %s.encoder-spin phase1 complete at heading=%d, entering gyro fine-trim" % (
                    g_plotter.get_distance(), self.__class__.__name__, current_heading))
                return Status.RUNNING

            use_decel = self.decel_deg > 0 and self.target_motor_deg >= 2 * self.decel_deg
            if not self.right_done:
                p = self.decel_power if use_decel and self.target_motor_deg - delta_r < self.decel_deg else self.main_power
                g_right_motor.set_power(g_course * self.direction * p)
            if not self.left_done:
                p = self.decel_power if use_decel and self.target_motor_deg - delta_l < self.decel_deg else self.main_power
                g_left_motor.set_power((-1) * g_course * self.direction * p)
            return Status.RUNNING

        # --- フェーズ2: ジャイロによる低パワーの仕上げ補正 ---
        error = (float(self.target_heading) - current_heading + 180.0) % 360.0 - 180.0
        if abs(error) < self.fine_tolerance_deg:
            # 2026-09-14: 判定が通った瞬間、モーターを明示的に止めずにSUCCESSを
            # 返していたため、fine_min_power(50前後)で回っていた勢いのまま
            # 判定後も惰性で回り続け、毎回ほぼ一定量(28x90度/14x180度テストで
            # 1回あたり平均0.57〜0.59度、旋回の回数にのみ比例し角度サイズには
            # 比例しない)オーバーしていたと判明。許容範囲を2.0→0.5度に狭めても
            # 改善しなかったのは、判定直前のパワーがfine_min_powerの下限に
            # 張り付いたまま変わらず、慣性の量もほぼ変わらなかったため
            # (許容範囲の広さでは効かない種類の誤差だった)。ここで明示的に
            # ブレーキをかけて惰性そのものを断つ。
            g_right_motor.set_power(0)
            g_right_motor.set_brake(True)
            g_left_motor.set_power(0)
            g_left_motor.set_brake(True)
            self.logger.info("%+06d %s.encoder-spin ended at heading=%d" % (
                g_plotter.get_distance(), self.__class__.__name__, current_heading))
            return Status.SUCCESS

        # スタック検知: ジャイロの角度がしばらく進んでいなければ、静止摩擦に
        # 負けて動けていないと判断し、動くことが分かっているパワーまで
        # 引き上げる(一度上げたら、このノードが終わるまで下げない)。
        heading_progress = abs((current_heading - self.prev_heading_for_stall + 180.0) % 360.0 - 180.0)
        if heading_progress < 0.3:
            self.stall_ticks += 1
            if self.stall_ticks > 7:  # 0.03s x 7 = 約0.2秒進捗なし(2026-09-12: 元は15=0.45秒、体感の停止時間を減らすため短縮)
                self.escalated = True
                self.logger.info("%+06d %s.stalled in fine-trim, escalating power" % (
                    g_plotter.get_distance(), self.__class__.__name__))
        else:
            self.stall_ticks = 0
        self.prev_heading_for_stall = current_heading

        self.pid.setpoint = current_heading + error
        clamper = self.escalated_clamper if self.escalated else self.fine_clamper
        power = int(clamper.clamp(self.pid(current_heading)))
        g_right_motor.set_power(g_course * power)
        g_left_motor.set_power((-1) * g_course * power)
        return Status.RUNNING


class RunByGyro(Behaviour):
    """床の線を見ず、ジャイロセンサーの角度だけを頼りに指定の方角へ向かって真っ直ぐ直進するノード"""
    def __init__(self, name: str, target: int, power: int,
                 pid_p: float, pid_i: float, pid_d: float, target_type: HeadingType,
                 distance_mm: float = 0.0, decel_mm: float = 0.0, decel_min_power: int = 40) -> None:
        super(RunByGyro, self).__init__(name)
        self.target = target
        self.target_type = target_type
        self.power = power  # 直進の前進パワー(巡航)
        self.pid_p = pid_p
        self.pid_i = pid_i
        self.pid_d = pid_d
        # 2026-09-20: 巡航パワーを上げて速く走り、止まる手前で減速する。
        # distance_mm(この区間の走行距離)とdecel_mm(減速を始める手前の距離)が
        # 両方指定されたときだけ、残り距離がdecel_mm(短い区間では距離の6割)を
        # 切ったところから、残り距離に比例してパワーをdecel_min_powerまで
        # 直線的に落とす。ゲート通過中など、止まらずに次の区間へ続くmoveでは
        # decel_mm=0にして巡航のまま走らせる。
        self.distance_mm = distance_mm
        self.decel_mm = min(decel_mm, distance_mm * 0.6) if distance_mm > 0 else 0.0
        self.decel_min_power = min(decel_min_power, power)
        self.last_log_time = None
        self.running = False

    def update(self) -> Status:
        # 2026-09-19: SpinAroundByEncoder(GYRO_SCALE_FACTOR適用済み)は旋回終了時点で
        # 真の向きをtarget_heading_degに正しく一致させているが、直後にRunByGyroが
        # 同じraw角度を無補正で読むと、raw角度はtargetよりGYRO_SCALE_FACTOR分
        # (約0.635%)少なく見える。RunByGyroのPIDはこれを実際の不足と誤認して
        # ロボットをさらに回してしまい、結果として真の向きがtarget_heading_degを
        # そのぶんオーバーシュートした状態で直進が続く(target_heading_degの符号・
        # 大きさに比例するズレなので、区間ごとに右にも左にもズレて見える一因になり
        # うる)。2026-09-14時点では適用すると本番経路でむしろ悪化したとのことだが、
        # 当時は他の較正(キャスター引きずり補正・タイヤ径較正)とも変更が重なって
        # いた可能性があるため、これ単体を切り分けて再検証する
        # (2026-09-19、et_rally_planner側の解析に基づき再度有効化)。
        current_heading = (-1) * g_course * g_gyro_sensor.get_angle() * GYRO_SCALE_FACTOR
        # 1秒ごとに現在の方角をログに吐き出してデバッグしやすくする
        if self.last_log_time == None or time.time() - self.last_log_time >= 1.0:
            self.logger.info("%+06d %s.current heading=%d" % (g_plotter.get_distance(), self.__class__.__name__, current_heading))
            self.last_log_time = time.time()
        if not self.running:
            if self.target_type == HeadingType.RELATIVE:
                self.target_heading = current_heading + self.target
            else:
                self.target_heading = self.target
            # 算出した旋回量が直進パワーを超えて暴走しないよう、output_limitsでしっかりキャップをかける
            self.pid = PID(self.pid_p, self.pid_i, self.pid_d, setpoint=self.target_heading, sample_time=EXEC_INTERVAL, output_limits=(-self.power, self.power))
            self.logger.info("%+06d %s.gyro run started toward heading=%d" % (g_plotter.get_distance(), self.__class__.__name__, self.target_heading))
            self.orig_dist = g_plotter.get_distance()
            self.running = True

        # 減速区間では、残り距離に比例して現在のパワーを下げる。
        power_now = self.power
        if self.decel_mm > 0.0:
            remaining = self.distance_mm - (g_plotter.get_distance() - self.orig_dist)
            if remaining < self.decel_mm:
                ratio = max(remaining, 0.0) / self.decel_mm
                power_now = int(self.decel_min_power + (self.power - self.decel_min_power) * ratio)

        # SpinAroundと同種の不具合(PID内部はsetpointとcurrent_headingの単純な引き算で、
        # 180度をまたぐ場合の短い方への正規化を行わない)を避けるため、ここでも
        # 短い方に正規化した誤差を計算し、それに一致するようsetpointを毎ティック補正する。
        # current_headingはジャイロの積算値で周回を重ねると360度を大きく超えることが
        # あるため、剰余演算(%)で一発で-180〜180度に正規化する
        # (1回きりのif文による補正では、360度以上ズレている場合に対応しきれない)。
        error = (float(self.target_heading) - current_heading + 180.0) % 360.0 - 180.0
        self.pid.setpoint = current_heading + error

        turn = int(self.pid(current_heading))  # まっすぐ走るために必要な微修正の旋回量
        # 減速中は基準パワーが下がるので、旋回量も現在のパワー以内に収める
        # (PID自体の上限は巡航パワーで作ってあるため)。
        turn = max(-power_now, min(power_now, turn))
        g_right_motor.set_power(power_now + g_course * turn)
        g_left_motor.set_power(power_now - g_course * turn)
        return Status.RUNNING


class TraceLineCam(Behaviour):
    """【前上方のカメラ画像を使用】Video.pyが算出した偏差角（theta）をターゲットにした先進的なライントレース"""
    def __init__(self, name: str, power: int, pid_p: float, pid_i: float, pid_d: float,
                 gs_min: int, gs_max: int, trace_side: TraceSide) -> None:
        super(TraceLineCam, self).__init__(name)
        self.power = power
        # 画面中央に対する線の角度偏差を「0（ズレなし）」に近づけるためのPID
        self.pid = PID(pid_p, pid_i, pid_d, setpoint=0, sample_time=EXEC_INTERVAL, output_limits=(-power, power))
        self.gs_min = gs_min  # 二値化の輝度最小値
        self.gs_max = gs_max  # 二値化の輝度最大値
        self.trace_side = trace_side
        self.running = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            # ビデオオブジェクトに二値化の閾値、モード（LINE検出）、およびトレース側（右・左・中央）を設定
            g_video.set_thresholds(self.gs_min, self.gs_max)
            g_video.set_target_interested(TargetInterested.LINE)
            
            # コース（右・左）に応じて、画像内のエッジ（TraceSide.RIGHT / LEFT）を自動で最適化
            if self.trace_side == TraceSide.NORMAL:
                if g_course == -1: g_video.set_trace_side(TraceSide.RIGHT)
                else: g_video.set_trace_side(TraceSide.LEFT)
            elif self.trace_side == TraceSide.OPPOSITE: 
                if g_course == -1: g_video.set_trace_side(TraceSide.LEFT)
                else: g_video.set_trace_side(TraceSide.RIGHT)
            else:
                g_video.set_trace_side(TraceSide.CENTER)
            self.logger.info("%+06d %s.trace started with TS=%s" % (g_plotter.get_distance(), self.__class__.__name__, self.trace_side.name))
        
        # video.pyが裏で計算してくれている最新の「theta（線のズレ角度）」を取得してPIDに放り込む
        turn = (-1) * int(self.pid(g_video.get_theta()))
        g_right_motor.set_power(self.power - turn)
        g_left_motor.set_power(self.power + turn)
        return Status.RUNNING


class IsJunction(Behaviour):
    """カメラ画像処理で割り出した線の幅（Range of edges）を用いて、交差点や分岐点への到達を検知するノード"""
    def __init__(self, name: str, target_state: JState) -> None:
        super(IsJunction, self).__init__(name)
        self.target_state = target_state  # 待ち構える状態（JOINEDやFORKEDなど）
        self.reached = False
        self.prev_roe = 0
        self.state:JState = JState.INITIAL
        self.running = False

    def update(self) -> Status:
        if not self.running:
            self.running = True
            self.logger.info("%+06d %s.scan started" % (g_plotter.get_distance(), self.__class__.__name__))
        
        # video.pyから最新の「線の横幅ピクセル数（roe）」を取得
        roe = g_video.get_range_of_edges()
        if roe != 0:
            if self.state == JState.INITIAL:
                # 合流待ちの時に、線の幅が急に太くなったら（JUNCT_UPPER_THRESHを超えたら）合流開始と判定
                if (self.target_state == JState.JOINING or self.target_state == JState.JOINED) and roe >= JUNCT_UPPER_THREAH and self.prev_roe <= JUNCT_LOWER_THREAH:
                    self.logger.info("%+06d %s.lines are joining" % (g_plotter.get_distance(), self.__class__.__name__))
                    self.state = JState.JOINING
                # 分岐待ちの時に、線の幅が急に変動し始めたら分岐開始と判定
                elif (self.target_state == JState.FORKING or self.target_state == JState.FORKED) and roe >= JUNCT_LOWER_THREAH and self.prev_roe <= JUNCT_LOWER_THREAH:
                    self.logger.info("%+06d %s.lines are forking" % (g_plotter.get_distance(), self.__class__.__name__))
                    self.state = JState.FORKING
            elif self.state == JState.JOINING:
                # 太かった線がまた元の細さに戻ったら、完全に1本のラインに合流完了（JOINED）したと判定
                if roe <= JUNCT_LOWER_THREAH:
                    self.logger.info("%+06d %s.the join completed" % (g_plotter.get_distance(), self.__class__.__name__))
                    self.state = JState.JOINED
            elif self.state == JState.FORKING:
                # 分岐を通り過ぎてまた線が通常の細さに戻ったら、分岐完了（FORKED）したと判定
                if roe <= JUNCT_LOWER_THREAH and self.prev_roe >= JUNCT_UPPER_THREAH:
                    self.logger.info("%+06d %s.the fork completed" % (g_plotter.get_distance(), self.__class__.__name__))
                    self.state = JState.FORKED
            else:
                pass
        self.prev_roe = roe

        # 自分が目指していた交差点の状態（target_state）に完全に一致したら SUCCESS を返して次のタスクへバトンタッチ
        if not self.reached and self.state == self.target_state:
            self.reached = True
            self.logger.info("%+06d %s.target state reached" % (g_plotter.get_distance(), self.__class__.__name__))
            return Status.SUCCESS
        else:
            return Status.RUNNING


class TraverseBehaviourTree(object):
    """【全体の司令塔】毎周期ロボットから呼ばれ、ビヘイビアツリーを1回進め（tick）、自己位置をプロットするクラス"""
    def __init__(self, tree: BehaviourTree) -> None:
        self.tree = tree
        self.last_log_time = None
        self.running = False
        
    def __call__(
        self,
        hub: Hub,
        arm_motor: Motor,
        right_motor: Motor,
        left_motor: Motor,
        touch_sensor: TouchSensor,
        color_sensor: ColorSensor,
        sonar_sensor: SonarSensor,
        gyro_sensor: GyroSensor,
    ) -> None:
        global g_hub, g_arm_motor, g_right_motor, g_left_motor, g_touch_sensor, g_color_sensor, g_sonar_sensor, g_gyro_sensor, g_plotter
        if not self.running:
            # 最初の1回目だけ呼ばれる初期化処理。ハードウェア群をすべてグローバル変数へ登録し、Plotter（自己位置推定）を生成
            g_hub = hub
            g_arm_motor = arm_motor
            g_right_motor = right_motor
            g_left_motor = left_motor
            g_touch_sensor = touch_sensor
            g_color_sensor = color_sensor
            g_sonar_sensor = sonar_sensor
            g_gyro_sensor = gyro_sensor
            g_plotter = Plotter()
            print(" -- TraverseBehaviorTree initialization complete")
            self.running = True
        else:
            # 2回目以降（毎周期 0.03秒ごと）：
            self.tree.tick_once() # ビヘイビアツリーの条件を1ステップ動かす
            # モーターの回転数やセンサー値から、ロボットが今マップ上のどこにいるか（位置）を毎ステップ計算・更新する（オドメトリ）
            g_plotter.plot(hub, arm_motor, right_motor, left_motor, touch_sensor, color_sensor, sonar_sensor, gyro_sensor)


class VideoThread(threading.Thread):
    """メイン制御とは『別部屋』で動き、カメラ画像処理（video.py）を高速並行実行するためのスレッドクラス"""
    def __init__(self):
        super().__init__()
        # スレッドを安全に外部から終了させるためのシグナルイベントオブジェクトを自前で用意
        self._stop_event = threading.Event()
        self.prev_time = time.time()

    def stop(self):
        # 外部（メイン側）からこのstop()を呼ぶと、内部フラグ（_flag）がTrueになり、裏のループが止まる仕掛け
        self._stop_event.set()

    def run(self):
        # start()が呼ばれたらこのrunが裏で回り出す。stop_eventがONにならない限り、無限にカメラ画像を更新（process）し続ける
        while not self._stop_event.is_set():
            g_video.process(g_plotter, g_hub, g_arm_motor, g_right_motor, g_left_motor, g_color_sensor, g_sonar_sensor, g_gyro_sensor)
            
            # --- CPUパワーを使い果たさないためのウェイト（お昼寝）処理 ---
            current_time = time.time()
            elapsed_time = current_time - self.prev_time
            self.prev_time = current_time
            # 画像処理がVIDEO_INTERVAL（0.02秒＝秒間50フレームペース）より早く終わったら、余った時間分だけsleepしてCPUを休ませる
            if elapsed_time < VIDEO_INTERVAL:
                time.sleep(VIDEO_INTERVAL - elapsed_time)


def build_behaviour_tree() -> BehaviourTree:
    """【ロボットの作戦マップ】どういう順番・条件でミッションをクリアしていくかを構築する巨大な設計図関数"""
    root = Sequence(name="2026 base", memory=True)              # すべての根本となる親シーケンス（順番に実行、クリアしたものは記憶（memory））
    calibration = Sequence(name="calibration", memory=True)    # 機材リセット・調整用の子シーケンス
    start = Parallel(name="start", policy=ParallelPolicy.SuccessOnOne()) # 並行処理ノード（どれか1つがSUCCESSになればクリア）
    lap2 = Parallel(name="lap2", policy=ParallelPolicy.SuccessOnOne())#parallelでmemory=trueは持っていないが、sequenceに組み込むことでparallelの結果も覚えられる。
    lap3 = Parallel(name="lap3", policy=ParallelPolicy.SuccessOnOne())
    carry1 = Parallel(name="carry1", policy=ParallelPolicy.SuccessOnOne())
    carry2 = Parallel(name="carry2", policy=ParallelPolicy.SuccessOnOne())
    carry3 = Parallel(name="carry3", policy=ParallelPolicy.SuccessOnOne())
    qr1 = Parallel(name="qr1", policy=ParallelPolicy.SuccessOnOne())
    qr2 = Parallel(name="qr2", policy=ParallelPolicy.SuccessOnOne())
    qr3 = Parallel(name="qr3", policy=ParallelPolicy.SuccessOnOne())
    qr4 = Parallel(name="qr4", policy=ParallelPolicy.SuccessOnOne())
    qr_read = Parallel(name="qr_read", policy=ParallelPolicy.SuccessOnOne())
    qr_scan_shake = Sequence(name="qr_scan_shake", memory=True)
    qr_scan_move_back = Parallel(name="qr_scan_move_back2", policy=ParallelPolicy.SuccessOnOne())
    
    # 1. 機材キャリブレーション（アームを上下に限界まで振り、デバイスをリセット）
    # name を渡してるのはログとかわかりやすくするための物
    calibration.add_children(
        [
            ArmUpDownFull(name="arm up", direction=ArmDirection.UP),
            ArmUpDownFull(name="arm down", direction=ArmDirection.DOWN),
            ResetDevice(name="device reset"),
        ]
    )
    # 2. スタート（タッチセンサーがカチッと押されるまでその場で待機）
    start.add_children(
        [
            IsTouchOn(name="touch start"),
        ]
    )
    # 3. 第2区間（床の線を見ながら通常エッジをトレースし、地面に青い線が見えるまで突っ走る）
    lap2.add_children(
        [
            TraceLine(name="sensor trace normal edge", target=TRACELINE_TARGET_V, power=33,
                pid_p=0.55, pid_i=0.0000009, pid_d=0.015, trace_side=TraceSide.NORMAL),
            IsColorDetected(name="check color", color=Color.BLUE),
        ]
    )
    # 4. 第3区間（ジャイロ直進で線を無視して370mm先のペットボトルの位置まで真っ直ぐ進む）
    lap3.add_children(
        [
            RunByGyro(name="run straight to catch the bottle", target=5, power=33,
                pid_p=1.1, pid_i=0.00075, pid_d=0.04, target_type=HeadingType.ABSOLUTE),
            IsDistanceEarned(name="check distance", delta_dist = 370),
        ]
    )
    # 5. ボトル運搬区間1（ラインに復帰してトレース開始、また次の青線が見えるまで前進）
    carry1.add_children(
        [
            TraceLine(name="sensor trace normal edge", target=TRACELINE_TARGET_V, power=33,
                pid_p=0.55, pid_i=0.0000009, pid_d=0.015, trace_side=TraceSide.NORMAL),
            IsColorDetected(name="check color", color=Color.BLUE),
        ]
    )
    # 6. ボトル運搬区間2（ジャイロを使い、絶対方位90度を向いて青線をまたぎ越すように120mm直進）
    carry2.add_children(
        [
            RunByGyro(name="run straight to pass the blue line", target=90, power=33,
                pid_p=1.1, pid_i=0.00075, pid_d=0.04, target_type=HeadingType.ABSOLUTE),
            IsDistanceEarned(name="check distance", delta_dist = 120),
        ]
    )
    # 7. ボトル運搬区間3（少しスピードを上げてライントレースを再開、再度青線が見えるまで前進）
    carry3.add_children(
        [
            TraceLine(name="sensor trace normal edge", target=TRACELINE_TARGET_V+10, power=33,
                pid_p=0.65, pid_i=0.000001, pid_d=0.011, trace_side=TraceSide.NORMAL),
            IsColorDetected(name="check color", color=Color.BLUE),
        ]
    )
    # 8. QRコード接近区間1（ジャイロ直進を用いて、対向車線側のエッジと平行になるよう50mm進む）
    qr1.add_children(
        [
            RunByGyro(name="run straight to align with opposite edge", target=5, power=33,
                pid_p=1.1, pid_i=0.00075, pid_d=0.04, target_type=HeadingType.ABSOLUTE),
            IsDistanceEarned(name="check distance", delta_dist = 50),
        ]
    )
    # 9. QRコード接近区間2（絶対方位0度に向けて車体の歪みをきれいに補正しながら50mm直進）
    qr2.add_children(
        [
            RunByGyro(name="run straight to correct heading", target=0, power=33,
                pid_p=1.1, pid_i=0.00075, pid_d=0.04, target_type=HeadingType.ABSOLUTE),
            IsDistanceEarned(name="check distance", delta_dist = 50),
        ]
    )
    # 10. QRコード接近区間3（今度は『逆側（Opposite）』のエッジを這いながら、青線を見つけるまでトレース）
    qr3.add_children(
        [
            TraceLine(name="sensor trace opposite edge", target=TRACELINE_TARGET_V+10, power=33,
                pid_p=0.655, pid_i=0.0000011, pid_d=0.012, trace_side=TraceSide.OPPOSITE),
            IsColorDetected(name="check color", color=Color.BLUE),
        ]
    )
    # 11. QRコード接近区間4（絶対方位-90度を向いて、青線の半分くらいの位置を超えるように100mm直進）
    qr4.add_children(
        [
            RunByGyro(name="run straight to pass half the blue line", target=-90, power=33,
                pid_p=1.1, pid_i=0.00075, pid_d=0.04, target_type=HeadingType.ABSOLUTE),
            IsDistanceEarned(name="check distance", delta_dist = 100),
        ]
    )
    # QRコード読み取り用：少し後ろに下がってカメラとの適切なピント・画角の距離を作る動作
    qr_scan_move_back.add_children(
        [
            RunAsInstructed(name="move back a little", pwm_l=-SPIN_MIN_POWER, pwm_r=-SPIN_MIN_POWER),
            IsDistanceEarned(name="check distance", delta_dist = 50),
        ]
    )
    # QRコード読み取り用：カメラがQRを捉えやすくするために、車体を「左右に細かくイヤイヤとシェイク」させる一連の連続シーケンス
    qr_scan_shake.add_children(
        [
            SpinAround(name="scan for QR code", target=4, max_power=SPIN_MAX_POWER, min_power=SPIN_MIN_POWER,
                pid_p=0.2, pid_i=0.00075, pid_d=0.03, target_type=HeadingType.RELATIVE),
            StopNow(name="stop"),
            IsTimePassed(name="wait for a moment", delta_time=0.8), # 止まってカメラのブレが収まるのを待つ
            SpinAround(name="scan for QR code", target=-8, max_power=SPIN_MAX_POWER, min_power=SPIN_MIN_POWER,
                pid_p=0.2, pid_i=0.00075, pid_d=0.03, target_type=HeadingType.RELATIVE),
            StopNow(name="stop"),
            IsTimePassed(name="wait for a moment", delta_time=0.8),
            SpinAround(name="scan for QR code", target=4, max_power=SPIN_MAX_POWER, min_power=SPIN_MIN_POWER,
                pid_p=0.2, pid_i=0.00075, pid_d=0.03, target_type=HeadingType.RELATIVE),
            StopNow(name="stop"),
            IsTimePassed(name="wait for a moment", delta_time=2.0),
            qr_scan_move_back, # 1回シェイクしても読めなければ、50mmバックして仕切り直す
            SpinAround(name="scan for QR code", target=3, max_power=SPIN_MAX_POWER, min_power=SPIN_MIN_POWER,
                pid_p=0.2, pid_i=0.00075, pid_d=0.03, target_type=HeadingType.RELATIVE),
            StopNow(name="stop"),
            IsTimePassed(name="wait for a moment", delta_time=0.8),
            SpinAround(name="scan for QR code", target=-6, max_power=SPIN_MAX_POWER, min_power=SPIN_MIN_POWER,
                pid_p=0.2, pid_i=0.00075, pid_d=0.03, target_type=HeadingType.RELATIVE),
            StopNow(name="stop"),
            IsTimePassed(name="wait for a moment", delta_time=0.8),
            SpinAround(name="scan for QR code", target=3, max_power=SPIN_MAX_POWER, min_power=SPIN_MIN_POWER,
                pid_p=0.2, pid_i=0.00075, delta_time=0.8),
            StopNow(name="stop"),
            IsTimePassed(name="wait for a moment", delta_time=2.0),
        ]
    )
    # パラレルノード：QRコードのデコード（IsQRDecoded）を見張りつつ、読めるまで下の「イヤイヤシェイク動作」を並行して回し続ける
    qr_read.add_children(
        [
            IsQRDecoded(name="check QR code"),
            qr_scan_shake,
        ]
    )
    
    # -------------------------------------------------------------------------
    # 各子要素を、大元の根本ルート（Sequence）へ上から順番に一本道として組み立てる
    # -------------------------------------------------------------------------
    root.add_children(
        [
            calibration,      # ① 起動時のアーム・ジャイロ初期化
            start,            # ② タッチセンサー押し下げでのスタート待ち
            lap2,             # ③ ライントレースで最初の青線まで爆走
            lap3,             # ④ ジャイロ直進でボトルをキャッチしに行く
            carry1,           # ⑤ ボトルを乗せたまま青線までトレース
            carry2,           # ⑥ 直角にジャイロ直進して青線を越える
            carry3,           # ⑦ 再びライントレースで最後の青線まで運搬
            # ⑧ その場でぐるっと回れ右（絶対方位10度を向くようにスピン反転）
            SpinAround(name="about the face", target=10, max_power=SPIN_MAX_POWER, min_power=SPIN_MIN_POWER,
                pid_p=0.2, pid_i=0.00075, pid_d=0.03, target_type=HeadingType.ABSOLUTE),
            StopNow(name="stop"),
            IsTimePassed(name="wait for a moment", delta_time=1.0),
            qr2,              # ⑨ 方角を0度に綺麗に整えて少し直進
            StopNow(name="stop"),
            IsTimePassed(name="wait for a moment", delta_time=1.0),
            # ⑩ 逆側エッジ方向へスピンし、床の黒線をセンサーで見つけ出すまで回る
            SpinAndLocateLine(name="spin and locate line", target=TRACELINE_TARGET_V-20, max_power=SPIN_MAX_POWER, min_power=SPIN_MIN_POWER,
                pid_p=0.2, pid_i=0.00075, pid_d=0.03, trace_side=TraceSide.OPPOSITE),
            StopNow(name="stop"),
            IsTimePassed(name="wait for a moment", delta_time=1.0),
            qr3,              # ⑪ 見つけたラインを逆側エッジでトレースして青線まで進む
            qr4,              # ⑫ -90度を向いて青線をまたぎ越す
            StopNow(name="stop"),
            IsTimePassed(name="wait for a moment", delta_time=1.0),
            # ⑬ カメラの視界を確保するため、アームを完全に上に跳ね上げる
            ArmUpDownFull(name="arm up", direction=ArmDirection.UP),
            # ⑭ 正面のQRコードボードと正対するように絶対方位0度へ車体を向ける
            SpinAround(name="align for QR code scanning", target=0, max_power=SPIN_MAX_POWER, min_power=SPIN_MIN_POWER,
                pid_p=0.2, pid_i=0.00075, pid_d=0.03, target_type=HeadingType.ABSOLUTE),
            qr_read,          # ⑮ 体をシェイクさせながら正面のQRコードをカメラで読み取る（読めるまで次のタスクに進まない）
            # ⑯ 読み終わったらアームを元の位置にガシャ降ろす
            ArmUpDownFull(name="arm down", direction=ArmDirection.DOWN),
            StopNow(name="stop"), # ⑰ モーター完全停止
            TheEnd(name="end"),   # ⑱ プログラムの終了待機状態へ
        ]
    )
    return root


def apply_caster_drag_compensation(steps: list, mm_per_deg: float = 0.0944) -> list:
    """その場旋回のたびに、ロボット後方のボールキャスターが(横方向にしか転がりに
    くいため)車体を後方に引きずる問題への暫定的な補正。

    2026-09-12〜14の実機テスト(その場旋回だけを繰り返し、位置ズレを実測)で判明:
    - ±90度を交互に30回繰り返すと、後方に24cm/24.5cm/28cmの一貫したズレ
      (平均25.5cm、1回の90度旋回あたり約8.5mm)
    - 同方向に90度を28回連続(4回=360度ごとに元の向きへ戻る)だと、ズレはわずか
      約2cmまで激減 → ズレの向きがロボット自身の向きと一緒に回転している証拠
      (床やコースなどグローバルな要因ではなく、車体に固定されたキャスター由来と
      ほぼ確定)
    - 手でキャスターのボールを回すと、前後方向はスムーズだが左右方向にひっかかりが
      あることも確認済み(その場旋回はキャスターを左右方向に転がす動きを要求する
      ため、症状と一致)

    本番のコースは旋回の向き・角度がバラバラに混ざるため、このズレは打ち消し
    合わずに実質的に残り続ける前提で、各turnステップの直後にあるmoveステップの
    距離を、その旋回角度に比例した分だけ延長して打ち消す。補正の向きは「旋回後の
    新しい進行方向」=直後のmoveの向きと同じなので、そのmoveの距離に足すだけで済む。
    直後にmoveが続かない旋回(ゴールでの向き合わせなど)は位置に影響しないため
    補正しない。

    キャスターの清掃・潤滑などで機構側を直せば、この補正量自体を減らす/不要に
    できる可能性がある(根本対策はそちらが本命、これは暫定処置)。

    mm_per_deg: 90度旋回あたり実測約8.5mmから逆算(8.5mm / 90度 ≈ 0.0944mm/度)。
    0を渡せば補正を無効化できる。
    """
    compensated = []
    current_heading = 0.0
    pending_mm = 0.0
    for step in steps:
        step = dict(step)
        if step["type"] == "turn":
            delta = (step["target_heading_deg"] - current_heading + 180.0) % 360.0 - 180.0
            current_heading = step["target_heading_deg"]
            pending_mm = abs(delta) * mm_per_deg
        elif step["type"] == "move":
            if pending_mm > 0.0:
                step["distance_mm"] = step["distance_mm"] + pending_mm
                pending_mm = 0.0
        compensated.append(step)
    return compensated


def apply_caster_drag_compensation_v2(steps: list, mm_per_deg: float = 0.0557) -> list:
    """apply_caster_drag_compensation(上記、旧版)の後継。角度に単純比例するのでは
    なく「直前の反転から、まだ1周(360度)し切っていない回転量」に比例させる。

    背景(2026-09-16、SpinAroundByEncoder+ブレーキ+GYRO_SCALE_FACTOR等の
    一連の修正が入った後に、et_rally_planner環境で再実施した実機テスト):
    - 交互(+90/-90を30回、15往復): 後方に平均15.05cm(2〜5回目、1回目は外れ値
      として除外)。1回の90度旋回あたり約5.0mm、度あたりだと約0.0557mm/度
      (旧版の0.0944mm/度から約41%減少。一連の精度向上で引きずり自体は
      減ったが、消えてはいない)。
    - 同方向のみ(+90を28回連続=360度×7周、毎回向きを変えない): 後方3.7cm
      (CW)/前方5.5cm(CCW、符号が反転する点も興味深い)。交互よりずっと小さい。
    - 4回ごとに反転(+90×4→-90×4を4セット=32回、各ブロックはちょうど
      360度で1周してから反転): 前方0.74cm相当とほぼノイズレベル。

    この3パターンから、「反転すること自体」ではなく「キャスターが360度
    1周して元の姿勢に戻り切る前に反転させること」が後方への引きずりの
    主因だと分かった(1周ちょうどで反転するブロック4テストでは、交互
    テストのような蓄積が起きなかったため)。

    そこでこの関数では、同じ向きへの旋回が連続している間の累積回転量を
    追跡し、その累積が360度に達するまでの部分(=まだ1周し切っていない
    「未解消」の回転)にだけ、交互テストで実測した最大のレート
    (0.0557mm/度)を掛けて補正する。360度に達した後(1周完了後)の
    追加の回転や、反転そのものによる補正は行わない(同方向単独テストで
    見られた3.7〜5.5cmの小さな残留や、その符号がCW/CCWで異なる性質は、
    交互テストの15cmに比べれば小さく、かつCW/CCWで向きが逆なので実際の
    経路では部分的に打ち消し合う可能性が高いと判断し、単純化のためあえて
    モデルに含めていない)。

    未検証の点(2026-09-16時点、実機での旋回のみ連続するテストでは検証
    できていない): このモデルの数値予測を、旋回とmoveが交互に並ぶ実際の
    経路(build_et_rally_treeが生成する形)に対して直接検証できていない。
    旋回だけが連続するテストJSON(直進を挟まない)では、この関数の
    「旋回の直後にあるmoveの距離を伸ばす」という補正の乗せ方自体が
    機能しない(直進を挟まず旋回が続くと、後の旋回の計算が前の旋回の
    pending_mmを上書きしてしまう)ため、旋回のみのテスト結果と本関数の
    予測値を単純比較できない。実際のETラリー経路(旋回の直後に必ず直進が
    続く)に適用した上で、改めて実機で結果を確認すること。

    mm_per_deg: 交互テストの実測値から算出(15.05cm / (30回×90度) ≈
    0.0557mm/度)。0を渡せば補正を無効化できる。
    """
    compensated = []
    current_heading = 0.0
    run_deg = 0.0  # 直前の反転からの、符号付き累積回転量(度、360度を超えても巻き戻さない)
    pending_mm = 0.0
    for step in steps:
        step = dict(step)
        if step["type"] == "turn":
            delta = (step["target_heading_deg"] - current_heading + 180.0) % 360.0 - 180.0
            current_heading = step["target_heading_deg"]

            if delta == 0.0:
                pending_mm = 0.0
            else:
                this_sign = 1.0 if delta > 0 else -1.0
                run_sign = 1.0 if run_deg > 0 else (-1.0 if run_deg < 0 else this_sign)
                if this_sign != run_sign:
                    run_deg = 0.0  # 反転: 未解消の累積をリセット

                before_capped = min(abs(run_deg), 360.0)
                run_deg += delta
                after_capped = min(abs(run_deg), 360.0)
                # 360度に達するまでの「未解消」区間が今回どれだけ増えたか
                # (既に360度に達していれば増分は0=これ以上補正しない)
                incomplete_increase = max(after_capped - before_capped, 0.0)
                pending_mm = incomplete_increase * mm_per_deg
        elif step["type"] == "move":
            if pending_mm > 0.0:
                step["distance_mm"] = step["distance_mm"] + pending_mm
                pending_mm = 0.0
        compensated.append(step)
    return compensated


def apply_lateral_drift_compensation(steps: list, mm_per_deg_a: float = 0.00496,
                                      mm_per_deg_b: float = 0.01278,
                                      sign: float = 1.0, max_correction_deg: float = 5.0) -> list:
    """その場旋回のたびに横方向(左右)へも車体がズレる問題への補正。

    背景(2026-09-19〜20、et_rally_planner環境でその場旋回のみを繰り返す
    テストを実施): apply_caster_drag_compensation(前後方向)は元々「後方への
    引きずり」だけをモデル化していたが、実際には**同方向に旋回を28回連続
    (7周ぶん)させただけでも、常に一定方向(「右」)へのズレが残る**ことが
    判明した。しかも旋回の向き(delta>0のA方向/delta<0のB方向)によって
    ズレの大きさが約2.1倍違う:
      - A方向(target_heading_degが増える向き): 8回の試行平均で1.25cm/28回
        (0.00496mm/度)、値は非常に安定(1.2〜1.3cmの範囲)。
      - B方向(target_heading_degが減る向き): 11回の試行のうち、最初の3回
        (4.9cm平均)だけ明確に高く、残り8回は2.0〜2.9cm(平均2.59cm)に
        まとまった。
    前後方向の引きずりと違い、A/CCW-B(前後で符号が逆だった)とは別の性質で、
    横方向はA/Bどちらの旋回方向でも同じ側(「右」)へズレる。そのため、この
    補正は旋回方向に関わらず常に同じ向き(sign)で、大きさだけを旋回方向
    (delta>0かdelta<0か)で使い分ける。

    実現方法: 非ホロノミックな車体は横方向に直接動けないため、旋回直後の
    moveの目標方位(target_heading_deg)を、そのmoveの距離に応じてわずかに
    傾けることで、直進しながら横ズレを打ち消す(distance_mm × sin(補正角)
    ≈ 打ち消したい横ズレ量、という近似)。moveの距離が短すぎると必要な
    補正角が大きくなりすぎるため、max_correction_degで上限をかける
    (それ以上は打ち消しきれず残る)。

    sign: 2026-09-20、実機の本番経路テスト(X座標が複数回とも完璧に一致)で
    sign=1.0が正しい向きだと確認済み。

    mm_per_deg_b: 2026-09-20、B方向係数を後半8回のクラスター(2.59cm/0.01028
    mm/度)で運用したところ、本番経路(plan_seed1650169_right_laps2.json、
    2周)を4回実走したうちY座標が3回とも+5cm前後の残差を残した
    (区間ごとの旋回方向を解析すると、Y方向の区間はX方向の区間よりB方向
    係数への依存度が高い(44.7% vs 37.5%)ため、この残差はB方向の過小補正が
    一因の可能性が高いと判断)。そのため、後半8回だけでなく最初の3回の
    外れ値も含めた11回全体の平均3.22cm(0.01278mm/度)に引き上げて再検証する。
    """
    compensated = []
    current_heading = 0.0
    pending_lateral_mm = 0.0
    for step in steps:
        step = dict(step)
        if step["type"] == "turn":
            delta = (step["target_heading_deg"] - current_heading + 180.0) % 360.0 - 180.0
            current_heading = step["target_heading_deg"]
            if delta == 0.0:
                pending_lateral_mm = 0.0
            else:
                rate = mm_per_deg_a if delta > 0.0 else mm_per_deg_b
                pending_lateral_mm = abs(delta) * rate
        elif step["type"] == "move":
            if pending_lateral_mm > 0.0 and step["distance_mm"] > 1e-6:
                correction_deg = sign * math.degrees(pending_lateral_mm / step["distance_mm"])
                correction_deg = max(-max_correction_deg, min(max_correction_deg, correction_deg))
                step["target_heading_deg"] = step["target_heading_deg"] + correction_deg
                pending_lateral_mm = 0.0
        compensated.append(step)
    return compensated


def steps_from_plan(plan_path: str, move_power: int = 70, move_pid=(1.1, 0.00075, 0.04),
                     turn_max_power: int = SPIN_MAX_POWER, turn_min_power: int = SPIN_MIN_POWER,
                     turn_pid=(0.2, 0.00075, 0.03),
                     turn_main_power: int = SPIN_MAX_POWER,
                     turn_fine_max_power: int = 60, turn_fine_min_power: int = 50,
                     turn_fine_tolerance_deg: float = 0.5,
                     caster_drag_mm_per_deg: float = 0.0502,
                     lateral_drift_mm_per_deg_a: float = 0.00496,
                     lateral_drift_mm_per_deg_b: float = 0.01278,
                     lateral_drift_sign: float = 1.0,
                     brake_after_move: bool = False,
                     move_decel_mm: float = 0.0, move_decel_min_power: int = 40,
                     turn_decel_deg: float = 0.0, turn_decel_power: int = 50,
                     use_probes: bool = True, probe_power: int = 33) -> list:
    # 2026-09-20: 直進の減速(move_decel_mm)・旋回の減速(turn_decel_deg)・
    # 停止待ちブレーキ(brake_after_move)は、実機で試す前に「元に戻して」と
    # 依頼があったため、すべて既定で無効(従来と同じ動作、move_power=70)。
    # 使うときは例えば move_power=90, move_decel_mm=250, turn_decel_deg=40 を
    # steps_from_planに渡す。減速するのは、直後が旋回または経路の最後で
    # 「止まる」moveだけ。
    # caster_drag_mm_per_deg: 2026-09-16、et_rally_planner環境で0を検証した後、
    # 改めてその場旋回のみのテスト(SpinAroundByEncoder+ブレーキ+GYRO_SCALE_
    # FACTOR等、現行の全修正が入った状態)を実施して再較正した値。
    # +90/-90を30回交互(15往復)に繰り返すテストを4回試行し、後方への
    # ズレは平均15.05cm(1回目は外れ値として除外)。90度旋回1回あたり
    # 約5.0mm、度あたりに直すと15.05cm/(30回×90度)≈0.0557mm/度
    # (旧値0.0944から約41%減少。一連の精度向上で引きずり自体は減ったが、
    # 消えてはいない)。CW/CCWで向きを区別せず一律この値を使う
    # (apply_caster_drag_compensation、シンプルな「毎回の角度にそのまま
    # 比例」方式。同方向の旋回が360度以上連続すると過剰補正になりうる
    # 点はapply_caster_drag_compensation_v2のdocstring参照。ただしv2は
    # まだ検証中でここでは呼んでいない)。
    #
    # 2026-09-20再較正: plan_spin_alternating30.json(±90度を交互に30回)で
    # 7回試行(13.0/13.5/15.9/12.9/15.0/11.9/12.7cm、平均13.56cm)し直した
    # ところ、0.0557よりさらに小さい0.0502mm/度(13.56cm/(30回×90度))と
    # 判明したため更新。この再テストでは同時に「右」方向への横ズレも
    # 毎回記録しており(平均6.5cm前後)、それはapply_lateral_drift_
    # compensation(下記、新規追加)で別途補正している。
    #
    # 元の0.0944は2026-09-12〜14、fine_min_power引き上げ/ブレーキ追加/
    # 許容範囲短縮/GYRO_SCALE_FACTORのいずれも入っていない時点のSpinAround
    # ByEncoderの挙動から算出した値。その後の一連の修正で旋回そのものの精度が
    # 上がった結果、実際の後方への引きずられ量(キャスターの影響)自体が
    # 当時より小さくなっている可能性が高く、0.0944のままだと旋回角度に比例して
    # 過剰補正(進みすぎ)になっていると疑われる(2026-09-15、黄色ゲート
    # エントリーでX軸方向の誤差が周回ごとに蓄積する症状を確認、黄色手前の
    # 旋回角度が経路中でも大きい区間で顕著に出ていることと整合)。0のままで
    # 改善するか確認し、改善するなら係数を測り直すこと。
    # turn_fine_tolerance_deg: 2026-09-12、その場旋回のみを繰り返すテストで
    # 後方に24〜28cmの一貫したズレが残ることを確認したため、フェーズ2(ジャイロの
    # 仕上げ補正)が原因かを切り分けるため一時的に8.0に緩めてテストした。
    # 結果、8.0でもズレはほぼ変わらず(後方24cm)、フェーズ2は位置ズレの原因では
    # ないと判明した(原因は後方のボールキャスターの横方向の引っかかりとほぼ確定、
    # apply_caster_drag_compensation参照)ため、いったん通常の2.0に戻した。
    #
    # その後2026-09-14、28x90度/14x180度(どちらも合計2520度)の旋回テストで、
    # 最終的なheadingのズレが1回あたり平均0.57〜0.59度とほぼ一定(旋回角度にも
    # 回数×角度の合計にも比例せず、旋回の"回数"にのみ比例)と判明。これは
    # フェーズ2が毎回0度ではなく許容範囲(2.0度)内のどちらか一方に偏った状態で
    # 収束していることを示すため、許容範囲そのものを0.5に狭めて偏りの絶対量を
    # 直接減らすことにした。turn_fine_min_power/maxを50/60まで上げてあるので
    # (2026-09-14時点)収束力には余裕があり、再スタックのリスクは低いはずだが、
    # 挙動(毎回止まりすぎる、暴れるなど)に問題が出たら緩める方向で調整すること。
    # turn_fine_min_power: 2026-09-12、実機テストで元の15だと静止摩擦に負けて
    # 全く動けず、フェーズ2が毎回スタック検知経由でしか進まない症状を確認した
    # ため35に引き上げた。その後、フェーズ2は位置ズレの主因ではないと判明した
    # ため(上記)、2026-09-14にさらに50に引き上げた(SPIN_MIN_POWER=60が
    # 「確実に動く」と分かっている値なので、それに寄せつつ少し余裕を残す)。
    # これでフェーズ2が最初から動きやすくなり、スタック検知による停止時間も
    # さらに減る見込み。まだ毎回止まるようならさらに上げて試すこと。
    """ETラリーの経路計画(et_rally_planner/export_plan.pyが書き出すplan.json)を読み込み、
    RunByGyro/IsDistanceEarned/SpinAroundByEncoder(2026-09-12にSpinAroundから切替、
    詳細はSpinAroundByEncoderのdocstring参照)を組み合わせたビヘイビアツリーの
    部品リストに変換する。

    plan.json側の各stepは絶対方位(target_type=ABSOLUTE)で、経路のスタート時点を0度とした
    シフト済みの値。実機ではジャイロをリセットした瞬間に向いている方角が0度に対応する
    (ResetDeviceの直後にスタートする前提)。旋回の増加方向(右回り/左回り)が実機のジャイロ
    配線と一致しているかは、最初の数ステップだけ動かして必ず確認すること。逆だった場合は
    plan.json側の全target_heading_degの符号を反転すれば直る。

    move_power/turn_max_power等は区間ごとに変えず一律のデフォルト値を使っている。
    区間ごとにパワーやPIDを変えたくなったら、plan.json側にフィールドを足して
    ここで読み取るよう拡張すればよい。
    """
    with open(plan_path, encoding="utf-8") as f:
        plan = json.load(f)

    # 2026-09-14: キャスターの引きずりによる旋回後の位置ズレを暫定補正
    # (apply_caster_drag_compensationのdocstring参照)。
    plan["steps"] = apply_caster_drag_compensation(plan["steps"], mm_per_deg=caster_drag_mm_per_deg)
    # 2026-09-20: 前後方向だけでなく横方向のズレも補正する
    # (apply_lateral_drift_compensationのdocstring参照)。distance_mm/
    # target_heading_degのどちらも同じstep辞書のキーなので、上の前後方向
    # 補正と独立に、順不同で適用してよい。
    plan["steps"] = apply_lateral_drift_compensation(
        plan["steps"], mm_per_deg_a=lateral_drift_mm_per_deg_a,
        mm_per_deg_b=lateral_drift_mm_per_deg_b, sign=lateral_drift_sign,
    )

    nodes = []
    for i, step in enumerate(plan["steps"]):
        if step["type"] == "move":
            is_last = i + 1 >= len(plan["steps"])
            stops_after = is_last or plan["steps"][i + 1]["type"] in ("turn", "probe")
            leg = Parallel(name="et_rally move%d %s" % (i, step["label"]), policy=ParallelPolicy.SuccessOnOne())
            leg.add_children(
                [
                    RunByGyro(name="et_rally run%d" % i, target=step["target_heading_deg"], power=move_power,
                        pid_p=move_pid[0], pid_i=move_pid[1], pid_d=move_pid[2],
                        target_type=HeadingType.ABSOLUTE,
                        distance_mm=step["distance_mm"],
                        decel_mm=move_decel_mm if stops_after else 0.0,
                        decel_min_power=move_decel_min_power),
                    IsDistanceEarned(name="et_rally dist%d" % i, delta_dist=int(step["distance_mm"])),
                ]
            )
            nodes.append(leg)
            # 2026-09-20: 直後が旋回(または経路の最後)のmoveだけ、実際に止まる
            # までブレーキをかける。entry->exitのように同じ向きで続くmoveの
            # 間では止めない(ゲート通過中に止まらないため)。
            if brake_after_move and stops_after:
                nodes.append(BrakeUntilStopped(name="et_rally brake%d" % i))
        elif step["type"] == "probe":
            # 2026-09-20: 床の黒線での位置リセット(et_rally_planner/checkpoints.py)。
            # use_probes=Falseなら、planにprobeがあっても何もしない(従来と同じ動作)。
            if use_probes:
                # カラーセンサーはアームが上がっていると隠れて使えない(calibrationは
                # 最後にarm upで終わる)ため、アームを下げるのは寄り道の間だけ。
                # 直前のmoveが終わった時点で車輪はまだ最後のパワーで回り続けている
                # (次のノードが上書きするまで)ので、アームを動かす前に必ずStopNowで止める。
                nodes.append(StopNow(name="et_rally probe%d stop" % i))
                nodes.append(ArmUpDownFull(name="et_rally probe%d arm down" % i, direction=ArmDirection.DOWN, min_travel_deg=100))
                nodes.append(
                    LineProbe(name="et_rally probe%d %s" % (i, step["line"]),
                        target=step["target_heading_deg"], nominal_mm=step["nominal_mm"],
                        min_mm=step["min_mm"], max_mm=step["max_mm"], power=probe_power,
                        pid_p=move_pid[0], pid_i=move_pid[1], pid_d=move_pid[2])
                )
                nodes.append(ArmUpDownFull(name="et_rally probe%d arm up" % i, direction=ArmDirection.UP, min_travel_deg=100))
        else:  # "turn"
            # 2026-09-12: 旋回による位置ズレ(±90度x30回のテストで最大約40cm、
            # 再現性の高いズレを確認)を減らすため、エンコーダで左右対称に
            # 回すSpinAroundByEncoderに切り替えた。
            #
            # 2026-09-19: 素のSpinAroundに一旦戻して単体テストしたところ、
            # SpinAroundByEncoderより明確に悪化したため、SpinAroundByEncoderに
            # 戻す。素のSpinAroundは切り戻したい場合のためコメントアウトで残す。
            # SpinAroundを使う場合はturn_max_power/turn_min_power/turn_pidが必要。
            #
            # nodes.append(
            #     SpinAround(name="et_rally turn%d" % i, target=step["target_heading_deg"],
            #         max_power=turn_max_power, min_power=turn_min_power,
            #         pid_p=turn_pid[0], pid_i=turn_pid[1], pid_d=turn_pid[2],
            #         target_type=HeadingType.ABSOLUTE)
            # )
            nodes.append(
                SpinAroundByEncoder(name="et_rally turn%d" % i, target=step["target_heading_deg"],
                    main_power=turn_main_power,
                    fine_max_power=turn_fine_max_power, fine_min_power=turn_fine_min_power,
                    pid_p=turn_pid[0], pid_i=turn_pid[1], pid_d=turn_pid[2],
                    target_type=HeadingType.ABSOLUTE,
                    fine_tolerance_deg=turn_fine_tolerance_deg,
                    decel_deg=turn_decel_deg, decel_power=turn_decel_power)
            )
    return nodes


def build_et_rally_tree(plan_path: str = "plan.json") -> BehaviourTree:
    """ETラリー(ゲート3つを指定順に3周通過するミッション)専用のビヘイビアツリーを組み立てる。

    build_behaviour_tree()が組む本戦(ラインライントレース+ボトル搬送+QR読取)用のツリーとは
    別物。ETラリーは別種目のため、混ぜずに独立したツリーとして扱う。
    """
    root = Sequence(name="et_rally root", memory=True)
    calibration = Sequence(name="calibration", memory=True)
    start = Parallel(name="start", policy=ParallelPolicy.SuccessOnOne())
    # 2026-09-20: 手でロボットを置くときの位置・向きのズレ(目視だと1〜2度でも
    # ゴールで数cmの誤差になると判明、et_rally_planner側の解析参照)を、
    # ラリー本編の前にラインをたどって吸収するための準備区間。
    # trace_to_lineでコース上の黒線に正確に沿わせ(向きのズレを解消)、
    # 青色マーカーを検知した位置で止める(ラインに沿った方向の位置ズレも解消)。
    # そこから右に90度旋回して、ラリー本編が前提とする向きへ合わせる。
    prepareForRally = Sequence(name="prepareForRally", memory=True)
    trace_to_line = Parallel(name="trace to alignment line", policy=ParallelPolicy.SuccessOnOne())
    et_rally = Sequence(name="et_rally", memory=True)

    calibration.add_children(
        [
            ArmUpDownFull(name="arm down", direction=ArmDirection.DOWN),
            ArmUpDownFull(name="arm up", direction=ArmDirection.UP),
            ResetDevice(name="device reset"),
        ]
    )
    start.add_children(
        [
            IsTouchOn(name="touch start"),
        ]
    )
    trace_to_line.add_children(
        [
            TraceLine(name="align trace to line", target=TRACELINE_TARGET_V, power=33,
                pid_p=0.55, pid_i=0.0000009, pid_d=0.015, trace_side=TraceSide.NORMAL),
            IsColorDetected(name="align check blue", color=Color.BLUE),
        ]
    )
    prepareForRally.add_children(
        [
            # calibrationの最後がアーム上げ(arm up)で終わっているため、
            # カラーセンサーがアームに隠れて使えない状態のまま。位置合わせに
            # カラーセンサー(TraceLine/IsColorDetected)を使うので、ここで
            # 一旦アームを下げる。
            ArmUpDownFull(name="align arm down", direction=ArmDirection.DOWN),
            trace_to_line,
            StopNow(name="align stop"),
            # 2026-09-20: 「右に90度」の符号は未検証。実機で試して逆(左)に
            # 曲がるようならtarget=-90に反転すること(このファイル内の他の
            # 符号系と同じ運用方針)。位置ズレを増やさないよう、通常の旋回と
            # 同じSpinAroundByEncoderを使う。
            SpinAroundByEncoder(name="align turn right 90", target=90,
                main_power=SPIN_MAX_POWER, fine_max_power=60, fine_min_power=50,
                pid_p=0.2, pid_i=0.00075, pid_d=0.03, target_type=HeadingType.RELATIVE,
                fine_tolerance_deg=0.5),
            StopNow(name="align stop after turn"),
            # ラリー本編はアーム上げの状態を前提にしているはずなので
            # (calibrationが最後にarm upしていたのと合わせる)、ここで戻す。
            ArmUpDownFull(name="align arm up", direction=ArmDirection.UP),
            # ここで改めてジャイロを0度にリセットする。これをしないと、
            # 直後のet_rally(target_type=ABSOLUTE、スタート姿勢を0度とする
            # 前提)が、この位置合わせ旋回前の(不正確な)向きを基準にしたままに
            # なってしまう。アーム上げ動作の揺れが収まるのも、ここの
            # 静止待ちでまとめて吸収される。
            ResetDevice(name="device reset after align"),
        ]
    )
    # 2026-09-19: キャスター補正なしのテストで悪化を確認したため、
    # SpinAroundByEncoder+補正あり(デフォルト0.0557mm/度)に戻す。
    #
    # 2026-09-20: 横ズレ補正(lateral_drift_sign=1.0)を入れた状態で精度向上を
    # 確認済み。-1.0での比較テストを終え、sign=1.0(デフォルト)に戻す。
    et_rally.add_children(steps_from_plan(plan_path))

    root.add_children(
        [
            calibration,
            start,
            # 2026-09-20: 位置合わせ準備区間(prepareForRally)は一旦使わない。
            # 再度有効にするときは、下の1行のコメントを外すだけでよい。
            # prepareForRally,
            et_rally,
            StopNow(name="stop"),
            TheEnd(name="end"),
        ]
    )
    return root


def build_gyro_watch_tree(duration_sec: float = 60.0) -> BehaviourTree:
    """ロボットを静止させたまま、ジャイロの角度だけを一定時間ログに出し続ける
    診断用ツリー(2026-09-14追加)。

    同方向に旋回を繰り返すテストで約20度のヘディングのズレが見つかったが、
    これが「回転させ続けることで起きる何か」なのか「センサー自体の時間経過に
    よるドリフト」なのかを切り分けるために使う。タッチセンサーを押すと計測開始、
    duration_sec秒間ロボットを完全に静止させたまま放置し、ログに残る
    「gyro-watch」の行(1秒おき)を見れば、静止状態でどれだけジャイロの値が
    ズレていくかが分かる。

    使い方: 下のmainブロックで
        tree = build_et_rally_tree("plan.json")
    の代わりに
        tree = build_gyro_watch_tree(60.0)  # 秒数は好きに変更
    に差し替えて実行し、--logfileで指定したログファイルを"gyro-watch"で
    grepする。
    """
    root = Sequence(name="gyro watch root", memory=True)
    calibration = Sequence(name="calibration", memory=True)
    start = Parallel(name="start", policy=ParallelPolicy.SuccessOnOne())

    calibration.add_children(
        [
            ResetDevice(name="device reset"),
        ]
    )
    start.add_children(
        [
            IsTouchOn(name="touch start"),
        ]
    )
    root.add_children(
        [
            calibration,
            start,
            LogGyroPeriodically(name="gyro watch", duration_sec=duration_sec),
            TheEnd(name="end"),
        ]
    )
    return root


def initialize_etrobo(backend: str) -> ETRobo:
    """ロボットの各ポート（A〜F）にどのモーターやセンサーが繋がっているかを設定して起動する関数"""
    return (ETRobo(backend=backend)
            .add_hub('hub')
            .add_device('arm_motor', device_type=Motor, port='C')
            .add_device('right_motor', device_type=Motor, port='A')
            .add_device('left_motor', device_type=Motor, port='B')
            .add_device('touch_sensor', device_type=TouchSensor, port='D')
            .add_device('color_sensor', device_type=ColorSensor, port='E')
            .add_device('sonar_sensor', device_type=SonarSensor, port='F')
            .add_device('gyro_sensor', device_type=GyroSensor, port='')
    )

def setup_thread():
    """【起動スイッチ】グローバル変数としてVideoクラスのインスタンス化を行い、別スレッドを立ち上げて並行処理を開始する関数"""
    global g_video, g_video_thread
    g_video = Video()

    print(" -- starting VideoThread...")
    g_video_thread = VideoThread()
    g_video_thread.start() # これにより自動的に裏で VideoThread の run() メソッドが回り出す

def cleanup_thread():
    """【後片付け】プログラム終了時に呼び出され、別スレッドに停止命令を送り、メモリから安全に削除する関数"""
    global g_video, g_video_thread
    print(" -- stopping VideoThread...")
    g_video_thread.stop() # stop_event のフラグをTrueにする（裏のwhileループが終了する）
    g_video_thread.join() # 裏のスレッドが完全に「お部屋を片付けて退去」するのをメイン側で待つ

    del g_video # メモリから削除

def sig_handler(signum, frame) -> None:
    """Linuxシステム等からプログラムの強制終了シグナル（SIGTERM）を受け取った際の割り込みハンドラ"""
    sys.exit(1)

# =============================================================================
# 【メインプログラムのエントリーポイント】
# コマンドラインからこのファイルが直接実行された場合のみ、ここから処理がスタートします。
# =============================================================================
if __name__ == '__main__':
    # 引数パーサーの窓口を作成
    parser = argparse.ArgumentParser()
    # 必須の引数として、走行するコース（rightかleftのいずれか）の入力を要求
    parser.add_argument('course', choices=['right', 'left'], help='Course to run')
    # オプション引数として、ログを保存するファイルパス（省略時はNone）を指定可能にする
    parser.add_argument('--logfile', type=str, default=None, help='Path to log file')
    args = parser.parse_args() # 入力された文字を解析し、args.course / args.logfile として利用可能にする

    # コースが「右」なら、旋回方向などの極性を反転させるため、全体の倍率係数（g_course）を -1 に設定
    if args.course == 'right':
        g_course = -1
    else:
        g_course = 1

    # 1. 裏方仕事（カメラ・画像処理専用のマルチスレッド）をバックグラウンドで発進させる
    setup_thread()

    # 2. 本日走る予定のミッションマップ（ビヘイビアツリー）を一階層ずつ綺麗にビルドする
    # tree = build_behaviour_tree()
    # tree = build_gyro_watch_tree(60.0)  # 診断用: 静止状態でのジャイロドリフトを見る(--logfileと併用)
    tree = build_et_rally_tree("plan.json")

    # システム終了シグナル（SIGTERM）が飛んできたときに、安全に終了させるための関数（sig_handler）をOSに登録
    signal.signal(signal.SIGTERM, sig_handler)

    try:
        # 3. ハードウェア（RasPikeなどの実機またはシミュレータの通信）を初期化
        etrobo = initialize_etrobo(backend='raspike_art')
        
        # 4. add_handler = ETRoboのシステム（エンジン）に対して、『周期ごとに実行してほしい仕事を登録する窓口
        etrobo.add_handler(TraverseBehaviourTree(tree))
        
        # 5. ロボットシステムを本番稼働！0.03秒に1回のテンポでツリーを評価し、ロボットを自律走行させる（無限ループ突入）
        etrobo.dispatch(interval=EXEC_INTERVAL, logfile=args.logfile)
        
    finally:
        # 【セーフティネット】例外クラッシュや強制終了（Ctrl+C）が入った場合でも、必ずここのfinallyを通す
        # 車輪が回りっぱなしで暴走するのを防ぐため、OSの終了シグナルを一度無視（IGN）させ、安全に停止シーケンスを実行する
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        
        # 6. カメラのマルチスレッドに「終了ボタン」を押し、安全に停止させてからメモリを解放する
        cleanup_thread()
        
        # シグナル設定をデフォルト（DFL）に戻してプログラムを美しく終了させる
        signal.signal(signal.SIGTERM, signal.SIG_DFL)
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        print(" -- exiting...")
        