import json, sys
import generate_diagram
import geometry as geo
import rule_route as rr
from random_gates import parse_gate_spec, validate_gate_orientation
spec=sys.argv[1]; tag=sys.argv[2]; laps=int(sys.argv[3]) if len(sys.argv)>3 else 2
gates=parse_gate_spec(spec); validate_gate_orientation(gates)
wps,anc,labels,tp=rr.plan_route_with_anchors(gates,laps)
dist=sum(geo.distance(wps[i],wps[i+1]) for i in range(len(wps)-1))
def fake(g,_w=wps,_d=dist,_l=labels,_t=tp): return _w,_d,_l,_t
generate_diagram.plan_path_detailed=fake
r=generate_diagram.main(gates=gates,out_path=f"diagram_{tag}.svg.txt")
json.dump([{"idx":0,"seed":tag,"total_dist_cm":r["total_dist_cm"],"ok":True,"svg":r["svg"]}],open(f"gallery_{tag}_out.json","w",encoding="utf-8"),ensure_ascii=False)
last_exit=0
print("T-arm clearance before each gate entry (body front -> own T-arm):")
for i,l in enumerate(labels):
    if l and l.endswith("-exit"): last_exit=i
    if l and l.endswith("-entry"):
        g=gates[l.split("-")[1]]; w=99.0
        for k in range(last_exit+1 if last_exit else 1,i+1):
            for p in g.posts():
                if p.arm_dir[0] or p.arm_dir[1]:
                    w=min(w,rr._segment_body_clearance(wps[k-1],wps[k],p))
        print("  ",l,"%.2f cm"%w)
for k,l in enumerate(labels): print(k,l,[round(v,1) for v in wps[k]])
