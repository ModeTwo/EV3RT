"""今回の実機テスト専用: スタート/ゴールのオフセットを一時的に上書きして
plan.jsonを書き出す(config.pyは変更しない、使い捨てスクリプト)。

スタート: X=4の位置(グレー●中心)から+18cm(今回実際に置いた位置)
ゴール:   X=0の位置(グレー●中心)から-15cm(今回の想定位置)
"""

import json
import sys

import config

START_OFFSET_CM = 18.0
GOAL_OFFSET_CM = 15.0

config.START_POS_CM = (4 * config.GRID_PITCH_CM + START_OFFSET_CM, 3.5 * config.GRID_PITCH_CM)
config.GOAL_POS_CM = (0 * config.GRID_PITCH_CM - GOAL_OFFSET_CM, 3.5 * config.GRID_PITCH_CM)
# 向き(LEFT想定、180/90)はそのまま変更しない

from random_gates import random_gates  # noqa: E402
from rule_route import (  # noqa: E402
    plan_route_with_anchors,
    verify_gate_crossing_directions,
    verify_pivot_safety,
    verify_straight_clearance,
)
from commands import waypoints_to_plan  # noqa: E402
import geometry as geo  # noqa: E402


def main():
    seed_arg = sys.argv[1] if len(sys.argv) > 1 else "9392783"
    out_path = sys.argv[2] if len(sys.argv) > 2 else "plan_this_run.json"

    gates, used_seed = random_gates(int(seed_arg))
    all_gates = list(gates.values())
    all_posts = [p for g in gates.values() for p in g.posts()]

    waypoints, anchors, labels, true_points = plan_route_with_anchors(gates)

    pivot_v = verify_pivot_safety(waypoints, all_posts)
    straight_v = verify_straight_clearance(waypoints, all_posts, anchors)
    crossing_v = verify_gate_crossing_directions(waypoints, labels, all_gates)
    non_goal_pivot = [v for v in pivot_v if labels[v[0]] != "goal"]
    print(f"pivot={len(non_goal_pivot)} straight={len(straight_v)} crossing={len(crossing_v)}")

    total_dist_cm = sum(geo.distance(waypoints[i], waypoints[i + 1]) for i in range(len(waypoints) - 1))
    steps = waypoints_to_plan(waypoints, labels)
    move_count = sum(1 for s in steps if s["type"] == "move")
    turn_count = sum(1 for s in steps if s["type"] == "turn")

    out = {
        "gates": {"mode": "random", "seed": used_seed} | {c: {"a": g.foot_a_grid, "b": g.foot_b_grid} for c, g in gates.items()},
        "start_offset_cm": START_OFFSET_CM,
        "goal_offset_cm": GOAL_OFFSET_CM,
        "start_pos_cm": config.START_POS_CM,
        "goal_pos_cm": config.GOAL_POS_CM,
        "total_distance_mm": round(total_dist_cm * 10.0, 1),
        "move_count": move_count,
        "turn_count": turn_count,
        "steps": steps,
    }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"start={config.START_POS_CM} goal={config.GOAL_POS_CM}")
    print(f"total_distance_mm={out['total_distance_mm']} move_count={move_count} turn_count={turn_count}")
    print(f"wrote {len(steps)} steps to {out_path}")


if __name__ == "__main__":
    main()
