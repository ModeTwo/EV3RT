"""経路計画を、実機の絶対方位ベース制御部品(RunByGyro/SpinAround等)向けのJSONとして書き出す。

使い方:
  python3 export_plan.py                  乱数シード自動生成
  python3 export_plan.py 199055            乱数シード指定
  python3 export_plan.py "red:0,0-1,0;blue:2,1-2,2;yellow:1,3-2,3"   ゲート直接指定
  python3 export_plan.py 199055 plan.json --laps=2   周回数を指定(省略時はconfig.LAPS=3)
  --arm-clearance=4.0 を付けると、entry直前の直進でT字パーツから車体基準4cm(下限3cm)を確保する経路にする。
  --no-probes を付けると、床の黒線での位置リセット(寄り道)を挿入しない。
  出力先は plan.json (第2引数で変更可)。
"""

import json
import sys

import config
import checkpoints
from commands import waypoints_to_plan
from random_gates import parse_gate_spec, random_gates, validate_gate_orientation
from rule_route import plan_route as plan_path_detailed


def main():
    args = sys.argv[1:]
    laps = None
    use_probes = True
    positional = []
    for a in args:
        if a.startswith("--laps="):
            laps = int(a.split("=", 1)[1])
        elif a == "--no-probes":
            use_probes = False
        elif a.startswith("--arm-clearance="):
            # entry直前の直進でT字パーツから確保したい車体クリアランス(cm)。既定は無効(0)。
            config.ARM_BODY_CLEARANCE_TARGET_CM = float(a.split("=", 1)[1])
        else:
            positional.append(a)

    arg = positional[0] if len(positional) > 0 else None
    out_path = positional[1] if len(positional) > 1 else "plan.json"

    if arg is not None and not arg.lstrip("-").isdigit():
        gates = parse_gate_spec(arg)
        validate_gate_orientation(gates)
        gate_desc = {"mode": "manual", "spec": arg}
    else:
        seed = int(arg) if arg is not None else None
        gates, used_seed = random_gates(seed)
        gate_desc = {"mode": "random", "seed": used_seed}

    waypoints, total_dist_cm, labels, _true_points = plan_path_detailed(gates, laps=laps)
    probes = checkpoints.find_reset_probes(waypoints, labels, gates) if use_probes else None
    steps = waypoints_to_plan(waypoints, labels, probes=probes)

    move_count = sum(1 for s in steps if s["type"] == "move")
    turn_count = sum(1 for s in steps if s["type"] == "turn")

    out = {
        "laps": laps if laps is not None else config.LAPS,
        "gates": {**gate_desc, **{c: {"a": g.foot_a_grid, "b": g.foot_b_grid} for c, g in gates.items()}},
        "heading_convention": (
            "target_heading_deg is absolute, shifted so that the plan's own start "
            "heading = 0deg. Treat 0deg as 'the direction the robot is physically "
            "facing at gyro reset'. Rotation sense (increasing angle = CW or CCW) "
            "must be verified against the real gyro/motor wiring; negate all "
            "target_heading_deg values if it turns out reversed."
        ),
        "total_distance_mm": round(total_dist_cm * 10.0, 1),
        "move_count": move_count,
        "turn_count": turn_count,
        "steps": steps,
    }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"laps={out['laps']} gates={gate_desc}")
    for s_ in steps:
        if s_["type"] == "probe":
            print(f"  probe: {s_['line']} nominal={s_['nominal_mm']}mm heading={s_['target_heading_deg']}")
    print(f"total_distance_mm={out['total_distance_mm']} move_count={move_count} turn_count={turn_count}")
    print(f"wrote {len(steps)} steps to {out_path}")


if __name__ == "__main__":
    main()
